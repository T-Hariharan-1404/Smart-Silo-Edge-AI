/******************* Libraries *******************/
#include <DHT.h>
#include <ESP32Servo.h>
#include "model_1.h"   // Demand Model
#include "model.h"     // Rain Model

/******************* PIN DEFINITIONS *******************/
#define TRIG_PIN    5
#define ECHO_PIN    18
#define DHT_PIN     4
#define MQ135_PIN   34
#define IR_PIN      26
#define LDR_PIN     35
#define SERVO_PIN   25

#define DHT_TYPE DHT11

/******************* THRESHOLDS *******************/
#define LDR_THRESHOLD      1300
#define GAS_THRESHOLD      1600
#define HUMIDITY_THRESHOLD 70
#define SPILL_DROP_CM      15

DHT dht(DHT_PIN, DHT_TYPE);
Servo gateServo;

/******************* VARIABLES *******************/
long duration;
int level;
int prevLevel = -1;
double ml_demand_score;
double rain_results[2];

void setup() {
  Serial.begin(9600);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(IR_PIN, INPUT);

  dht.begin();
  gateServo.attach(SERVO_PIN);
  gateServo.write(90);

  Serial.println("--- Smart Silo Monitoring Started ---");
}

void loop() {

  /* ---------- ULTRASONIC ---------- */
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duration = pulseIn(ECHO_PIN, HIGH, 30000);
  level = (duration > 0) ? (200 - (duration * 0.034 / 2)) : 0;

  /* ---------- DHT ---------- */
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  if (isnan(temperature)) temperature = 0;
  if (isnan(humidity)) humidity = 0;

  /* ---------- OTHER SENSORS ---------- */
  int gasConcentration = analogRead(MQ135_PIN);
  int lightIntensity = analogRead(LDR_PIN);
  int motionState = digitalRead(IR_PIN);

  /* ---------- TINYML ---------- */
  double demand_input[4] = {
    (double)level,
    (double)temperature,
    (double)humidity,
    (gasConcentration > GAS_THRESHOLD ? 1.0 : 0.0)
  };

  ml_demand_score = score(demand_input);

  double rain_input[2] = {(double)temperature, (double)humidity};
  score_rain(rain_input, rain_results);
  double rain_probability = rain_results[1] * 100;

  /* ---------- SAFETY LOGIC ---------- */
  bool safetyRisk = (gasConcentration > GAS_THRESHOLD || humidity > HUMIDITY_THRESHOLD);
  bool confirmedSpoilage = (gasConcentration > GAS_THRESHOLD && humidity > HUMIDITY_THRESHOLD);

  Serial.println("\n--- MONITORING REPORT ---");

  if (confirmedSpoilage)
    Serial.println("SPOILAGE STATUS: CONFIRMED");
  else if (safetyRisk)
    Serial.println("SPOILAGE STATUS: RISK");
  else
    Serial.println("SPOILAGE STATUS: SAFE");

  if (prevLevel != -1 && (prevLevel - level) > SPILL_DROP_CM) {
    Serial.println("SPILLAGE ALERT: LEVEL DROP");
  }
  prevLevel = level;

  if (motionState == HIGH) {
    Serial.println("MOTION DETECTED");
  }

  /* ---------- AI ADVICE ---------- */
  Serial.print("RAIN PROBABILITY: ");
  Serial.print(rain_probability);
  Serial.println(" %");

  Serial.print("DEMAND SCORE: ");
  Serial.println(ml_demand_score);

  /* ---------- SERVO CONTROL ---------- */
  if (confirmedSpoilage || lightIntensity < LDR_THRESHOLD || rain_probability > 85.0) {
    gateServo.write(0);
    Serial.println("GATE: CLOSED");
  } else {
    gateServo.write(90);
    Serial.println("GATE: OPEN");
  }

  /* ---------- SENSOR DATA ---------- */
  Serial.println("--- SENSOR DATA ---");
  Serial.print("Level: "); Serial.println(level);
  Serial.print("Temp: "); Serial.println(temperature);
  Serial.print("Humidity: "); Serial.println(humidity);
  Serial.print("Gas: "); Serial.println(gasConcentration);
  Serial.print("Light: "); Serial.println(lightIntensity);

  delay(5000);
}