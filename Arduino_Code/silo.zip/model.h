#include <string.h>
void add_vectors(double *v1, double *v2, int size, double *result) {
    for(int i = 0; i < size; ++i)
        result[i] = v1[i] + v2[i];
}
void mul_vector_number(double *v1, double num, int size, double *result) {
    for(int i = 0; i < size; ++i)
        result[i] = v1[i] * num;
}
void score(double * input, double * output) {
    double var0[2];
    double var1[2];
    double var2[2];
    double var3[2];
    double var4[2];
    double var5[2];
    if (input[1] <= 90.85000228881836) {
        if (input[0] <= 26.949999809265137) {
            if (input[1] <= 90.54999923706055) {
                if (input[1] <= 85.85000228881836) {
                    memcpy(var5, (double[]){0.6018779342723005, 0.39812206572769954}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.6940639269406392, 0.3059360730593607}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 90.64999771118164) {
                    memcpy(var5, (double[]){0.0, 1.0}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.25, 0.75}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[0] <= 32.04999923706055) {
                if (input[0] <= 31.75) {
                    memcpy(var5, (double[]){0.5642118076688983, 0.43578819233110166}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.475177304964539, 0.524822695035461}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 30.75) {
                    memcpy(var5, (double[]){0.23684210526315788, 0.7631578947368421}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.5994724943481538, 0.40052750565184625}, 2 * sizeof(double));
                }
            }
        }
    } else {
        if (input[1] <= 93.75) {
            if (input[0] <= 38.54999923706055) {
                if (input[0] <= 35.89999961853027) {
                    memcpy(var5, (double[]){0.7142857142857143, 0.2857142857142857}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.5454545454545454, 0.45454545454545453}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 91.64999771118164) {
                    memcpy(var5, (double[]){0.6666666666666666, 0.3333333333333333}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){1.0, 0.0}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[0] <= 28.550000190734863) {
                if (input[0] <= 23.699999809265137) {
                    memcpy(var5, (double[]){0.5185185185185185, 0.48148148148148145}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.24, 0.76}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 93.85000228881836) {
                    memcpy(var5, (double[]){0.2, 0.8}, 2 * sizeof(double));
                } else {
                    memcpy(var5, (double[]){0.6133333333333333, 0.38666666666666666}, 2 * sizeof(double));
                }
            }
        }
    }
    double var6[2];
    if (input[0] <= 21.949999809265137) {
        if (input[0] <= 19.15000057220459) {
            if (input[0] <= 17.84999942779541) {
                memcpy(var6, (double[]){1.0, 0.0}, 2 * sizeof(double));
            } else {
                if (input[0] <= 18.050000190734863) {
                    memcpy(var6, (double[]){0.2, 0.8}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.5, 0.5}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[1] <= 91.35000228881836) {
                if (input[1] <= 34.79999923706055) {
                    memcpy(var6, (double[]){0.8085106382978723, 0.19148936170212766}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.6345811051693404, 0.36541889483065954}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 19.75) {
                    memcpy(var6, (double[]){1.0, 0.0}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.8536585365853658, 0.14634146341463414}, 2 * sizeof(double));
                }
            }
        }
    } else {
        if (input[1] <= 38.45000076293945) {
            if (input[0] <= 22.84999942779541) {
                if (input[1] <= 35.35000038146973) {
                    memcpy(var6, (double[]){0.14285714285714285, 0.8571428571428571}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.5555555555555556, 0.4444444444444444}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 23.75) {
                    memcpy(var6, (double[]){0.7083333333333334, 0.2916666666666667}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.5191545574636723, 0.4808454425363276}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[0] <= 31.949999809265137) {
                if (input[0] <= 28.65000057220459) {
                    memcpy(var6, (double[]){0.6055477197931358, 0.3944522802068641}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){0.5207939508506616, 0.4792060491493384}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 41.95000076293945) {
                    memcpy(var6, (double[]){0.6211941478845393, 0.37880585211546064}, 2 * sizeof(double));
                } else {
                    memcpy(var6, (double[]){1.0, 0.0}, 2 * sizeof(double));
                }
            }
        }
    }
    add_vectors(var5, var6, 2, var4);
    double var7[2];
    if (input[0] <= 37.45000076293945) {
        if (input[1] <= 31.449999809265137) {
            if (input[1] <= 31.34999942779541) {
                if (input[1] <= 30.84999942779541) {
                    memcpy(var7, (double[]){0.3918918918918919, 0.6081081081081081}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.5510204081632653, 0.4489795918367347}, 2 * sizeof(double));
                }
            } else {
                memcpy(var7, (double[]){0.0, 1.0}, 2 * sizeof(double));
            }
        } else {
            if (input[0] <= 36.45000076293945) {
                if (input[1] <= 93.64999771118164) {
                    memcpy(var7, (double[]){0.5880300122142732, 0.41196998778572674}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.45714285714285713, 0.5428571428571428}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 36.54999923706055) {
                    memcpy(var7, (double[]){0.37254901960784315, 0.6274509803921569}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.5422077922077922, 0.4577922077922078}, 2 * sizeof(double));
                }
            }
        }
    } else {
        if (input[0] <= 38.25) {
            if (input[0] <= 37.54999923706055) {
                if (input[1] <= 85.70000076293945) {
                    memcpy(var7, (double[]){0.5172413793103449, 0.4827586206896552}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){1.0, 0.0}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 47.25) {
                    memcpy(var7, (double[]){0.5333333333333333, 0.4666666666666667}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.8, 0.2}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[1] <= 31.65000057220459) {
                if (input[1] <= 30.84999942779541) {
                    memcpy(var7, (double[]){0.5, 0.5}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.0, 1.0}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 34.25) {
                    memcpy(var7, (double[]){0.9090909090909091, 0.09090909090909091}, 2 * sizeof(double));
                } else {
                    memcpy(var7, (double[]){0.610738255033557, 0.38926174496644295}, 2 * sizeof(double));
                }
            }
        }
    }
    add_vectors(var4, var7, 2, var3);
    double var8[2];
    if (input[0] <= 27.15000057220459) {
        if (input[0] <= 25.449999809265137) {
            if (input[1] <= 38.35000038146973) {
                if (input[1] <= 34.54999923706055) {
                    memcpy(var8, (double[]){0.5827814569536424, 0.41721854304635764}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.4020618556701031, 0.5979381443298969}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 24.84999942779541) {
                    memcpy(var8, (double[]){0.6256648936170213, 0.37433510638297873}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.5051546391752577, 0.4948453608247423}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[0] <= 25.949999809265137) {
                if (input[1] <= 52.25) {
                    memcpy(var8, (double[]){0.8181818181818182, 0.18181818181818182}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.6728971962616822, 0.32710280373831774}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 34.54999923706055) {
                    memcpy(var8, (double[]){0.2777777777777778, 0.7222222222222222}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.6617647058823529, 0.3382352941176471}, 2 * sizeof(double));
                }
            }
        }
    } else {
        if (input[0] <= 27.75) {
            if (input[1] <= 58.5) {
                if (input[1] <= 41.05000114440918) {
                    memcpy(var8, (double[]){0.5, 0.5}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.2711864406779661, 0.7288135593220338}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 27.25) {
                    memcpy(var8, (double[]){0.3684210526315789, 0.631578947368421}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.6370967741935484, 0.3629032258064516}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[0] <= 28.65000057220459) {
                if (input[0] <= 27.84999942779541) {
                    memcpy(var8, (double[]){0.7857142857142857, 0.21428571428571427}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.6779026217228464, 0.32209737827715357}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 30.75) {
                    memcpy(var8, (double[]){0.25925925925925924, 0.7407407407407407}, 2 * sizeof(double));
                } else {
                    memcpy(var8, (double[]){0.5813784764207981, 0.41862152357920196}, 2 * sizeof(double));
                }
            }
        }
    }
    add_vectors(var3, var8, 2, var2);
    double var9[2];
    if (input[1] <= 87.04999923706055) {
        if (input[1] <= 81.35000228881836) {
            if (input[1] <= 81.04999923706055) {
                if (input[0] <= 41.95000076293945) {
                    memcpy(var9, (double[]){0.5957704974865661, 0.40422950251343387}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){1.0, 0.0}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 81.14999771118164) {
                    memcpy(var9, (double[]){1.0, 0.0}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.8518518518518519, 0.14814814814814814}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[1] <= 86.14999771118164) {
                if (input[1] <= 85.64999771118164) {
                    memcpy(var9, (double[]){0.5247058823529411, 0.4752941176470588}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.3275862068965517, 0.6724137931034483}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 39.0) {
                    memcpy(var9, (double[]){0.6190476190476191, 0.38095238095238093}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.3333333333333333, 0.6666666666666666}, 2 * sizeof(double));
                }
            }
        }
    } else {
        if (input[1] <= 94.14999771118164) {
            if (input[0] <= 41.14999961853027) {
                if (input[0] <= 36.19999885559082) {
                    memcpy(var9, (double[]){0.6427503736920778, 0.3572496263079223}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.7534246575342466, 0.2465753424657534}, 2 * sizeof(double));
                }
            } else {
                if (input[0] <= 42.04999923706055) {
                    memcpy(var9, (double[]){0.1, 0.9}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){1.0, 0.0}, 2 * sizeof(double));
                }
            }
        } else {
            if (input[1] <= 94.35000228881836) {
                if (input[0] <= 29.700000762939453) {
                    memcpy(var9, (double[]){0.0, 1.0}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.5, 0.5}, 2 * sizeof(double));
                }
            } else {
                if (input[1] <= 94.54999923706055) {
                    memcpy(var9, (double[]){0.625, 0.375}, 2 * sizeof(double));
                } else {
                    memcpy(var9, (double[]){0.4473684210526316, 0.5526315789473685}, 2 * sizeof(double));
                }
            }
        }
    }
    add_vectors(var2, var9, 2, var1);
    mul_vector_number(var1, 0.2, 2, var0);
    memcpy(output, var0, 2 * sizeof(double));
}
