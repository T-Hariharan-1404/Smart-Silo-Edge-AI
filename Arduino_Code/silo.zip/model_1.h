double score(double * input) {
    double var0;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.895000457763672) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 21.274999618530273) {
                    if (input[0] <= 5.5) {
                        var0 = 35.16;
                    } else {
                        var0 = 35.42;
                    }
                } else {
                    if (input[0] <= 3.5) {
                        if (input[0] <= 2.5) {
                            var0 = 36.77;
                        } else {
                            var0 = 36.76;
                        }
                    } else {
                        if (input[1] <= 21.714999198913574) {
                            var0 = 44.31;
                        } else {
                            if (input[2] <= 181.02499389648438) {
                                if (input[0] <= 6.0) {
                                    var0 = 39.14;
                                } else {
                                    if (input[2] <= 57.21500110626221) {
                                        var0 = 39.52;
                                    } else {
                                        var0 = 39.48;
                                    }
                                }
                            } else {
                                var0 = 39.98;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 28.28499984741211) {
                    if (input[2] <= 144.02999877929688) {
                        var0 = 32.23;
                    } else {
                        var0 = 32.47;
                    }
                } else {
                    if (input[2] <= 103.48500061035156) {
                        var0 = 34.91;
                    } else {
                        if (input[2] <= 172.30500030517578) {
                            var0 = 37.89;
                        } else {
                            var0 = 36.25;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[2] <= 161.75) {
                    if (input[0] <= 5.0) {
                        if (input[1] <= 35.98499870300293) {
                            var0 = 35.17;
                        } else {
                            var0 = 35.3;
                        }
                    } else {
                        if (input[2] <= 113.84499740600586) {
                            if (input[1] <= 36.46999931335449) {
                                var0 = 31.17;
                            } else {
                                var0 = 30.22;
                            }
                        } else {
                            var0 = 32.91;
                        }
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 33.66000175476074) {
                            var0 = 31.15;
                        } else {
                            if (input[2] <= 195.8550033569336) {
                                var0 = 30.63;
                            } else {
                                if (input[0] <= 5.0) {
                                    var0 = 30.34;
                                } else {
                                    var0 = 30.13;
                                }
                            }
                        }
                    } else {
                        var0 = 32.07;
                    }
                }
            } else {
                if (input[1] <= 39.28000068664551) {
                    if (input[0] <= 4.5) {
                        var0 = 29.5;
                    } else {
                        if (input[1] <= 38.93499946594238) {
                            var0 = 28.69;
                        } else {
                            var0 = 28.17;
                        }
                    }
                } else {
                    var0 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[1] <= 30.950000762939453) {
                        var0 = 88.23;
                    } else {
                        var0 = 87.95;
                    }
                } else {
                    var0 = 84.62;
                }
            } else {
                if (input[0] <= 10.5) {
                    var0 = 80.11;
                } else {
                    var0 = 83.02;
                }
            }
        } else {
            if (input[1] <= 39.84000015258789) {
                if (input[0] <= 6.0) {
                    var0 = 78.32;
                } else {
                    var0 = 79.55;
                }
            } else {
                if (input[2] <= 177.6300048828125) {
                    if (input[0] <= 10.5) {
                        var0 = 76.33;
                    } else {
                        var0 = 75.92;
                    }
                } else {
                    if (input[1] <= 46.974998474121094) {
                        var0 = 74.09;
                    } else {
                        var0 = 74.62;
                    }
                }
            }
        }
    }
    double var1;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 76.15499877929688) {
                if (input[1] <= 24.28499984741211) {
                    var1 = 39.52;
                } else {
                    if (input[0] <= 7.5) {
                        if (input[2] <= 37.3199987411499) {
                            var1 = 36.43;
                        } else {
                            var1 = 34.91;
                        }
                    } else {
                        if (input[2] <= 35.429999113082886) {
                            var1 = 32.94;
                        } else {
                            var1 = 32.23;
                        }
                    }
                }
            } else {
                if (input[2] <= 217.63999938964844) {
                    if (input[2] <= 136.5449981689453) {
                        if (input[0] <= 5.5) {
                            if (input[1] <= 29.165000915527344) {
                                var1 = 39.14;
                            } else {
                                var1 = 38.4;
                            }
                        } else {
                            if (input[2] <= 82.32500076293945) {
                                var1 = 40.31;
                            } else {
                                if (input[0] <= 8.0) {
                                    var1 = 39.78;
                                } else {
                                    var1 = 39.48;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 21.31999969482422) {
                            var1 = 39.67;
                        } else {
                            if (input[0] <= 7.0) {
                                var1 = 35.59;
                            } else {
                                var1 = 37.89;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 222.51499938964844) {
                        var1 = 34.54;
                    } else {
                        var1 = 35.42;
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[2] <= 83.63999938964844) {
                    if (input[0] <= 4.5) {
                        var1 = 29.28;
                    } else {
                        var1 = 30.22;
                    }
                } else {
                    if (input[1] <= 34.3700008392334) {
                        var1 = 32.91;
                    } else {
                        if (input[0] <= 5.5) {
                            var1 = 35.3;
                        } else {
                            var1 = 35.16;
                        }
                    }
                }
            } else {
                if (input[2] <= 244.36000061035156) {
                    if (input[0] <= 6.5) {
                        var1 = 26.88;
                    } else {
                        if (input[2] <= 205.875) {
                            if (input[2] <= 184.36499786376953) {
                                var1 = 27.52;
                            } else {
                                var1 = 28.17;
                            }
                        } else {
                            var1 = 30.13;
                        }
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 36.540000915527344) {
                            var1 = 30.34;
                        } else {
                            var1 = 29.5;
                        }
                    } else {
                        var1 = 32.07;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 30.27500057220459) {
                var1 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var1 = 80.11;
                } else {
                    if (input[1] <= 34.53500175476074) {
                        if (input[2] <= 186.67000579833984) {
                            var1 = 84.62;
                        } else {
                            var1 = 83.02;
                        }
                    } else {
                        if (input[2] <= 195.11000061035156) {
                            var1 = 82.48;
                        } else {
                            var1 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[0] <= 5.5) {
                    var1 = 74.09;
                } else {
                    if (input[2] <= 163.86000061035156) {
                        var1 = 75.92;
                    } else {
                        var1 = 76.33;
                    }
                }
            } else {
                var1 = 80.28;
            }
        }
    }
    double var2;
    if (input[3] <= 0.5) {
        if (input[1] <= 34.97999954223633) {
            if (input[0] <= 8.5) {
                if (input[0] <= 5.5) {
                    if (input[1] <= 23.21500015258789) {
                        if (input[1] <= 21.770000457763672) {
                            if (input[0] <= 4.0) {
                                var2 = 35.16;
                            } else {
                                var2 = 35.59;
                            }
                        } else {
                            var2 = 34.54;
                        }
                    } else {
                        if (input[1] <= 33.385000228881836) {
                            if (input[2] <= 166.7449951171875) {
                                if (input[1] <= 29.165000915527344) {
                                    var2 = 39.14;
                                } else {
                                    var2 = 38.4;
                                }
                            } else {
                                var2 = 36.76;
                            }
                        } else {
                            var2 = 35.17;
                        }
                    }
                } else {
                    if (input[2] <= 225.12000274658203) {
                        if (input[1] <= 28.28499984741211) {
                            if (input[2] <= 144.02999877929688) {
                                var2 = 32.23;
                            } else {
                                var2 = 32.47;
                            }
                        } else {
                            if (input[2] <= 103.69000244140625) {
                                var2 = 34.91;
                            } else {
                                if (input[2] <= 146.86000061035156) {
                                    var2 = 33.27;
                                } else {
                                    var2 = 32.91;
                                }
                            }
                        }
                    } else {
                        var2 = 35.42;
                    }
                }
            } else {
                if (input[1] <= 29.869999885559082) {
                    if (input[1] <= 28.93000030517578) {
                        var2 = 37.89;
                    } else {
                        var2 = 40.31;
                    }
                } else {
                    if (input[2] <= 107.31999850273132) {
                        var2 = 32.94;
                    } else {
                        var2 = 36.25;
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[1] <= 39.06999969482422) {
                    if (input[2] <= 154.50500106811523) {
                        var2 = 35.3;
                    } else {
                        var2 = 35.22;
                    }
                } else {
                    if (input[2] <= 144.70000076293945) {
                        var2 = 31.5;
                    } else {
                        var2 = 29.5;
                    }
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[2] <= 257.91500091552734) {
                        if (input[2] <= 45.665000915527344) {
                            var2 = 31.17;
                        } else {
                            if (input[1] <= 37.59000015258789) {
                                if (input[0] <= 7.0) {
                                    var2 = 30.22;
                                } else {
                                    var2 = 30.13;
                                }
                            } else {
                                var2 = 30.63;
                            }
                        }
                    } else {
                        var2 = 32.07;
                    }
                } else {
                    if (input[1] <= 39.045000076293945) {
                        var2 = 28.69;
                    } else {
                        var2 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 31.25) {
                    if (input[1] <= 30.574999809265137) {
                        var2 = 80.11;
                    } else {
                        var2 = 83.02;
                    }
                } else {
                    if (input[1] <= 32.470001220703125) {
                        var2 = 87.95;
                    } else {
                        var2 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 163.4550018310547) {
                    if (input[0] <= 5.5) {
                        var2 = 82.02;
                    } else {
                        var2 = 82.48;
                    }
                } else {
                    if (input[2] <= 179.24500274658203) {
                        var2 = 76.33;
                    } else {
                        if (input[2] <= 210.9000015258789) {
                            var2 = 78.32;
                        } else {
                            var2 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                var2 = 80.28;
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[1] <= 46.974998474121094) {
                        var2 = 74.09;
                    } else {
                        var2 = 74.62;
                    }
                } else {
                    var2 = 70.41;
                }
            }
        }
    }
    double var3;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.67000102996826) {
            if (input[1] <= 26.020000457763672) {
                if (input[2] <= 138.625) {
                    if (input[1] <= 21.714999198913574) {
                        var3 = 44.31;
                    } else {
                        if (input[2] <= 109.53999710083008) {
                            if (input[1] <= 22.984999656677246) {
                                var3 = 39.52;
                            } else {
                                var3 = 39.48;
                            }
                        } else {
                            var3 = 39.14;
                        }
                    }
                } else {
                    if (input[2] <= 192.48500061035156) {
                        if (input[2] <= 164.36500549316406) {
                            var3 = 34.54;
                        } else {
                            var3 = 35.16;
                        }
                    } else {
                        if (input[0] <= 2.5) {
                            var3 = 39.67;
                        } else {
                            if (input[2] <= 211.7050018310547) {
                                var3 = 36.76;
                            } else {
                                var3 = 35.42;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 26.985000610351562) {
                        var3 = 32.23;
                    } else {
                        if (input[2] <= 147.0999984741211) {
                            if (input[2] <= 30.609999656677246) {
                                var3 = 36.43;
                            } else {
                                if (input[1] <= 27.890000343322754) {
                                    var3 = 34.8;
                                } else {
                                    var3 = 34.91;
                                }
                            }
                        } else {
                            var3 = 32.47;
                        }
                    }
                } else {
                    if (input[2] <= 109.33000183105469) {
                        var3 = 40.31;
                    } else {
                        var3 = 37.89;
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[1] <= 38.39499855041504) {
                    if (input[2] <= 58.26499938964844) {
                        var3 = 31.17;
                    } else {
                        if (input[1] <= 34.3700008392334) {
                            if (input[0] <= 7.0) {
                                var3 = 32.91;
                            } else {
                                var3 = 33.27;
                            }
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                var3 = 35.16;
                            } else {
                                var3 = 35.3;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 39.71000099182129) {
                        if (input[0] <= 4.0) {
                            var3 = 29.28;
                        } else {
                            var3 = 28.69;
                        }
                    } else {
                        var3 = 31.5;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[2] <= 216.77999877929688) {
                        if (input[1] <= 35.8650016784668) {
                            var3 = 31.15;
                        } else {
                            var3 = 30.63;
                        }
                    } else {
                        if (input[1] <= 37.81500053405762) {
                            if (input[2] <= 243.01000213623047) {
                                var3 = 30.13;
                            } else {
                                var3 = 30.34;
                            }
                        } else {
                            var3 = 29.5;
                        }
                    }
                } else {
                    var3 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[2] <= 273.96998596191406) {
                if (input[2] <= 159.2699966430664) {
                    if (input[2] <= 122.375) {
                        var3 = 84.62;
                    } else {
                        var3 = 82.48;
                    }
                } else {
                    if (input[1] <= 30.950000762939453) {
                        var3 = 88.23;
                    } else {
                        var3 = 87.95;
                    }
                }
            } else {
                if (input[0] <= 10.5) {
                    var3 = 80.11;
                } else {
                    var3 = 83.02;
                }
            }
        } else {
            if (input[2] <= 99.03999900817871) {
                var3 = 82.02;
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[2] <= 177.6300048828125) {
                        if (input[2] <= 163.86000061035156) {
                            var3 = 75.92;
                        } else {
                            var3 = 76.33;
                        }
                    } else {
                        if (input[2] <= 186.8350067138672) {
                            var3 = 74.62;
                        } else {
                            var3 = 74.09;
                        }
                    }
                } else {
                    var3 = 70.41;
                }
            }
        }
    }
    double var4;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[2] <= 217.63999938964844) {
                if (input[0] <= 7.5) {
                    if (input[1] <= 21.31999969482422) {
                        if (input[1] <= 20.734999656677246) {
                            var4 = 39.78;
                        } else {
                            var4 = 39.67;
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            if (input[0] <= 3.5) {
                                if (input[0] <= 2.5) {
                                    var4 = 34.54;
                                } else {
                                    var4 = 36.76;
                                }
                            } else {
                                var4 = 39.14;
                            }
                        } else {
                            if (input[2] <= 30.609999656677246) {
                                var4 = 36.43;
                            } else {
                                if (input[0] <= 5.5) {
                                    var4 = 35.59;
                                } else {
                                    if (input[0] <= 6.5) {
                                        var4 = 34.8;
                                    } else {
                                        var4 = 34.91;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (input[2] <= 176.31000518798828) {
                        if (input[2] <= 109.33000183105469) {
                            if (input[1] <= 25.619999885559082) {
                                var4 = 39.52;
                            } else {
                                var4 = 40.31;
                            }
                        } else {
                            var4 = 37.89;
                        }
                    } else {
                        var4 = 41.93;
                    }
                }
            } else {
                if (input[0] <= 7.5) {
                    var4 = 32.47;
                } else {
                    if (input[2] <= 222.51499938964844) {
                        var4 = 34.54;
                    } else {
                        var4 = 35.42;
                    }
                }
            }
        } else {
            if (input[0] <= 8.5) {
                if (input[1] <= 39.06999969482422) {
                    if (input[0] <= 3.5) {
                        if (input[1] <= 33.66000175476074) {
                            var4 = 31.15;
                        } else {
                            var4 = 30.34;
                        }
                    } else {
                        if (input[0] <= 5.0) {
                            if (input[1] <= 36.42499923706055) {
                                var4 = 35.17;
                            } else {
                                var4 = 35.22;
                            }
                        } else {
                            if (input[1] <= 35.7400016784668) {
                                if (input[0] <= 7.0) {
                                    var4 = 32.91;
                                } else {
                                    var4 = 33.27;
                                }
                            } else {
                                var4 = 30.63;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 54.564998626708984) {
                        var4 = 31.5;
                    } else {
                        if (input[2] <= 160.4749984741211) {
                            var4 = 29.28;
                        } else {
                            var4 = 29.5;
                        }
                    }
                }
            } else {
                if (input[2] <= 101.06499862670898) {
                    if (input[1] <= 33.63000011444092) {
                        var4 = 32.94;
                    } else {
                        var4 = 31.17;
                    }
                } else {
                    if (input[1] <= 37.03000068664551) {
                        var4 = 27.52;
                    } else {
                        var4 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 10.5) {
                if (input[2] <= 217.37998962402344) {
                    var4 = 88.23;
                } else {
                    var4 = 87.95;
                }
            } else {
                if (input[1] <= 31.860000610351562) {
                    var4 = 83.02;
                } else {
                    var4 = 84.62;
                }
            }
        } else {
            if (input[2] <= 106.5200023651123) {
                var4 = 82.02;
            } else {
                if (input[0] <= 5.5) {
                    var4 = 78.32;
                } else {
                    if (input[2] <= 202.99500274658203) {
                        var4 = 80.28;
                    } else {
                        var4 = 79.55;
                    }
                }
            }
        }
    }
    double var5;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[1] <= 22.085000038146973) {
                if (input[1] <= 21.179999351501465) {
                    var5 = 35.16;
                } else {
                    if (input[2] <= 170.62500381469727) {
                        if (input[0] <= 7.0) {
                            var5 = 44.31;
                        } else {
                            var5 = 39.52;
                        }
                    } else {
                        var5 = 39.67;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[2] <= 224.75499725341797) {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 182.3550033569336) {
                                if (input[1] <= 22.190000534057617) {
                                    var5 = 34.54;
                                } else {
                                    if (input[2] <= 77.58499908447266) {
                                        if (input[2] <= 30.609999656677246) {
                                            var5 = 36.43;
                                        } else {
                                            if (input[1] <= 27.890000343322754) {
                                                var5 = 34.8;
                                            } else {
                                                var5 = 34.91;
                                            }
                                        }
                                    } else {
                                        var5 = 36.77;
                                    }
                                }
                            } else {
                                var5 = 32.47;
                            }
                        } else {
                            var5 = 32.23;
                        }
                    } else {
                        var5 = 39.98;
                    }
                } else {
                    var5 = 40.31;
                }
            }
        } else {
            if (input[2] <= 100.63999938964844) {
                if (input[2] <= 81.82500076293945) {
                    if (input[2] <= 54.564998626708984) {
                        if (input[0] <= 10.5) {
                            if (input[2] <= 29.540000915527344) {
                                var5 = 31.17;
                            } else {
                                var5 = 31.5;
                            }
                        } else {
                            var5 = 32.94;
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            var5 = 29.28;
                        } else {
                            var5 = 30.22;
                        }
                    }
                } else {
                    if (input[1] <= 35.98499870300293) {
                        var5 = 35.17;
                    } else {
                        var5 = 35.3;
                    }
                }
            } else {
                if (input[2] <= 197.7949981689453) {
                    if (input[0] <= 10.5) {
                        if (input[0] <= 7.0) {
                            var5 = 28.69;
                        } else {
                            var5 = 28.17;
                        }
                    } else {
                        var5 = 27.52;
                    }
                } else {
                    if (input[2] <= 231.69000244140625) {
                        if (input[2] <= 210.73500061035156) {
                            var5 = 31.15;
                        } else {
                            var5 = 35.22;
                        }
                    } else {
                        if (input[2] <= 276.06500244140625) {
                            if (input[1] <= 36.540000915527344) {
                                var5 = 30.34;
                            } else {
                                var5 = 29.5;
                            }
                        } else {
                            var5 = 32.07;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[1] <= 43.11000061035156) {
                if (input[0] <= 5.5) {
                    var5 = 87.95;
                } else {
                    if (input[2] <= 195.11000061035156) {
                        var5 = 82.48;
                    } else {
                        if (input[2] <= 280.1549987792969) {
                            if (input[2] <= 257.35999298095703) {
                                var5 = 79.55;
                            } else {
                                var5 = 80.11;
                            }
                        } else {
                            var5 = 83.02;
                        }
                    }
                }
            } else {
                if (input[1] <= 48.14500045776367) {
                    if (input[0] <= 5.5) {
                        var5 = 74.09;
                    } else {
                        if (input[0] <= 10.5) {
                            var5 = 76.33;
                        } else {
                            var5 = 75.92;
                        }
                    }
                } else {
                    var5 = 80.28;
                }
            }
        } else {
            var5 = 70.41;
        }
    }
    double var6;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.695000648498535) {
                if (input[0] <= 5.5) {
                    if (input[2] <= 206.8300018310547) {
                        if (input[1] <= 24.914999961853027) {
                            if (input[1] <= 21.84000015258789) {
                                if (input[2] <= 187.12000274658203) {
                                    var6 = 35.59;
                                } else {
                                    var6 = 35.16;
                                }
                            } else {
                                if (input[2] <= 140.95999908447266) {
                                    var6 = 36.77;
                                } else {
                                    var6 = 36.76;
                                }
                            }
                        } else {
                            var6 = 39.14;
                        }
                    } else {
                        if (input[0] <= 3.5) {
                            var6 = 39.67;
                        } else {
                            var6 = 39.98;
                        }
                    }
                } else {
                    if (input[2] <= 110.34500122070312) {
                        if (input[1] <= 21.149999618530273) {
                            var6 = 39.78;
                        } else {
                            var6 = 39.52;
                        }
                    } else {
                        var6 = 44.31;
                    }
                }
            } else {
                if (input[1] <= 28.760000228881836) {
                    if (input[2] <= 147.0999984741211) {
                        if (input[1] <= 27.890000343322754) {
                            var6 = 34.8;
                        } else {
                            var6 = 34.91;
                        }
                    } else {
                        var6 = 32.47;
                    }
                } else {
                    if (input[1] <= 29.869999885559082) {
                        var6 = 40.31;
                    } else {
                        if (input[0] <= 5.0) {
                            var6 = 38.4;
                        } else {
                            if (input[1] <= 30.90499973297119) {
                                var6 = 36.25;
                            } else {
                                if (input[0] <= 10.0) {
                                    var6 = 33.27;
                                } else {
                                    var6 = 32.94;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[0] <= 10.5) {
                    if (input[2] <= 81.82500076293945) {
                        if (input[0] <= 7.5) {
                            var6 = 30.22;
                        } else {
                            var6 = 31.17;
                        }
                    } else {
                        if (input[1] <= 33.89500045776367) {
                            if (input[1] <= 33.53500175476074) {
                                var6 = 32.91;
                            } else {
                                var6 = 30.34;
                            }
                        } else {
                            if (input[1] <= 37.19499969482422) {
                                if (input[2] <= 128.65499877929688) {
                                    var6 = 35.17;
                                } else {
                                    var6 = 35.16;
                                }
                            } else {
                                var6 = 35.22;
                            }
                        }
                    }
                } else {
                    var6 = 27.52;
                }
            } else {
                if (input[0] <= 6.5) {
                    if (input[1] <= 39.45000076293945) {
                        var6 = 29.5;
                    } else {
                        var6 = 29.28;
                    }
                } else {
                    var6 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 10.5) {
                if (input[0] <= 5.5) {
                    var6 = 87.95;
                } else {
                    var6 = 88.23;
                }
            } else {
                if (input[2] <= 186.67000579833984) {
                    var6 = 84.62;
                } else {
                    var6 = 83.02;
                }
            }
        } else {
            if (input[2] <= 154.01499938964844) {
                if (input[2] <= 98.63500022888184) {
                    var6 = 82.02;
                } else {
                    var6 = 82.48;
                }
            } else {
                if (input[2] <= 183.57500457763672) {
                    if (input[2] <= 177.6300048828125) {
                        if (input[1] <= 45.295000076293945) {
                            var6 = 76.33;
                        } else {
                            var6 = 75.92;
                        }
                    } else {
                        var6 = 74.62;
                    }
                } else {
                    if (input[0] <= 6.0) {
                        var6 = 78.32;
                    } else {
                        var6 = 79.55;
                    }
                }
            }
        }
    }
    double var7;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 4.0) {
                    if (input[2] <= 192.48500061035156) {
                        if (input[0] <= 2.5) {
                            var7 = 34.54;
                        } else {
                            var7 = 35.16;
                        }
                    } else {
                        var7 = 36.76;
                    }
                } else {
                    if (input[1] <= 21.734999656677246) {
                        if (input[1] <= 20.835000038146973) {
                            var7 = 39.78;
                        } else {
                            var7 = 35.59;
                        }
                    } else {
                        if (input[0] <= 6.5) {
                            var7 = 39.98;
                        } else {
                            if (input[2] <= 57.21500110626221) {
                                var7 = 39.52;
                            } else {
                                var7 = 39.48;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 73.08499908447266) {
                    if (input[0] <= 7.0) {
                        var7 = 34.8;
                    } else {
                        if (input[1] <= 28.890000343322754) {
                            var7 = 32.23;
                        } else {
                            var7 = 32.94;
                        }
                    }
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[0] <= 10.5) {
                            if (input[1] <= 30.74000072479248) {
                                var7 = 37.89;
                            } else {
                                var7 = 38.4;
                            }
                        } else {
                            var7 = 40.31;
                        }
                    } else {
                        if (input[1] <= 27.65499973297119) {
                            var7 = 34.54;
                        } else {
                            if (input[0] <= 7.5) {
                                var7 = 32.47;
                            } else {
                                var7 = 33.27;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[0] <= 10.5) {
                    if (input[1] <= 33.3650016784668) {
                        var7 = 32.91;
                    } else {
                        if (input[2] <= 276.06500244140625) {
                            if (input[0] <= 2.5) {
                                var7 = 30.34;
                            } else {
                                if (input[1] <= 37.1200008392334) {
                                    if (input[1] <= 34.7450008392334) {
                                        var7 = 31.15;
                                    } else {
                                        var7 = 31.17;
                                    }
                                } else {
                                    var7 = 30.63;
                                }
                            }
                        } else {
                            var7 = 32.07;
                        }
                    }
                } else {
                    var7 = 27.52;
                }
            } else {
                if (input[2] <= 54.564998626708984) {
                    var7 = 31.5;
                } else {
                    if (input[2] <= 171.57500076293945) {
                        if (input[2] <= 87.68999862670898) {
                            var7 = 29.28;
                        } else {
                            var7 = 28.69;
                        }
                    } else {
                        var7 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 33.92500114440918) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 30.950000762939453) {
                    var7 = 88.23;
                } else {
                    var7 = 87.95;
                }
            } else {
                var7 = 80.11;
            }
        } else {
            if (input[1] <= 46.119998931884766) {
                if (input[2] <= 114.42500114440918) {
                    var7 = 82.02;
                } else {
                    if (input[1] <= 36.14000129699707) {
                        var7 = 79.55;
                    } else {
                        var7 = 78.32;
                    }
                }
            } else {
                if (input[1] <= 48.14500045776367) {
                    if (input[2] <= 173.06500244140625) {
                        var7 = 75.92;
                    } else {
                        var7 = 74.09;
                    }
                } else {
                    var7 = 80.28;
                }
            }
        }
    }
    double var8;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[1] <= 21.399999618530273) {
                if (input[1] <= 21.299999237060547) {
                    if (input[2] <= 156.32000350952148) {
                        var8 = 39.78;
                    } else {
                        var8 = 39.67;
                    }
                } else {
                    var8 = 44.31;
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 26.230000495910645) {
                        if (input[1] <= 23.890000343322754) {
                            if (input[0] <= 6.5) {
                                if (input[1] <= 22.190000534057617) {
                                    if (input[0] <= 3.5) {
                                        var8 = 34.54;
                                    } else {
                                        var8 = 35.59;
                                    }
                                } else {
                                    var8 = 36.77;
                                }
                            } else {
                                var8 = 39.52;
                            }
                        } else {
                            if (input[1] <= 25.730000495910645) {
                                var8 = 39.14;
                            } else {
                                var8 = 39.98;
                            }
                        }
                    } else {
                        if (input[0] <= 7.5) {
                            if (input[1] <= 27.90999984741211) {
                                var8 = 36.43;
                            } else {
                                var8 = 34.91;
                            }
                        } else {
                            var8 = 32.23;
                        }
                    }
                } else {
                    if (input[2] <= 176.31000518798828) {
                        if (input[2] <= 109.65500259399414) {
                            if (input[1] <= 26.55500030517578) {
                                var8 = 39.48;
                            } else {
                                var8 = 40.31;
                            }
                        } else {
                            var8 = 37.89;
                        }
                    } else {
                        var8 = 41.93;
                    }
                }
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[1] <= 35.75) {
                    if (input[1] <= 33.89500045776367) {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 234.93000030517578) {
                                var8 = 31.15;
                            } else {
                                var8 = 30.34;
                            }
                        } else {
                            var8 = 32.94;
                        }
                    } else {
                        if (input[1] <= 34.72999954223633) {
                            var8 = 35.17;
                        } else {
                            var8 = 35.16;
                        }
                    }
                } else {
                    if (input[0] <= 4.5) {
                        var8 = 35.22;
                    } else {
                        if (input[1] <= 38.510000228881836) {
                            if (input[0] <= 5.5) {
                                var8 = 32.07;
                            } else {
                                if (input[2] <= 45.665000915527344) {
                                    var8 = 31.17;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[0] <= 7.0) {
                                            var8 = 30.22;
                                        } else {
                                            var8 = 30.13;
                                        }
                                    } else {
                                        var8 = 30.63;
                                    }
                                }
                            }
                        } else {
                            var8 = 28.69;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 160.4749984741211) {
                        var8 = 29.28;
                    } else {
                        var8 = 29.5;
                    }
                } else {
                    var8 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 39.920000076293945) {
            if (input[1] <= 32.470001220703125) {
                if (input[0] <= 5.5) {
                    var8 = 87.95;
                } else {
                    var8 = 88.23;
                }
            } else {
                var8 = 84.62;
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                var8 = 80.28;
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[2] <= 186.8350067138672) {
                        var8 = 74.62;
                    } else {
                        var8 = 74.09;
                    }
                } else {
                    var8 = 70.41;
                }
            }
        }
    }
    double var9;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.020000457763672) {
                if (input[2] <= 221.1550064086914) {
                    if (input[0] <= 5.5) {
                        if (input[1] <= 23.890000343322754) {
                            if (input[1] <= 21.84000015258789) {
                                var9 = 35.59;
                            } else {
                                var9 = 36.77;
                            }
                        } else {
                            var9 = 39.14;
                        }
                    } else {
                        if (input[0] <= 7.5) {
                            var9 = 44.31;
                        } else {
                            var9 = 41.93;
                        }
                    }
                } else {
                    var9 = 35.42;
                }
            } else {
                if (input[1] <= 27.47000026702881) {
                    if (input[1] <= 26.795000076293945) {
                        var9 = 32.23;
                    } else {
                        if (input[2] <= 137.78499603271484) {
                            var9 = 34.8;
                        } else {
                            var9 = 34.54;
                        }
                    }
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[1] <= 28.079999923706055) {
                            var9 = 36.43;
                        } else {
                            if (input[2] <= 118.92000198364258) {
                                var9 = 38.4;
                            } else {
                                var9 = 37.89;
                            }
                        }
                    } else {
                        var9 = 33.27;
                    }
                }
            }
        } else {
            if (input[2] <= 174.34500122070312) {
                if (input[1] <= 38.125) {
                    if (input[0] <= 8.0) {
                        if (input[1] <= 34.3700008392334) {
                            var9 = 32.91;
                        } else {
                            if (input[2] <= 130.46999740600586) {
                                var9 = 35.3;
                            } else {
                                var9 = 35.16;
                            }
                        }
                    } else {
                        var9 = 31.17;
                    }
                } else {
                    if (input[2] <= 54.564998626708984) {
                        var9 = 31.5;
                    } else {
                        if (input[2] <= 118.59500122070312) {
                            var9 = 29.28;
                        } else {
                            var9 = 30.63;
                        }
                    }
                }
            } else {
                if (input[2] <= 270.79000091552734) {
                    if (input[1] <= 39.28000068664551) {
                        if (input[2] <= 205.875) {
                            if (input[0] <= 10.5) {
                                var9 = 28.17;
                            } else {
                                var9 = 27.52;
                            }
                        } else {
                            if (input[2] <= 237.73500061035156) {
                                var9 = 30.13;
                            } else {
                                var9 = 29.5;
                            }
                        }
                    } else {
                        var9 = 26.88;
                    }
                } else {
                    var9 = 32.07;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[0] <= 5.5) {
                        var9 = 87.95;
                    } else {
                        var9 = 88.23;
                    }
                } else {
                    var9 = 84.62;
                }
            } else {
                if (input[1] <= 30.574999809265137) {
                    var9 = 80.11;
                } else {
                    var9 = 83.02;
                }
            }
        } else {
            if (input[1] <= 39.41000175476074) {
                var9 = 79.55;
            } else {
                if (input[1] <= 44.15500068664551) {
                    var9 = 82.48;
                } else {
                    var9 = 82.02;
                }
            }
        }
    }
    double var10;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 6.0) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 28.5600004196167) {
                        if (input[1] <= 23.28499984741211) {
                            var10 = 36.77;
                        } else {
                            var10 = 36.76;
                        }
                    } else {
                        var10 = 38.4;
                    }
                } else {
                    if (input[2] <= 221.11000061035156) {
                        var10 = 39.67;
                    } else {
                        var10 = 39.98;
                    }
                }
            } else {
                if (input[1] <= 28.5) {
                    if (input[2] <= 47.97499942779541) {
                        var10 = 39.52;
                    } else {
                        if (input[2] <= 67.23999786376953) {
                            var10 = 32.23;
                        } else {
                            if (input[2] <= 225.12000274658203) {
                                if (input[2] <= 221.28499603271484) {
                                    if (input[0] <= 9.5) {
                                        var10 = 34.91;
                                    } else {
                                        var10 = 34.54;
                                    }
                                } else {
                                    var10 = 32.47;
                                }
                            } else {
                                var10 = 35.42;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 109.33000183105469) {
                        var10 = 40.31;
                    } else {
                        if (input[1] <= 29.609999656677246) {
                            var10 = 37.89;
                        } else {
                            var10 = 36.25;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.39499855041504) {
                if (input[1] <= 37.474998474121094) {
                    if (input[1] <= 35.94000053405762) {
                        if (input[0] <= 4.5) {
                            if (input[0] <= 2.5) {
                                var10 = 30.34;
                            } else {
                                var10 = 31.149999999999995;
                            }
                        } else {
                            if (input[1] <= 34.3700008392334) {
                                var10 = 32.91;
                            } else {
                                var10 = 35.16;
                            }
                        }
                    } else {
                        if (input[1] <= 36.65999984741211) {
                            var10 = 30.13;
                        } else {
                            var10 = 30.22;
                        }
                    }
                } else {
                    var10 = 35.3;
                }
            } else {
                if (input[1] <= 39.28000068664551) {
                    if (input[0] <= 4.5) {
                        var10 = 29.5;
                    } else {
                        if (input[0] <= 7.0) {
                            var10 = 28.69;
                        } else {
                            var10 = 28.17;
                        }
                    }
                } else {
                    var10 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 30.34000015258789) {
                    var10 = 88.23;
                } else {
                    if (input[1] <= 31.860000610351562) {
                        var10 = 83.02;
                    } else {
                        var10 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 163.4550018310547) {
                    if (input[0] <= 5.5) {
                        var10 = 82.02;
                    } else {
                        var10 = 82.48;
                    }
                } else {
                    if (input[2] <= 179.24500274658203) {
                        var10 = 76.33;
                    } else {
                        if (input[0] <= 6.0) {
                            var10 = 78.32;
                        } else {
                            var10 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 48.43499946594238) {
                if (input[0] <= 6.0) {
                    var10 = 74.09;
                } else {
                    var10 = 74.62;
                }
            } else {
                var10 = 70.41;
            }
        }
    }
    double var11;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.350000381469727) {
            if (input[2] <= 130.65500259399414) {
                if (input[2] <= 103.6500015258789) {
                    if (input[2] <= 18.05500030517578) {
                        var11 = 36.43;
                    } else {
                        if (input[1] <= 26.55500030517578) {
                            if (input[2] <= 57.21500110626221) {
                                var11 = 39.52;
                            } else {
                                var11 = 39.48;
                            }
                        } else {
                            var11 = 40.31;
                        }
                    }
                } else {
                    var11 = 44.31;
                }
            } else {
                if (input[2] <= 217.63999938964844) {
                    if (input[2] <= 212.2750015258789) {
                        if (input[1] <= 23.21500015258789) {
                            if (input[0] <= 4.0) {
                                if (input[1] <= 21.630000114440918) {
                                    var11 = 35.16;
                                } else {
                                    var11 = 34.54;
                                }
                            } else {
                                var11 = 35.59;
                            }
                        } else {
                            if (input[2] <= 166.86000061035156) {
                                var11 = 37.89;
                            } else {
                                if (input[0] <= 7.5) {
                                    var11 = 36.76;
                                } else {
                                    var11 = 36.25;
                                }
                            }
                        }
                    } else {
                        var11 = 39.67;
                    }
                } else {
                    if (input[0] <= 7.5) {
                        var11 = 32.47;
                    } else {
                        if (input[1] <= 24.119999885559082) {
                            var11 = 35.42;
                        } else {
                            var11 = 34.54;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[0] <= 2.5) {
                    var11 = 38.4;
                } else {
                    if (input[2] <= 65.70000076293945) {
                        if (input[2] <= 29.540000915527344) {
                            var11 = 31.17;
                        } else {
                            var11 = 31.5;
                        }
                    } else {
                        if (input[1] <= 33.60000038146973) {
                            if (input[2] <= 146.86000061035156) {
                                var11 = 33.27;
                            } else {
                                var11 = 32.91;
                            }
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[1] <= 34.72999954223633) {
                                    var11 = 35.17;
                                } else {
                                    var11 = 35.16;
                                }
                            } else {
                                var11 = 35.3;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 8.0) {
                    if (input[2] <= 231.69000244140625) {
                        if (input[1] <= 36.19000053405762) {
                            var11 = 31.15;
                        } else {
                            var11 = 35.22;
                        }
                    } else {
                        if (input[0] <= 3.0) {
                            var11 = 30.34;
                        } else {
                            var11 = 29.5;
                        }
                    }
                } else {
                    var11 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[0] <= 10.5) {
                if (input[0] <= 5.5) {
                    var11 = 87.95;
                } else {
                    var11 = 88.23;
                }
            } else {
                if (input[1] <= 31.860000610351562) {
                    var11 = 83.02;
                } else {
                    var11 = 84.62;
                }
            }
        } else {
            if (input[2] <= 171.34000396728516) {
                if (input[1] <= 47.28499984741211) {
                    if (input[0] <= 5.5) {
                        var11 = 82.02;
                    } else {
                        var11 = 82.48;
                    }
                } else {
                    var11 = 80.28;
                }
            } else {
                if (input[2] <= 238.1750030517578) {
                    if (input[1] <= 39.84000015258789) {
                        var11 = 78.32;
                    } else {
                        if (input[0] <= 10.5) {
                            var11 = 76.33;
                        } else {
                            var11 = 74.62;
                        }
                    }
                } else {
                    var11 = 70.41;
                }
            }
        }
    }
    double var12;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[0] <= 4.0) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 22.190000534057617) {
                        var12 = 34.54;
                    } else {
                        if (input[1] <= 23.28499984741211) {
                            var12 = 36.77;
                        } else {
                            var12 = 36.76;
                        }
                    }
                } else {
                    var12 = 39.67;
                }
            } else {
                if (input[2] <= 225.98500061035156) {
                    if (input[1] <= 22.649999618530273) {
                        if (input[0] <= 6.5) {
                            var12 = 44.31;
                        } else {
                            var12 = 39.78;
                        }
                    } else {
                        if (input[2] <= 154.1349983215332) {
                            var12 = 39.48;
                        } else {
                            var12 = 39.98;
                        }
                    }
                } else {
                    var12 = 35.42;
                }
            }
        } else {
            if (input[1] <= 38.39499855041504) {
                if (input[0] <= 2.5) {
                    var12 = 38.4;
                } else {
                    if (input[2] <= 224.375) {
                        if (input[2] <= 5.509999990463257) {
                            var12 = 36.43;
                        } else {
                            if (input[2] <= 81.82500076293945) {
                                if (input[0] <= 7.0) {
                                    var12 = 30.22;
                                } else {
                                    if (input[2] <= 35.429999113082886) {
                                        var12 = 32.94;
                                    } else {
                                        var12 = 32.23;
                                    }
                                }
                            } else {
                                if (input[2] <= 173.2699966430664) {
                                    if (input[1] <= 33.60000038146973) {
                                        var12 = 32.91;
                                    } else {
                                        if (input[1] <= 36.7549991607666) {
                                            if (input[1] <= 34.72999954223633) {
                                                var12 = 35.17;
                                            } else {
                                                var12 = 35.16;
                                            }
                                        } else {
                                            var12 = 35.3;
                                        }
                                    }
                                } else {
                                    if (input[1] <= 32.02000045776367) {
                                        if (input[2] <= 221.28499603271484) {
                                            if (input[1] <= 28.809999465942383) {
                                                var12 = 34.54;
                                            } else {
                                                var12 = 36.25;
                                            }
                                        } else {
                                            var12 = 32.47;
                                        }
                                    } else {
                                        if (input[1] <= 34.23000144958496) {
                                            var12 = 31.15;
                                        } else {
                                            var12 = 27.52;
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        var12 = 30.13;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[1] <= 39.45000076293945) {
                            var12 = 29.5;
                        } else {
                            var12 = 29.28;
                        }
                    } else {
                        var12 = 31.5;
                    }
                } else {
                    if (input[2] <= 212.5) {
                        if (input[1] <= 38.93499946594238) {
                            var12 = 28.69;
                        } else {
                            var12 = 28.17;
                        }
                    } else {
                        var12 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[2] <= 286.6800079345703) {
            if (input[0] <= 5.5) {
                if (input[1] <= 34.07500076293945) {
                    var12 = 87.95;
                } else {
                    var12 = 78.32;
                }
            } else {
                if (input[0] <= 10.5) {
                    if (input[2] <= 161.49500274658203) {
                        var12 = 82.48;
                    } else {
                        if (input[1] <= 39.80000019073486) {
                            var12 = 80.11;
                        } else {
                            var12 = 80.28;
                        }
                    }
                } else {
                    var12 = 83.02;
                }
            }
        } else {
            var12 = 70.41;
        }
    }
    double var13;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 178.7100067138672) {
                        if (input[1] <= 22.190000534057617) {
                            var13 = 34.54;
                        } else {
                            var13 = 36.77;
                        }
                    } else {
                        var13 = 39.67;
                    }
                } else {
                    if (input[2] <= 225.98500061035156) {
                        if (input[2] <= 89.34500122070312) {
                            var13 = 39.48;
                        } else {
                            if (input[0] <= 6.0) {
                                var13 = 39.98;
                            } else {
                                var13 = 39.78;
                            }
                        }
                    } else {
                        var13 = 35.42;
                    }
                }
            } else {
                if (input[0] <= 7.5) {
                    if (input[1] <= 27.47000026702881) {
                        var13 = 34.8;
                    } else {
                        if (input[0] <= 4.5) {
                            var13 = 38.4;
                        } else {
                            var13 = 36.43;
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        if (input[1] <= 29.33500099182129) {
                            var13 = 32.23;
                        } else {
                            var13 = 33.27;
                        }
                    } else {
                        var13 = 34.54;
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[1] <= 35.75) {
                    if (input[2] <= 212.93000030517578) {
                        if (input[2] <= 160.67499542236328) {
                            var13 = 32.91;
                        } else {
                            var13 = 35.16;
                        }
                    } else {
                        var13 = 30.34;
                    }
                } else {
                    if (input[0] <= 5.5) {
                        var13 = 32.07;
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[1] <= 37.59000015258789) {
                                if (input[0] <= 7.0) {
                                    var13 = 30.22;
                                } else {
                                    var13 = 30.13;
                                }
                            } else {
                                var13 = 30.63;
                            }
                        } else {
                            var13 = 31.17;
                        }
                    }
                }
            } else {
                if (input[2] <= 54.564998626708984) {
                    var13 = 31.5;
                } else {
                    if (input[0] <= 4.0) {
                        var13 = 29.28;
                    } else {
                        if (input[1] <= 38.93499946594238) {
                            var13 = 28.69;
                        } else {
                            var13 = 28.17;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[2] <= 217.37998962402344) {
                        var13 = 88.23;
                    } else {
                        var13 = 87.95;
                    }
                } else {
                    var13 = 84.62;
                }
            } else {
                if (input[1] <= 30.574999809265137) {
                    var13 = 80.11;
                } else {
                    var13 = 83.02;
                }
            }
        } else {
            if (input[1] <= 46.119998931884766) {
                if (input[2] <= 108.48000144958496) {
                    var13 = 82.02;
                } else {
                    if (input[1] <= 39.84000015258789) {
                        if (input[2] <= 210.9000015258789) {
                            var13 = 78.32;
                        } else {
                            var13 = 79.55;
                        }
                    } else {
                        var13 = 76.33;
                    }
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[2] <= 168.19000244140625) {
                        var13 = 75.92;
                    } else {
                        if (input[2] <= 186.8350067138672) {
                            var13 = 74.62;
                        } else {
                            var13 = 74.09;
                        }
                    }
                } else {
                    var13 = 70.41;
                }
            }
        }
    }
    double var14;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.505000114440918) {
                if (input[0] <= 5.5) {
                    if (input[1] <= 24.914999961853027) {
                        if (input[1] <= 21.84000015258789) {
                            if (input[0] <= 4.0) {
                                var14 = 35.16;
                            } else {
                                var14 = 35.59;
                            }
                        } else {
                            if (input[1] <= 23.28499984741211) {
                                var14 = 36.77;
                            } else {
                                var14 = 36.76;
                            }
                        }
                    } else {
                        if (input[1] <= 25.730000495910645) {
                            var14 = 39.14;
                        } else {
                            var14 = 39.98;
                        }
                    }
                } else {
                    if (input[2] <= 103.6500015258789) {
                        var14 = 39.48;
                    } else {
                        if (input[2] <= 170.30500411987305) {
                            var14 = 44.31;
                        } else {
                            var14 = 41.93;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.0) {
                    var14 = 38.4;
                } else {
                    if (input[2] <= 221.28499603271484) {
                        if (input[1] <= 30.90499973297119) {
                            if (input[1] <= 27.47000026702881) {
                                if (input[2] <= 137.78499603271484) {
                                    var14 = 34.8;
                                } else {
                                    var14 = 34.54;
                                }
                            } else {
                                if (input[1] <= 29.019999504089355) {
                                    var14 = 36.43;
                                } else {
                                    var14 = 36.25;
                                }
                            }
                        } else {
                            var14 = 32.94;
                        }
                    } else {
                        var14 = 32.47;
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[2] <= 81.4749984741211) {
                    if (input[0] <= 6.0) {
                        var14 = 29.28;
                    } else {
                        var14 = 31.17;
                    }
                } else {
                    if (input[1] <= 33.60000038146973) {
                        var14 = 32.91;
                    } else {
                        if (input[1] <= 36.7549991607666) {
                            if (input[0] <= 5.5) {
                                var14 = 35.17;
                            } else {
                                var14 = 35.16;
                            }
                        } else {
                            var14 = 35.3;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 36.540000915527344) {
                        if (input[0] <= 2.5) {
                            var14 = 30.34;
                        } else {
                            var14 = 31.15;
                        }
                    } else {
                        var14 = 29.5;
                    }
                } else {
                    if (input[0] <= 6.5) {
                        var14 = 26.88;
                    } else {
                        if (input[2] <= 205.875) {
                            if (input[1] <= 37.03000068664551) {
                                var14 = 27.52;
                            } else {
                                var14 = 28.17;
                            }
                        } else {
                            var14 = 30.13;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 33.31500053405762) {
            if (input[1] <= 30.27500057220459) {
                var14 = 88.23;
            } else {
                if (input[2] <= 280.1549987792969) {
                    var14 = 80.11;
                } else {
                    var14 = 83.02;
                }
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[1] <= 48.14500045776367) {
                    if (input[1] <= 39.84000015258789) {
                        if (input[1] <= 36.14000129699707) {
                            var14 = 79.55;
                        } else {
                            var14 = 78.32;
                        }
                    } else {
                        if (input[2] <= 177.6300048828125) {
                            if (input[0] <= 10.5) {
                                var14 = 76.33;
                            } else {
                                var14 = 75.92;
                            }
                        } else {
                            if (input[1] <= 46.974998474121094) {
                                var14 = 74.09;
                            } else {
                                var14 = 74.62;
                            }
                        }
                    }
                } else {
                    var14 = 80.28;
                }
            } else {
                var14 = 70.41;
            }
        }
    }
    double var15;
    if (input[3] <= 0.5) {
        if (input[1] <= 35.75) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 4.0) {
                    if (input[2] <= 206.8300018310547) {
                        if (input[1] <= 22.190000534057617) {
                            if (input[0] <= 2.5) {
                                var15 = 34.54;
                            } else {
                                var15 = 35.16;
                            }
                        } else {
                            if (input[1] <= 23.28499984741211) {
                                var15 = 36.77;
                            } else {
                                var15 = 36.76;
                            }
                        }
                    } else {
                        var15 = 39.67;
                    }
                } else {
                    if (input[2] <= 155.4900016784668) {
                        if (input[0] <= 7.0) {
                            var15 = 44.31;
                        } else {
                            var15 = 39.52;
                        }
                    } else {
                        if (input[1] <= 23.68000030517578) {
                            if (input[1] <= 21.295000076293945) {
                                var15 = 35.42;
                            } else {
                                var15 = 35.59;
                            }
                        } else {
                            var15 = 39.98;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.0) {
                    var15 = 38.4;
                } else {
                    if (input[0] <= 10.0) {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 194.2949981689453) {
                                if (input[0] <= 6.5) {
                                    if (input[2] <= 106.7699966430664) {
                                        var15 = 34.8;
                                    } else {
                                        var15 = 32.91;
                                    }
                                } else {
                                    if (input[2] <= 117.50499725341797) {
                                        var15 = 34.91;
                                    } else {
                                        var15 = 35.16;
                                    }
                                }
                            } else {
                                var15 = 32.47;
                            }
                        } else {
                            if (input[1] <= 29.33500099182129) {
                                var15 = 32.23;
                            } else {
                                var15 = 33.27;
                            }
                        }
                    } else {
                        if (input[1] <= 30.90499973297119) {
                            if (input[2] <= 144.9749984741211) {
                                var15 = 40.31;
                            } else {
                                if (input[2] <= 213.31499481201172) {
                                    var15 = 36.25;
                                } else {
                                    var15 = 34.54;
                                }
                            }
                        } else {
                            var15 = 32.94;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.28499984741211) {
                if (input[1] <= 37.364999771118164) {
                    if (input[1] <= 36.19000053405762) {
                        var15 = 31.170000000000005;
                    } else {
                        if (input[0] <= 7.0) {
                            var15 = 30.22;
                        } else {
                            var15 = 30.13;
                        }
                    }
                } else {
                    var15 = 32.07;
                }
            } else {
                if (input[2] <= 71.91500091552734) {
                    var15 = 31.5;
                } else {
                    if (input[2] <= 212.5) {
                        if (input[2] <= 145.9650001525879) {
                            var15 = 28.69;
                        } else {
                            var15 = 28.17;
                        }
                    } else {
                        var15 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 37.345001220703125) {
                if (input[1] <= 30.950000762939453) {
                    var15 = 88.23;
                } else {
                    var15 = 87.95;
                }
            } else {
                if (input[1] <= 44.15500068664551) {
                    var15 = 82.48;
                } else {
                    var15 = 82.02;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[0] <= 10.5) {
                    var15 = 80.28;
                } else {
                    var15 = 75.92;
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[0] <= 6.0) {
                        var15 = 74.09;
                    } else {
                        var15 = 74.62;
                    }
                } else {
                    var15 = 70.41;
                }
            }
        }
    }
    double var16;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 67.23999786376953) {
                if (input[0] <= 10.0) {
                    var16 = 32.23;
                } else {
                    var16 = 32.94;
                }
            } else {
                if (input[2] <= 211.9550018310547) {
                    if (input[2] <= 119.12500381469727) {
                        if (input[2] <= 76.15499877929688) {
                            var16 = 34.91;
                        } else {
                            if (input[0] <= 4.5) {
                                if (input[2] <= 93.02000045776367) {
                                    var16 = 36.77;
                                } else {
                                    var16 = 38.4;
                                }
                            } else {
                                if (input[1] <= 26.55500030517578) {
                                    if (input[0] <= 8.0) {
                                        var16 = 39.78;
                                    } else {
                                        var16 = 39.48;
                                    }
                                } else {
                                    var16 = 40.31;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 31.350000381469727) {
                            if (input[2] <= 197.93000030517578) {
                                if (input[0] <= 4.0) {
                                    var16 = 35.16;
                                } else {
                                    var16 = 35.59;
                                }
                            } else {
                                var16 = 36.25;
                            }
                        } else {
                            var16 = 33.27;
                        }
                    }
                } else {
                    if (input[2] <= 220.79000091552734) {
                        var16 = 41.93;
                    } else {
                        var16 = 39.98;
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[0] <= 4.5) {
                    if (input[1] <= 33.89500045776367) {
                        if (input[0] <= 2.5) {
                            var16 = 30.34;
                        } else {
                            var16 = 31.15;
                        }
                    } else {
                        if (input[1] <= 36.42499923706055) {
                            var16 = 35.17;
                        } else {
                            var16 = 35.22;
                        }
                    }
                } else {
                    if (input[1] <= 34.10500144958496) {
                        var16 = 32.91;
                    } else {
                        if (input[0] <= 10.5) {
                            if (input[1] <= 38.510000228881836) {
                                if (input[0] <= 5.5) {
                                    var16 = 32.07;
                                } else {
                                    if (input[0] <= 8.5) {
                                        if (input[1] <= 37.310001373291016) {
                                            var16 = 30.13;
                                        } else {
                                            var16 = 30.63;
                                        }
                                    } else {
                                        var16 = 31.17;
                                    }
                                }
                            } else {
                                var16 = 28.69;
                            }
                        } else {
                            var16 = 27.52;
                        }
                    }
                }
            } else {
                if (input[1] <= 39.71000099182129) {
                    if (input[2] <= 212.5) {
                        if (input[2] <= 128.61499786376953) {
                            var16 = 29.28;
                        } else {
                            var16 = 28.17;
                        }
                    } else {
                        var16 = 26.88;
                    }
                } else {
                    var16 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[0] <= 5.5) {
                var16 = 87.95;
            } else {
                if (input[1] <= 31.79500102996826) {
                    var16 = 80.11;
                } else {
                    if (input[2] <= 122.375) {
                        var16 = 84.62;
                    } else {
                        var16 = 82.48;
                    }
                }
            }
        } else {
            if (input[2] <= 177.6300048828125) {
                if (input[2] <= 99.03999900817871) {
                    var16 = 82.02;
                } else {
                    if (input[1] <= 48.14500045776367) {
                        if (input[2] <= 163.86000061035156) {
                            var16 = 75.92;
                        } else {
                            var16 = 76.33;
                        }
                    } else {
                        var16 = 80.28;
                    }
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[1] <= 46.974998474121094) {
                        var16 = 74.09;
                    } else {
                        var16 = 74.62;
                    }
                } else {
                    var16 = 70.41;
                }
            }
        }
    }
    double var17;
    if (input[3] <= 0.5) {
        if (input[1] <= 25.414999961853027) {
            if (input[0] <= 5.5) {
                if (input[1] <= 22.190000534057617) {
                    if (input[2] <= 163.57500457763672) {
                        var17 = 34.54;
                    } else {
                        var17 = 35.59;
                    }
                } else {
                    if (input[0] <= 2.5) {
                        var17 = 36.77;
                    } else {
                        var17 = 36.76;
                    }
                }
            } else {
                if (input[2] <= 103.6500015258789) {
                    if (input[2] <= 57.21500110626221) {
                        var17 = 39.52;
                    } else {
                        var17 = 39.48;
                    }
                } else {
                    if (input[1] <= 22.354999542236328) {
                        var17 = 44.31;
                    } else {
                        var17 = 41.93;
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 34.46500015258789) {
                    if (input[0] <= 10.0) {
                        if (input[2] <= 60.529998779296875) {
                            if (input[1] <= 27.47000026702881) {
                                var17 = 34.8;
                            } else {
                                var17 = 36.43;
                            }
                        } else {
                            if (input[1] <= 28.28499984741211) {
                                if (input[1] <= 27.380000114440918) {
                                    var17 = 32.23;
                                } else {
                                    var17 = 32.47;
                                }
                            } else {
                                if (input[0] <= 7.5) {
                                    if (input[1] <= 31.144999504089355) {
                                        var17 = 34.91;
                                    } else {
                                        var17 = 35.17;
                                    }
                                } else {
                                    var17 = 33.27;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 30.90499973297119) {
                            if (input[2] <= 144.9749984741211) {
                                var17 = 40.31;
                            } else {
                                if (input[1] <= 28.809999465942383) {
                                    var17 = 34.54;
                                } else {
                                    var17 = 36.25;
                                }
                            }
                        } else {
                            var17 = 32.94;
                        }
                    }
                } else {
                    if (input[0] <= 7.5) {
                        if (input[0] <= 6.5) {
                            if (input[0] <= 4.5) {
                                var17 = 35.22;
                            } else {
                                if (input[0] <= 5.5) {
                                    var17 = 32.07;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        var17 = 30.22;
                                    } else {
                                        var17 = 30.63;
                                    }
                                }
                            }
                        } else {
                            var17 = 35.16;
                        }
                    } else {
                        if (input[1] <= 35.48500061035156) {
                            var17 = 27.52;
                        } else {
                            if (input[0] <= 8.5) {
                                var17 = 30.13;
                            } else {
                                var17 = 31.17;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 160.4749984741211) {
                        var17 = 29.28;
                    } else {
                        var17 = 29.5;
                    }
                } else {
                    if (input[2] <= 212.5) {
                        var17 = 28.17;
                    } else {
                        var17 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 33.92500114440918) {
                if (input[2] <= 273.96998596191406) {
                    if (input[0] <= 5.5) {
                        var17 = 87.95;
                    } else {
                        var17 = 88.23;
                    }
                } else {
                    var17 = 80.11;
                }
            } else {
                if (input[2] <= 195.11000061035156) {
                    if (input[2] <= 98.63500022888184) {
                        var17 = 82.02;
                    } else {
                        var17 = 82.48;
                    }
                } else {
                    var17 = 79.55;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[0] <= 10.5) {
                    var17 = 80.28;
                } else {
                    var17 = 75.92;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[2] <= 186.8350067138672) {
                        var17 = 74.62;
                    } else {
                        var17 = 74.09;
                    }
                } else {
                    var17 = 70.41;
                }
            }
        }
    }
    double var18;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[2] <= 161.37999725341797) {
                if (input[1] <= 21.714999198913574) {
                    var18 = 44.31;
                } else {
                    if (input[0] <= 3.0) {
                        var18 = 36.77;
                    } else {
                        if (input[0] <= 6.0) {
                            var18 = 39.14;
                        } else {
                            if (input[2] <= 57.21500110626221) {
                                var18 = 39.52;
                            } else {
                                var18 = 39.48;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 2.5) {
                    var18 = 39.67;
                } else {
                    if (input[1] <= 25.125) {
                        if (input[0] <= 4.0) {
                            var18 = 36.76;
                        } else {
                            if (input[0] <= 6.5) {
                                var18 = 35.59;
                            } else {
                                var18 = 35.42;
                            }
                        }
                    } else {
                        var18 = 39.98;
                    }
                }
            }
        } else {
            if (input[2] <= 221.7699966430664) {
                if (input[2] <= 76.52000045776367) {
                    if (input[2] <= 21.5600004196167) {
                        var18 = 36.43;
                    } else {
                        if (input[1] <= 32.63499927520752) {
                            if (input[1] <= 26.985000610351562) {
                                var18 = 32.23;
                            } else {
                                if (input[1] <= 27.890000343322754) {
                                    var18 = 34.8;
                                } else {
                                    var18 = 34.91;
                                }
                            }
                        } else {
                            if (input[2] <= 54.915000915527344) {
                                var18 = 31.5;
                            } else {
                                var18 = 30.22;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 150.68000030517578) {
                        if (input[1] <= 33.385000228881836) {
                            if (input[0] <= 10.5) {
                                if (input[0] <= 5.5) {
                                    var18 = 38.4;
                                } else {
                                    var18 = 37.89;
                                }
                            } else {
                                var18 = 40.31;
                            }
                        } else {
                            var18 = 35.17;
                        }
                    } else {
                        if (input[0] <= 3.5) {
                            var18 = 31.15;
                        } else {
                            if (input[1] <= 28.809999465942383) {
                                var18 = 34.54;
                            } else {
                                if (input[1] <= 33.02499961853027) {
                                    var18 = 36.25;
                                } else {
                                    if (input[0] <= 5.5) {
                                        var18 = 35.22;
                                    } else {
                                        var18 = 35.16;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 38.55000114440918) {
                    if (input[1] <= 37.08500099182129) {
                        if (input[1] <= 35.10500144958496) {
                            var18 = 30.34;
                        } else {
                            var18 = 30.13;
                        }
                    } else {
                        var18 = 32.07;
                    }
                } else {
                    var18 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[2] <= 175.05999755859375) {
                if (input[2] <= 159.2699966430664) {
                    if (input[2] <= 122.375) {
                        var18 = 84.62;
                    } else {
                        var18 = 82.48;
                    }
                } else {
                    var18 = 88.23;
                }
            } else {
                if (input[2] <= 280.1549987792969) {
                    if (input[0] <= 5.5) {
                        var18 = 78.32;
                    } else {
                        if (input[2] <= 257.35999298095703) {
                            var18 = 79.55;
                        } else {
                            var18 = 80.11;
                        }
                    }
                } else {
                    var18 = 83.02;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[0] <= 10.5) {
                    var18 = 80.28;
                } else {
                    var18 = 75.92;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[1] <= 46.974998474121094) {
                        var18 = 74.09;
                    } else {
                        var18 = 74.62;
                    }
                } else {
                    var18 = 70.41;
                }
            }
        }
    }
    double var19;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.895000457763672) {
            if (input[2] <= 73.08499908447266) {
                if (input[1] <= 26.985000610351562) {
                    var19 = 32.23;
                } else {
                    if (input[1] <= 27.47000026702881) {
                        var19 = 34.8;
                    } else {
                        var19 = 36.43;
                    }
                }
            } else {
                if (input[0] <= 8.0) {
                    if (input[1] <= 27.09000015258789) {
                        if (input[2] <= 206.8300018310547) {
                            if (input[2] <= 161.37999725341797) {
                                if (input[0] <= 3.0) {
                                    var19 = 36.77;
                                } else {
                                    if (input[1] <= 22.885000228881836) {
                                        var19 = 39.78;
                                    } else {
                                        var19 = 39.14;
                                    }
                                }
                            } else {
                                if (input[1] <= 22.864999771118164) {
                                    if (input[2] <= 187.12000274658203) {
                                        var19 = 35.59;
                                    } else {
                                        var19 = 35.16;
                                    }
                                } else {
                                    var19 = 36.76;
                                }
                            }
                        } else {
                            if (input[1] <= 23.579999923706055) {
                                var19 = 39.67;
                            } else {
                                var19 = 39.98;
                            }
                        }
                    } else {
                        var19 = 32.47;
                    }
                } else {
                    if (input[1] <= 29.869999885559082) {
                        if (input[1] <= 23.625) {
                            var19 = 41.93;
                        } else {
                            if (input[2] <= 82.32500076293945) {
                                var19 = 40.31;
                            } else {
                                var19 = 39.48;
                            }
                        }
                    } else {
                        var19 = 36.25;
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 81.4749984741211) {
                    if (input[2] <= 54.564998626708984) {
                        var19 = 31.5;
                    } else {
                        var19 = 29.28;
                    }
                } else {
                    if (input[1] <= 33.60000038146973) {
                        var19 = 32.91;
                    } else {
                        if (input[1] <= 36.7549991607666) {
                            if (input[0] <= 5.5) {
                                var19 = 35.17;
                            } else {
                                var19 = 35.16;
                            }
                        } else {
                            var19 = 35.3;
                        }
                    }
                }
            } else {
                if (input[0] <= 3.5) {
                    if (input[1] <= 33.66000175476074) {
                        var19 = 31.15;
                    } else {
                        var19 = 30.34;
                    }
                } else {
                    if (input[2] <= 174.34500122070312) {
                        var19 = 30.63;
                    } else {
                        if (input[0] <= 4.5) {
                            var19 = 29.5;
                        } else {
                            if (input[2] <= 212.5) {
                                if (input[2] <= 184.36499786376953) {
                                    var19 = 27.52;
                                } else {
                                    var19 = 28.17;
                                }
                            } else {
                                var19 = 26.88;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (input[2] <= 284.63499450683594) {
            if (input[1] <= 33.92500114440918) {
                if (input[2] <= 273.96998596191406) {
                    var19 = 87.95;
                } else {
                    var19 = 80.11;
                }
            } else {
                if (input[2] <= 99.03999900817871) {
                    var19 = 82.02;
                } else {
                    if (input[1] <= 39.84000015258789) {
                        if (input[2] <= 210.9000015258789) {
                            var19 = 78.32;
                        } else {
                            var19 = 79.55;
                        }
                    } else {
                        if (input[1] <= 48.14500045776367) {
                            if (input[2] <= 182.5050048828125) {
                                if (input[0] <= 10.5) {
                                    var19 = 76.33;
                                } else {
                                    var19 = 75.92;
                                }
                            } else {
                                var19 = 74.09;
                            }
                        } else {
                            var19 = 80.28;
                        }
                    }
                }
            }
        } else {
            var19 = 70.41;
        }
    }
    double var20;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.32000160217285) {
            if (input[1] <= 26.230000495910645) {
                if (input[2] <= 225.98500061035156) {
                    if (input[0] <= 8.5) {
                        if (input[0] <= 3.5) {
                            if (input[1] <= 22.764999389648438) {
                                var20 = 39.67;
                            } else {
                                var20 = 36.76;
                            }
                        } else {
                            if (input[0] <= 4.5) {
                                var20 = 39.14;
                            } else {
                                if (input[2] <= 63.910000801086426) {
                                    var20 = 39.52;
                                } else {
                                    if (input[0] <= 6.0) {
                                        var20 = 39.98;
                                    } else {
                                        var20 = 39.78;
                                    }
                                }
                            }
                        }
                    } else {
                        var20 = 41.93;
                    }
                } else {
                    var20 = 35.42;
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[0] <= 4.0) {
                        var20 = 38.4;
                    } else {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 147.0999984741211) {
                                if (input[1] <= 27.890000343322754) {
                                    var20 = 34.8;
                                } else {
                                    var20 = 34.91;
                                }
                            } else {
                                var20 = 32.47;
                            }
                        } else {
                            if (input[1] <= 29.33500099182129) {
                                var20 = 32.23;
                            } else {
                                var20 = 33.27;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 172.30500030517578) {
                        var20 = 37.89;
                    } else {
                        var20 = 36.25;
                    }
                }
            }
        } else {
            if (input[1] <= 35.94000053405762) {
                if (input[2] <= 173.2699966430664) {
                    if (input[2] <= 128.65499877929688) {
                        var20 = 35.17;
                    } else {
                        var20 = 35.16;
                    }
                } else {
                    if (input[2] <= 221.5) {
                        var20 = 27.52;
                    } else {
                        var20 = 30.34;
                    }
                }
            } else {
                if (input[1] <= 39.71000099182129) {
                    if (input[1] <= 37.85999870300293) {
                        if (input[1] <= 36.65999984741211) {
                            var20 = 30.13;
                        } else {
                            var20 = 30.22;
                        }
                    } else {
                        if (input[1] <= 39.3700008392334) {
                            if (input[2] <= 145.9650001525879) {
                                var20 = 28.69;
                            } else {
                                var20 = 28.17;
                            }
                        } else {
                            var20 = 29.28;
                        }
                    }
                } else {
                    var20 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 33.92500114440918) {
            if (input[2] <= 276.01499938964844) {
                if (input[1] <= 30.950000762939453) {
                    var20 = 88.23;
                } else {
                    var20 = 87.95;
                }
            } else {
                var20 = 83.02;
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[2] <= 154.01499938964844) {
                    if (input[1] <= 44.15500068664551) {
                        var20 = 82.48;
                    } else {
                        var20 = 82.02;
                    }
                } else {
                    if (input[2] <= 214.16000366210938) {
                        if (input[1] <= 48.14500045776367) {
                            if (input[2] <= 177.6300048828125) {
                                if (input[0] <= 10.5) {
                                    var20 = 76.33;
                                } else {
                                    var20 = 75.92;
                                }
                            } else {
                                if (input[2] <= 186.8350067138672) {
                                    var20 = 74.62;
                                } else {
                                    var20 = 74.09;
                                }
                            }
                        } else {
                            var20 = 80.28;
                        }
                    } else {
                        var20 = 79.55;
                    }
                }
            } else {
                var20 = 70.41;
            }
        }
    }
    double var21;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.89000129699707) {
            if (input[1] <= 26.230000495910645) {
                if (input[2] <= 130.53999710083008) {
                    if (input[1] <= 20.8149995803833) {
                        var21 = 39.78;
                    } else {
                        var21 = 44.31;
                    }
                } else {
                    if (input[1] <= 22.725000381469727) {
                        if (input[1] <= 21.770000457763672) {
                            if (input[2] <= 206.34000396728516) {
                                var21 = 35.59;
                            } else {
                                var21 = 35.42;
                            }
                        } else {
                            var21 = 34.54;
                        }
                    } else {
                        if (input[0] <= 3.5) {
                            var21 = 36.76;
                        } else {
                            if (input[0] <= 7.0) {
                                if (input[2] <= 181.02499389648438) {
                                    var21 = 39.14;
                                } else {
                                    var21 = 39.98;
                                }
                            } else {
                                var21 = 41.93;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 28.454999923706055) {
                    if (input[2] <= 34.249999046325684) {
                        var21 = 36.43;
                    } else {
                        if (input[2] <= 144.02999877929688) {
                            var21 = 32.23;
                        } else {
                            var21 = 32.47;
                        }
                    }
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[2] <= 91.59000015258789) {
                            var21 = 40.31;
                        } else {
                            if (input[0] <= 5.5) {
                                var21 = 38.4;
                            } else {
                                var21 = 37.89;
                            }
                        }
                    } else {
                        if (input[1] <= 31.350000381469727) {
                            var21 = 36.25;
                        } else {
                            var21 = 33.27;
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 8.0) {
                if (input[1] <= 36.64500045776367) {
                    var21 = 35.16;
                } else {
                    if (input[1] <= 38.01500129699707) {
                        var21 = 32.07;
                    } else {
                        if (input[1] <= 38.7450008392334) {
                            var21 = 30.63;
                        } else {
                            var21 = 29.5;
                        }
                    }
                }
            } else {
                if (input[2] <= 184.36499786376953) {
                    var21 = 27.52;
                } else {
                    var21 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[1] <= 30.950000762939453) {
                        var21 = 88.23;
                    } else {
                        var21 = 87.95;
                    }
                } else {
                    var21 = 84.62;
                }
            } else {
                if (input[2] <= 280.1549987792969) {
                    var21 = 80.11;
                } else {
                    var21 = 83.02;
                }
            }
        } else {
            if (input[1] <= 46.119998931884766) {
                if (input[1] <= 44.43499946594238) {
                    if (input[2] <= 179.24500274658203) {
                        var21 = 76.33;
                    } else {
                        if (input[2] <= 210.9000015258789) {
                            var21 = 78.32;
                        } else {
                            var21 = 79.55;
                        }
                    }
                } else {
                    var21 = 82.02;
                }
            } else {
                if (input[2] <= 175.67000579833984) {
                    if (input[1] <= 48.14500045776367) {
                        var21 = 75.92;
                    } else {
                        var21 = 80.28;
                    }
                } else {
                    if (input[1] <= 48.43499946594238) {
                        if (input[2] <= 186.8350067138672) {
                            var21 = 74.62;
                        } else {
                            var21 = 74.09;
                        }
                    } else {
                        var21 = 70.41;
                    }
                }
            }
        }
    }
    double var22;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[2] <= 138.74000549316406) {
                if (input[1] <= 21.714999198913574) {
                    if (input[2] <= 110.34500122070312) {
                        var22 = 39.78;
                    } else {
                        var22 = 44.31;
                    }
                } else {
                    if (input[0] <= 7.0) {
                        if (input[2] <= 110.6449966430664) {
                            if (input[2] <= 70.875) {
                                var22 = 34.8;
                            } else {
                                var22 = 36.77;
                            }
                        } else {
                            var22 = 39.14;
                        }
                    } else {
                        if (input[2] <= 109.33000183105469) {
                            if (input[1] <= 25.619999885559082) {
                                var22 = 39.52;
                            } else {
                                var22 = 40.31;
                            }
                        } else {
                            var22 = 37.89;
                        }
                    }
                }
            } else {
                if (input[1] <= 23.21500015258789) {
                    if (input[0] <= 3.5) {
                        var22 = 34.54;
                    } else {
                        if (input[0] <= 6.5) {
                            var22 = 35.59;
                        } else {
                            var22 = 35.42;
                        }
                    }
                } else {
                    if (input[2] <= 222.14999389648438) {
                        if (input[2] <= 213.31499481201172) {
                            if (input[2] <= 202.50499725341797) {
                                var22 = 36.76;
                            } else {
                                var22 = 36.25;
                            }
                        } else {
                            var22 = 34.54;
                        }
                    } else {
                        var22 = 39.98;
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[1] <= 38.39499855041504) {
                    if (input[2] <= 81.82500076293945) {
                        if (input[1] <= 34.09999942779541) {
                            var22 = 32.94;
                        } else {
                            var22 = 30.22;
                        }
                    } else {
                        if (input[0] <= 3.0) {
                            var22 = 38.4;
                        } else {
                            if (input[0] <= 7.5) {
                                if (input[1] <= 36.7549991607666) {
                                    if (input[0] <= 5.5) {
                                        var22 = 35.17;
                                    } else {
                                        var22 = 35.16;
                                    }
                                } else {
                                    var22 = 35.3;
                                }
                            } else {
                                var22 = 33.27;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 39.27499961853027) {
                        var22 = 28.69;
                    } else {
                        var22 = 31.5;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        if (input[2] <= 234.93000030517578) {
                            var22 = 31.15;
                        } else {
                            var22 = 30.34;
                        }
                    } else {
                        var22 = 35.22;
                    }
                } else {
                    if (input[0] <= 6.5) {
                        var22 = 26.88;
                    } else {
                        if (input[0] <= 8.5) {
                            var22 = 30.13;
                        } else {
                            if (input[1] <= 37.03000068664551) {
                                var22 = 27.52;
                            } else {
                                var22 = 28.17;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.334999084472656) {
            if (input[2] <= 273.96998596191406) {
                if (input[2] <= 128.03499603271484) {
                    if (input[0] <= 6.0) {
                        var22 = 82.02;
                    } else {
                        var22 = 84.62;
                    }
                } else {
                    if (input[2] <= 217.37998962402344) {
                        var22 = 88.23;
                    } else {
                        var22 = 87.95;
                    }
                }
            } else {
                var22 = 80.11;
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                var22 = 80.28;
            } else {
                if (input[2] <= 236.56000518798828) {
                    var22 = 74.62;
                } else {
                    var22 = 70.41;
                }
            }
        }
    }
    double var23;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.350000381469727) {
            if (input[2] <= 44.33500003814697) {
                if (input[2] <= 18.05500030517578) {
                    var23 = 36.43;
                } else {
                    var23 = 39.52;
                }
            } else {
                if (input[2] <= 67.23999786376953) {
                    if (input[2] <= 60.529998779296875) {
                        var23 = 34.8;
                    } else {
                        var23 = 32.23;
                    }
                } else {
                    if (input[1] <= 22.190000534057617) {
                        if (input[1] <= 21.645000457763672) {
                            if (input[2] <= 207.1300048828125) {
                                var23 = 35.16;
                            } else {
                                var23 = 35.42;
                            }
                        } else {
                            var23 = 34.54;
                        }
                    } else {
                        if (input[0] <= 10.5) {
                            if (input[2] <= 211.33999633789062) {
                                if (input[2] <= 77.58499908447266) {
                                    var23 = 34.91;
                                } else {
                                    if (input[0] <= 6.0) {
                                        if (input[1] <= 23.28499984741211) {
                                            var23 = 36.77;
                                        } else {
                                            var23 = 36.76;
                                        }
                                    } else {
                                        var23 = 37.89;
                                    }
                                }
                            } else {
                                var23 = 39.98;
                            }
                        } else {
                            if (input[1] <= 28.809999465942383) {
                                var23 = 34.54;
                            } else {
                                var23 = 36.25;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 81.4749984741211) {
                    if (input[1] <= 39.71000099182129) {
                        var23 = 29.28;
                    } else {
                        var23 = 31.5;
                    }
                } else {
                    if (input[1] <= 33.60000038146973) {
                        if (input[0] <= 7.0) {
                            var23 = 32.91;
                        } else {
                            var23 = 33.27;
                        }
                    } else {
                        if (input[1] <= 34.72999954223633) {
                            var23 = 35.17;
                        } else {
                            var23 = 35.16;
                        }
                    }
                }
            } else {
                if (input[0] <= 7.5) {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 38.7450008392334) {
                            if (input[1] <= 33.66000175476074) {
                                var23 = 31.15;
                            } else {
                                if (input[0] <= 4.0) {
                                    var23 = 30.34;
                                } else {
                                    var23 = 30.63;
                                }
                            }
                        } else {
                            var23 = 29.5;
                        }
                    } else {
                        var23 = 32.07;
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var23 = 28.17;
                    } else {
                        var23 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[2] <= 273.96998596191406) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var23 = 87.95;
                    } else {
                        var23 = 88.23;
                    }
                } else {
                    var23 = 84.62;
                }
            } else {
                var23 = 80.11;
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[1] <= 47.28499984741211) {
                    if (input[0] <= 5.5) {
                        var23 = 82.02;
                    } else {
                        var23 = 82.48;
                    }
                } else {
                    var23 = 80.28;
                }
            } else {
                if (input[1] <= 41.52499961853027) {
                    var23 = 78.32;
                } else {
                    if (input[2] <= 241.43500518798828) {
                        if (input[2] <= 186.8350067138672) {
                            var23 = 74.62;
                        } else {
                            var23 = 74.09;
                        }
                    } else {
                        var23 = 70.41;
                    }
                }
            }
        }
    }
    double var24;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.895000457763672) {
            if (input[1] <= 26.505000114440918) {
                if (input[2] <= 90.45000076293945) {
                    if (input[0] <= 5.0) {
                        var24 = 36.77;
                    } else {
                        var24 = 39.52;
                    }
                } else {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 23.369999885559082) {
                            var24 = 39.67;
                        } else {
                            var24 = 39.14;
                        }
                    } else {
                        if (input[0] <= 6.0) {
                            var24 = 39.98;
                        } else {
                            var24 = 39.78;
                        }
                    }
                }
            } else {
                if (input[1] <= 28.5) {
                    if (input[2] <= 30.609999656677246) {
                        var24 = 36.43;
                    } else {
                        if (input[1] <= 27.260000228881836) {
                            var24 = 34.54;
                        } else {
                            if (input[2] <= 63.599998474121094) {
                                var24 = 34.8;
                            } else {
                                var24 = 34.91;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 29.609999656677246) {
                        var24 = 37.89;
                    } else {
                        var24 = 36.25;
                    }
                }
            }
        } else {
            if (input[0] <= 7.5) {
                if (input[1] <= 39.06999969482422) {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 33.72500038146973) {
                            var24 = 31.15;
                        } else {
                            if (input[2] <= 94.42499923706055) {
                                var24 = 35.17;
                            } else {
                                if (input[2] <= 154.50500106811523) {
                                    var24 = 35.3;
                                } else {
                                    var24 = 35.22;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 38.01500129699707) {
                            if (input[0] <= 6.5) {
                                if (input[0] <= 5.5) {
                                    var24 = 32.07;
                                } else {
                                    var24 = 32.91;
                                }
                            } else {
                                var24 = 35.16;
                            }
                        } else {
                            if (input[1] <= 38.510000228881836) {
                                var24 = 30.63;
                            } else {
                                var24 = 28.69;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 160.4749984741211) {
                        var24 = 29.28;
                    } else {
                        var24 = 29.5;
                    }
                }
            } else {
                if (input[0] <= 10.5) {
                    if (input[0] <= 8.5) {
                        var24 = 30.13;
                    } else {
                        var24 = 31.17;
                    }
                } else {
                    var24 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[0] <= 5.5) {
                var24 = 87.95;
            } else {
                if (input[1] <= 30.27500057220459) {
                    var24 = 88.23;
                } else {
                    if (input[1] <= 30.574999809265137) {
                        var24 = 80.11;
                    } else {
                        if (input[2] <= 259.4050064086914) {
                            if (input[2] <= 195.11000061035156) {
                                var24 = 82.48;
                            } else {
                                var24 = 79.55;
                            }
                        } else {
                            var24 = 83.02;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[2] <= 161.9000015258789) {
                    var24 = 75.92;
                } else {
                    var24 = 80.28;
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[1] <= 46.974998474121094) {
                        var24 = 74.09;
                    } else {
                        var24 = 74.62;
                    }
                } else {
                    var24 = 70.41;
                }
            }
        }
    }
    double var25;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 22.725000381469727) {
                    if (input[1] <= 22.085000038146973) {
                        if (input[2] <= 221.47500610351562) {
                            if (input[1] <= 21.31999969482422) {
                                var25 = 39.67;
                            } else {
                                if (input[2] <= 109.0550012588501) {
                                    var25 = 39.52;
                                } else {
                                    var25 = 35.59;
                                }
                            }
                        } else {
                            var25 = 35.42;
                        }
                    } else {
                        var25 = 34.54;
                    }
                } else {
                    if (input[1] <= 23.625) {
                        var25 = 41.93;
                    } else {
                        if (input[0] <= 7.0) {
                            var25 = 39.98;
                        } else {
                            var25 = 39.48;
                        }
                    }
                }
            } else {
                if (input[1] <= 28.454999923706055) {
                    if (input[0] <= 6.5) {
                        var25 = 34.8;
                    } else {
                        if (input[0] <= 7.5) {
                            var25 = 32.47;
                        } else {
                            var25 = 32.23;
                        }
                    }
                } else {
                    if (input[2] <= 44.34500002861023) {
                        var25 = 32.94;
                    } else {
                        if (input[2] <= 91.59000015258789) {
                            var25 = 40.31;
                        } else {
                            if (input[0] <= 10.5) {
                                if (input[0] <= 5.5) {
                                    var25 = 38.4;
                                } else {
                                    var25 = 37.89;
                                }
                            } else {
                                var25 = 36.25;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[1] <= 35.75) {
                    if (input[1] <= 34.72999954223633) {
                        var25 = 35.17;
                    } else {
                        var25 = 35.16;
                    }
                } else {
                    if (input[2] <= 88.04000091552734) {
                        if (input[2] <= 54.915000915527344) {
                            if (input[1] <= 37.885000228881836) {
                                var25 = 31.17;
                            } else {
                                var25 = 31.5;
                            }
                        } else {
                            var25 = 30.22;
                        }
                    } else {
                        var25 = 28.69;
                    }
                }
            } else {
                if (input[1] <= 39.28000068664551) {
                    if (input[0] <= 9.0) {
                        if (input[1] <= 39.06999969482422) {
                            if (input[1] <= 38.56500053405762) {
                                if (input[2] <= 276.06500244140625) {
                                    if (input[1] <= 33.66000175476074) {
                                        var25 = 31.15;
                                    } else {
                                        if (input[1] <= 36.03500175476074) {
                                            var25 = 30.34;
                                        } else {
                                            var25 = 30.63;
                                        }
                                    }
                                } else {
                                    var25 = 32.07;
                                }
                            } else {
                                var25 = 35.22;
                            }
                        } else {
                            var25 = 29.5;
                        }
                    } else {
                        var25 = 27.52;
                    }
                } else {
                    var25 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 46.255001068115234) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 10.5) {
                    var25 = 88.23;
                } else {
                    if (input[1] <= 31.860000610351562) {
                        var25 = 83.02;
                    } else {
                        var25 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    var25 = 82.48;
                } else {
                    if (input[2] <= 210.9000015258789) {
                        var25 = 78.32;
                    } else {
                        var25 = 79.55;
                    }
                }
            }
        } else {
            var25 = 70.41;
        }
    }
    double var26;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[2] <= 217.31999969482422) {
                if (input[0] <= 7.5) {
                    if (input[1] <= 21.399999618530273) {
                        if (input[2] <= 156.28000259399414) {
                            var26 = 44.31;
                        } else {
                            var26 = 35.16;
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            if (input[1] <= 24.914999961853027) {
                                var26 = 36.76;
                            } else {
                                var26 = 39.14;
                            }
                        } else {
                            if (input[2] <= 128.31999969482422) {
                                if (input[2] <= 63.599998474121094) {
                                    var26 = 34.8;
                                } else {
                                    var26 = 34.91;
                                }
                            } else {
                                var26 = 35.59;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 176.31000518798828) {
                        if (input[2] <= 109.65500259399414) {
                            if (input[0] <= 10.5) {
                                if (input[0] <= 8.5) {
                                    var26 = 39.52;
                                } else {
                                    var26 = 39.48;
                                }
                            } else {
                                var26 = 40.31;
                            }
                        } else {
                            var26 = 37.89;
                        }
                    } else {
                        var26 = 41.93;
                    }
                }
            } else {
                if (input[2] <= 222.51499938964844) {
                    var26 = 34.54;
                } else {
                    var26 = 35.42;
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.834999084472656) {
                    if (input[1] <= 35.94000053405762) {
                        if (input[2] <= 186.6999969482422) {
                            if (input[1] <= 34.3700008392334) {
                                if (input[0] <= 7.0) {
                                    var26 = 32.91;
                                } else {
                                    if (input[0] <= 10.0) {
                                        var26 = 33.27;
                                    } else {
                                        var26 = 32.94;
                                    }
                                }
                            } else {
                                var26 = 35.16;
                            }
                        } else {
                            if (input[2] <= 234.93000030517578) {
                                var26 = 31.15;
                            } else {
                                var26 = 30.34;
                            }
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            var26 = 35.3;
                        } else {
                            if (input[1] <= 38.510000228881836) {
                                if (input[0] <= 5.5) {
                                    var26 = 32.07;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[0] <= 7.0) {
                                            var26 = 30.22;
                                        } else {
                                            var26 = 30.13;
                                        }
                                    } else {
                                        var26 = 30.63;
                                    }
                                }
                            } else {
                                var26 = 28.69;
                            }
                        }
                    }
                } else {
                    var26 = 35.22;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        var26 = 29.28;
                    } else {
                        var26 = 29.5;
                    }
                } else {
                    if (input[0] <= 7.0) {
                        var26 = 26.88;
                    } else {
                        var26 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 31.25) {
                    if (input[1] <= 30.574999809265137) {
                        var26 = 80.11;
                    } else {
                        var26 = 83.02;
                    }
                } else {
                    if (input[1] <= 32.470001220703125) {
                        var26 = 87.95;
                    } else {
                        var26 = 84.62;
                    }
                }
            } else {
                if (input[1] <= 39.560001373291016) {
                    if (input[2] <= 210.9000015258789) {
                        var26 = 78.32;
                    } else {
                        var26 = 79.55;
                    }
                } else {
                    var26 = 82.48;
                }
            }
        } else {
            if (input[2] <= 186.8350067138672) {
                var26 = 74.62;
            } else {
                var26 = 74.09;
            }
        }
    }
    double var27;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[0] <= 3.5) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 21.699999809265137) {
                        var27 = 35.16;
                    } else {
                        if (input[2] <= 140.95999908447266) {
                            var27 = 36.77;
                        } else {
                            var27 = 36.76;
                        }
                    }
                } else {
                    var27 = 39.67;
                }
            } else {
                if (input[1] <= 21.734999656677246) {
                    if (input[1] <= 21.295000076293945) {
                        var27 = 35.42;
                    } else {
                        var27 = 35.59;
                    }
                } else {
                    if (input[2] <= 176.19499969482422) {
                        if (input[1] <= 24.72000026702881) {
                            if (input[0] <= 8.5) {
                                var27 = 39.52;
                            } else {
                                var27 = 39.48;
                            }
                        } else {
                            var27 = 39.14;
                        }
                    } else {
                        if (input[0] <= 7.0) {
                            var27 = 39.98;
                        } else {
                            var27 = 41.93;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 30.90499973297119) {
                if (input[1] <= 28.5) {
                    if (input[1] <= 26.795000076293945) {
                        var27 = 32.23;
                    } else {
                        if (input[2] <= 221.28499603271484) {
                            if (input[2] <= 30.609999656677246) {
                                var27 = 36.43;
                            } else {
                                if (input[1] <= 27.260000228881836) {
                                    var27 = 34.54;
                                } else {
                                    if (input[0] <= 6.5) {
                                        var27 = 34.8;
                                    } else {
                                        var27 = 34.91;
                                    }
                                }
                            }
                        } else {
                            var27 = 32.47;
                        }
                    }
                } else {
                    if (input[1] <= 29.609999656677246) {
                        var27 = 37.89;
                    } else {
                        var27 = 36.25;
                    }
                }
            } else {
                if (input[1] <= 39.06999969482422) {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 35.75) {
                            var27 = 31.149999999999995;
                        } else {
                            if (input[1] <= 38.44999885559082) {
                                var27 = 35.3;
                            } else {
                                var27 = 35.22;
                            }
                        }
                    } else {
                        if (input[1] <= 34.810001373291016) {
                            if (input[1] <= 32.69500160217285) {
                                if (input[0] <= 10.0) {
                                    var27 = 33.27;
                                } else {
                                    var27 = 32.94;
                                }
                            } else {
                                var27 = 32.91;
                            }
                        } else {
                            if (input[0] <= 5.5) {
                                var27 = 28.69;
                            } else {
                                if (input[0] <= 7.0) {
                                    var27 = 30.63;
                                } else {
                                    var27 = 30.13;
                                }
                            }
                        }
                    }
                } else {
                    if (input[2] <= 54.564998626708984) {
                        var27 = 31.5;
                    } else {
                        if (input[0] <= 3.5) {
                            var27 = 29.28;
                        } else {
                            var27 = 29.5;
                        }
                    }
                }
            }
        }
    } else {
        if (input[2] <= 188.45000457763672) {
            if (input[2] <= 167.15499877929688) {
                var27 = 88.23;
            } else {
                if (input[0] <= 5.5) {
                    var27 = 78.32;
                } else {
                    var27 = 80.28;
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                var27 = 74.09;
            } else {
                var27 = 70.41;
            }
        }
    }
    double var28;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 21.399999618530273) {
                if (input[1] <= 21.274999618530273) {
                    if (input[2] <= 161.19500350952148) {
                        var28 = 39.78;
                    } else {
                        var28 = 35.42;
                    }
                } else {
                    var28 = 44.31;
                }
            } else {
                if (input[0] <= 4.0) {
                    if (input[1] <= 28.5600004196167) {
                        if (input[1] <= 23.28499984741211) {
                            var28 = 36.77;
                        } else {
                            var28 = 36.76;
                        }
                    } else {
                        var28 = 38.4;
                    }
                } else {
                    if (input[1] <= 30.90499973297119) {
                        if (input[1] <= 28.5) {
                            if (input[2] <= 34.249999046325684) {
                                var28 = 36.43;
                            } else {
                                if (input[2] <= 67.23999786376953) {
                                    var28 = 32.23;
                                } else {
                                    if (input[2] <= 221.28499603271484) {
                                        if (input[0] <= 6.0) {
                                            var28 = 35.59;
                                        } else {
                                            if (input[1] <= 27.699999809265137) {
                                                var28 = 34.54;
                                            } else {
                                                var28 = 34.91;
                                            }
                                        }
                                    } else {
                                        var28 = 32.47;
                                    }
                                }
                            }
                        } else {
                            if (input[2] <= 109.33000183105469) {
                                var28 = 40.31;
                            } else {
                                if (input[1] <= 29.609999656677246) {
                                    var28 = 37.89;
                                } else {
                                    var28 = 36.25;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 71.8800036907196) {
                            var28 = 32.94;
                        } else {
                            var28 = 33.27;
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 8.0) {
                if (input[1] <= 38.125) {
                    if (input[2] <= 212.93000030517578) {
                        if (input[1] <= 34.3700008392334) {
                            var28 = 32.91;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                var28 = 35.16;
                            } else {
                                var28 = 35.3;
                            }
                        }
                    } else {
                        if (input[1] <= 35.810001373291016) {
                            var28 = 30.34;
                        } else {
                            var28 = 32.07;
                        }
                    }
                } else {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 39.06999969482422) {
                            var28 = 35.22;
                        } else {
                            if (input[2] <= 160.4749984741211) {
                                var28 = 29.28;
                            } else {
                                var28 = 29.5;
                            }
                        }
                    } else {
                        if (input[1] <= 38.510000228881836) {
                            var28 = 30.63;
                        } else {
                            if (input[1] <= 39.045000076293945) {
                                var28 = 28.69;
                            } else {
                                var28 = 26.88;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 10.5) {
                    var28 = 28.17;
                } else {
                    var28 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.27500057220459) {
                var28 = 88.23;
            } else {
                if (input[0] <= 5.5) {
                    if (input[2] <= 156.74499320983887) {
                        var28 = 82.02;
                    } else {
                        var28 = 87.95;
                    }
                } else {
                    if (input[1] <= 43.11000061035156) {
                        if (input[1] <= 30.574999809265137) {
                            var28 = 80.11;
                        } else {
                            if (input[2] <= 217.9050064086914) {
                                var28 = 82.48;
                            } else {
                                var28 = 83.02;
                            }
                        }
                    } else {
                        var28 = 76.33;
                    }
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[0] <= 10.5) {
                    var28 = 80.28;
                } else {
                    var28 = 75.92;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[1] <= 46.974998474121094) {
                        var28 = 74.09;
                    } else {
                        var28 = 74.62;
                    }
                } else {
                    var28 = 70.41;
                }
            }
        }
    }
    double var29;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 138.74000549316406) {
                if (input[1] <= 22.15499973297119) {
                    if (input[1] <= 21.149999618530273) {
                        var29 = 39.78;
                    } else {
                        var29 = 39.52;
                    }
                } else {
                    if (input[1] <= 23.09000015258789) {
                        var29 = 36.77;
                    } else {
                        if (input[1] <= 26.295000076293945) {
                            var29 = 39.48;
                        } else {
                            if (input[2] <= 118.92000198364258) {
                                var29 = 38.4;
                            } else {
                                var29 = 37.89;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 224.75499725341797) {
                    if (input[2] <= 217.63999938964844) {
                        if (input[2] <= 212.2750015258789) {
                            if (input[1] <= 23.21500015258789) {
                                if (input[2] <= 164.36500549316406) {
                                    var29 = 34.54;
                                } else {
                                    var29 = 35.16;
                                }
                            } else {
                                if (input[0] <= 7.5) {
                                    var29 = 36.76;
                                } else {
                                    var29 = 36.25;
                                }
                            }
                        } else {
                            var29 = 39.67;
                        }
                    } else {
                        if (input[0] <= 9.5) {
                            var29 = 32.47;
                        } else {
                            var29 = 34.54;
                        }
                    }
                } else {
                    if (input[2] <= 225.98500061035156) {
                        var29 = 39.98;
                    } else {
                        var29 = 35.42;
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[1] <= 35.75) {
                    if (input[1] <= 33.60000038146973) {
                        var29 = 32.91;
                    } else {
                        if (input[1] <= 34.72999954223633) {
                            var29 = 35.17;
                        } else {
                            var29 = 35.16;
                        }
                    }
                } else {
                    if (input[1] <= 38.39499855041504) {
                        if (input[2] <= 83.63999938964844) {
                            if (input[2] <= 45.665000915527344) {
                                var29 = 31.17;
                            } else {
                                var29 = 30.22;
                            }
                        } else {
                            var29 = 35.3;
                        }
                    } else {
                        if (input[2] <= 54.564998626708984) {
                            var29 = 31.5;
                        } else {
                            if (input[2] <= 87.68999862670898) {
                                var29 = 29.28;
                            } else {
                                var29 = 28.69;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[1] <= 39.06999969482422) {
                        if (input[1] <= 38.34000015258789) {
                            if (input[0] <= 6.5) {
                                if (input[0] <= 4.0) {
                                    var29 = 31.149999999999995;
                                } else {
                                    var29 = 32.07;
                                }
                            } else {
                                var29 = 30.13;
                            }
                        } else {
                            var29 = 35.22;
                        }
                    } else {
                        if (input[2] <= 244.36000061035156) {
                            var29 = 26.88;
                        } else {
                            var29 = 29.5;
                        }
                    }
                } else {
                    var29 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 41.375) {
            if (input[2] <= 200.7699966430664) {
                if (input[0] <= 10.5) {
                    var29 = 88.23;
                } else {
                    var29 = 84.62;
                }
            } else {
                if (input[2] <= 280.1549987792969) {
                    if (input[0] <= 10.5) {
                        var29 = 80.11;
                    } else {
                        var29 = 79.55;
                    }
                } else {
                    var29 = 83.02;
                }
            }
        } else {
            if (input[1] <= 48.43499946594238) {
                if (input[0] <= 6.0) {
                    var29 = 74.09;
                } else {
                    var29 = 74.62;
                }
            } else {
                var29 = 70.41;
            }
        }
    }
    double var30;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 10.5) {
                if (input[1] <= 21.19499969482422) {
                    if (input[1] <= 21.15499973297119) {
                        var30 = 35.16;
                    } else {
                        var30 = 35.42;
                    }
                } else {
                    if (input[1] <= 21.399999618530273) {
                        if (input[0] <= 4.0) {
                            var30 = 39.67;
                        } else {
                            var30 = 44.31;
                        }
                    } else {
                        if (input[2] <= 201.14500427246094) {
                            if (input[0] <= 7.5) {
                                if (input[2] <= 121.00000381469727) {
                                    if (input[1] <= 30.15000057220459) {
                                        if (input[2] <= 44.59500026702881) {
                                            var30 = 36.43;
                                        } else {
                                            var30 = 36.77;
                                        }
                                    } else {
                                        var30 = 38.4;
                                    }
                                } else {
                                    if (input[2] <= 163.57500457763672) {
                                        var30 = 34.54;
                                    } else {
                                        var30 = 35.59;
                                    }
                                }
                            } else {
                                if (input[2] <= 84.22000217437744) {
                                    var30 = 39.52;
                                } else {
                                    var30 = 37.89;
                                }
                            }
                        } else {
                            if (input[0] <= 7.0) {
                                var30 = 39.98;
                            } else {
                                var30 = 41.93;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 30.90499973297119) {
                    if (input[2] <= 144.9749984741211) {
                        var30 = 40.31;
                    } else {
                        if (input[1] <= 28.809999465942383) {
                            var30 = 34.54;
                        } else {
                            var30 = 36.25;
                        }
                    }
                } else {
                    var30 = 32.94;
                }
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        var30 = 31.15;
                    } else {
                        if (input[1] <= 38.44999885559082) {
                            var30 = 35.3;
                        } else {
                            var30 = 35.22;
                        }
                    }
                } else {
                    if (input[1] <= 35.75) {
                        if (input[2] <= 160.67499542236328) {
                            var30 = 32.91;
                        } else {
                            var30 = 35.16;
                        }
                    } else {
                        if (input[0] <= 5.5) {
                            var30 = 28.69;
                        } else {
                            if (input[0] <= 7.5) {
                                var30 = 30.63;
                            } else {
                                var30 = 31.17;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 54.564998626708984) {
                    var30 = 31.5;
                } else {
                    if (input[0] <= 3.5) {
                        var30 = 29.28;
                    } else {
                        var30 = 29.5;
                    }
                }
            }
        }
    } else {
        if (input[2] <= 280.4949951171875) {
            if (input[1] <= 34.685001373291016) {
                if (input[0] <= 6.0) {
                    var30 = 87.95;
                } else {
                    var30 = 84.62;
                }
            } else {
                if (input[2] <= 154.01499938964844) {
                    if (input[2] <= 98.63500022888184) {
                        var30 = 82.02;
                    } else {
                        var30 = 82.48;
                    }
                } else {
                    if (input[1] <= 48.14500045776367) {
                        if (input[1] <= 39.84000015258789) {
                            var30 = 78.32;
                        } else {
                            if (input[2] <= 177.6300048828125) {
                                if (input[2] <= 163.86000061035156) {
                                    var30 = 75.92;
                                } else {
                                    var30 = 76.33;
                                }
                            } else {
                                var30 = 74.62;
                            }
                        }
                    } else {
                        var30 = 80.28;
                    }
                }
            }
        } else {
            var30 = 70.41;
        }
    }
    double var31;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 8.5) {
                if (input[1] <= 21.399999618530273) {
                    if (input[1] <= 21.299999237060547) {
                        if (input[2] <= 141.97500228881836) {
                            var31 = 39.78;
                        } else {
                            if (input[2] <= 202.2550048828125) {
                                var31 = 35.16;
                            } else {
                                var31 = 39.67;
                            }
                        }
                    } else {
                        var31 = 44.31;
                    }
                } else {
                    if (input[2] <= 47.97499942779541) {
                        if (input[1] <= 24.769999504089355) {
                            var31 = 39.52;
                        } else {
                            var31 = 36.43;
                        }
                    } else {
                        if (input[2] <= 67.23999786376953) {
                            var31 = 32.23;
                        } else {
                            if (input[1] <= 30.570000648498535) {
                                if (input[2] <= 112.84000396728516) {
                                    if (input[1] <= 25.295000076293945) {
                                        var31 = 36.77;
                                    } else {
                                        var31 = 34.91;
                                    }
                                } else {
                                    if (input[2] <= 163.57500457763672) {
                                        var31 = 34.54;
                                    } else {
                                        var31 = 35.59;
                                    }
                                }
                            } else {
                                var31 = 38.4;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 29.869999885559082) {
                    if (input[2] <= 149.30500411987305) {
                        if (input[0] <= 10.5) {
                            var31 = 39.48;
                        } else {
                            var31 = 40.31;
                        }
                    } else {
                        var31 = 41.93;
                    }
                } else {
                    var31 = 36.25;
                }
            }
        } else {
            if (input[0] <= 7.5) {
                if (input[1] <= 38.125) {
                    if (input[1] <= 35.75) {
                        if (input[2] <= 182.67499542236328) {
                            var31 = 32.91;
                        } else {
                            var31 = 31.15;
                        }
                    } else {
                        var31 = 35.3;
                    }
                } else {
                    if (input[1] <= 38.7450008392334) {
                        var31 = 30.63;
                    } else {
                        if (input[1] <= 39.45000076293945) {
                            var31 = 29.5;
                        } else {
                            var31 = 29.28;
                        }
                    }
                }
            } else {
                if (input[2] <= 184.36499786376953) {
                    var31 = 27.52;
                } else {
                    var31 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 5.5) {
                    var31 = 87.95;
                } else {
                    if (input[0] <= 10.5) {
                        var31 = 80.11;
                    } else {
                        if (input[2] <= 186.67000579833984) {
                            var31 = 84.62;
                        } else {
                            var31 = 83.02;
                        }
                    }
                }
            } else {
                if (input[1] <= 40.885000228881836) {
                    if (input[1] <= 36.14000129699707) {
                        var31 = 79.55;
                    } else {
                        var31 = 78.32;
                    }
                } else {
                    var31 = 82.02;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                var31 = 80.28;
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[0] <= 6.0) {
                        var31 = 74.09;
                    } else {
                        var31 = 74.62;
                    }
                } else {
                    var31 = 70.41;
                }
            }
        }
    }
    double var32;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.32000160217285) {
            if (input[2] <= 76.15499877929688) {
                if (input[0] <= 7.5) {
                    if (input[0] <= 6.5) {
                        var32 = 34.8;
                    } else {
                        var32 = 34.91;
                    }
                } else {
                    if (input[1] <= 28.890000343322754) {
                        var32 = 32.23;
                    } else {
                        var32 = 32.94;
                    }
                }
            } else {
                if (input[2] <= 161.49500274658203) {
                    if (input[2] <= 83.75500106811523) {
                        if (input[1] <= 26.55500030517578) {
                            var32 = 39.48;
                        } else {
                            var32 = 40.31;
                        }
                    } else {
                        if (input[1] <= 23.890000343322754) {
                            var32 = 36.77;
                        } else {
                            if (input[1] <= 27.09500026702881) {
                                var32 = 39.14;
                            } else {
                                if (input[1] <= 30.74000072479248) {
                                    var32 = 37.89;
                                } else {
                                    var32 = 38.4;
                                }
                            }
                        }
                    }
                } else {
                    if (input[2] <= 222.14999389648438) {
                        if (input[2] <= 217.31999969482422) {
                            if (input[2] <= 211.9550018310547) {
                                if (input[2] <= 192.48500061035156) {
                                    if (input[0] <= 4.0) {
                                        var32 = 35.16;
                                    } else {
                                        var32 = 35.59;
                                    }
                                } else {
                                    if (input[1] <= 27.429999351501465) {
                                        var32 = 36.76;
                                    } else {
                                        var32 = 36.25;
                                    }
                                }
                            } else {
                                var32 = 41.93;
                            }
                        } else {
                            var32 = 34.54;
                        }
                    } else {
                        var32 = 39.98;
                    }
                }
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[2] <= 165.7750015258789) {
                    if (input[1] <= 36.7549991607666) {
                        if (input[0] <= 5.5) {
                            var32 = 35.17;
                        } else {
                            var32 = 35.16;
                        }
                    } else {
                        var32 = 35.3;
                    }
                } else {
                    if (input[1] <= 38.56500053405762) {
                        if (input[0] <= 10.0) {
                            if (input[2] <= 276.06500244140625) {
                                if (input[2] <= 195.8550033569336) {
                                    var32 = 30.63;
                                } else {
                                    if (input[2] <= 243.01000213623047) {
                                        var32 = 30.13;
                                    } else {
                                        var32 = 30.34;
                                    }
                                }
                            } else {
                                var32 = 32.07;
                            }
                        } else {
                            var32 = 27.52;
                        }
                    } else {
                        var32 = 35.22;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 160.4749984741211) {
                        var32 = 29.28;
                    } else {
                        var32 = 29.5;
                    }
                } else {
                    var32 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[0] <= 5.5) {
                        var32 = 87.95;
                    } else {
                        var32 = 88.23;
                    }
                } else {
                    var32 = 84.62;
                }
            } else {
                if (input[0] <= 10.5) {
                    var32 = 80.11;
                } else {
                    var32 = 83.02;
                }
            }
        } else {
            if (input[1] <= 45.07499885559082) {
                if (input[0] <= 10.5) {
                    var32 = 76.33;
                } else {
                    var32 = 79.55;
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[1] <= 46.974998474121094) {
                        var32 = 74.09;
                    } else {
                        var32 = 74.62;
                    }
                } else {
                    var32 = 70.41;
                }
            }
        }
    }
    double var33;
    if (input[3] <= 0.5) {
        if (input[1] <= 34.46500015258789) {
            if (input[2] <= 136.86500549316406) {
                if (input[0] <= 7.5) {
                    if (input[2] <= 94.32500076293945) {
                        if (input[0] <= 3.0) {
                            var33 = 36.77;
                        } else {
                            if (input[0] <= 5.0) {
                                var33 = 35.17;
                            } else {
                                if (input[1] <= 27.890000343322754) {
                                    var33 = 34.8;
                                } else {
                                    var33 = 34.91;
                                }
                            }
                        }
                    } else {
                        if (input[0] <= 3.0) {
                            var33 = 38.4;
                        } else {
                            if (input[1] <= 22.885000228881836) {
                                var33 = 39.78;
                            } else {
                                var33 = 39.14;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 109.65500259399414) {
                        if (input[1] <= 26.55500030517578) {
                            if (input[1] <= 22.984999656677246) {
                                var33 = 39.52;
                            } else {
                                var33 = 39.48;
                            }
                        } else {
                            var33 = 40.31;
                        }
                    } else {
                        var33 = 37.89;
                    }
                }
            } else {
                if (input[1] <= 27.09000015258789) {
                    if (input[2] <= 206.8300018310547) {
                        if (input[1] <= 23.21500015258789) {
                            if (input[0] <= 2.5) {
                                var33 = 34.54;
                            } else {
                                if (input[0] <= 4.0) {
                                    var33 = 35.16;
                                } else {
                                    var33 = 35.59;
                                }
                            }
                        } else {
                            var33 = 36.76;
                        }
                    } else {
                        if (input[2] <= 225.98500061035156) {
                            if (input[1] <= 23.579999923706055) {
                                var33 = 39.67;
                            } else {
                                var33 = 39.98;
                            }
                        } else {
                            var33 = 35.42;
                        }
                    }
                } else {
                    if (input[1] <= 30.195000648498535) {
                        var33 = 32.47;
                    } else {
                        if (input[2] <= 146.86000061035156) {
                            var33 = 33.27;
                        } else {
                            var33 = 32.91;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[2] <= 134.86999893188477) {
                    if (input[2] <= 54.564998626708984) {
                        if (input[1] <= 37.885000228881836) {
                            var33 = 31.17;
                        } else {
                            var33 = 31.5;
                        }
                    } else {
                        if (input[2] <= 87.68999862670898) {
                            var33 = 29.28;
                        } else {
                            var33 = 28.69;
                        }
                    }
                } else {
                    var33 = 35.16;
                }
            } else {
                if (input[2] <= 244.36000061035156) {
                    if (input[1] <= 37.14000129699707) {
                        var33 = 27.52;
                    } else {
                        var33 = 26.88;
                    }
                } else {
                    if (input[1] <= 38.52000045776367) {
                        var33 = 32.07;
                    } else {
                        var33 = 29.5;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.685001373291016) {
                if (input[1] <= 32.470001220703125) {
                    if (input[1] <= 30.950000762939453) {
                        var33 = 88.23;
                    } else {
                        var33 = 87.95;
                    }
                } else {
                    var33 = 84.62;
                }
            } else {
                if (input[1] <= 40.885000228881836) {
                    var33 = 78.32;
                } else {
                    var33 = 82.02;
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[2] <= 168.19000244140625) {
                    var33 = 75.92;
                } else {
                    if (input[2] <= 186.8350067138672) {
                        var33 = 74.62;
                    } else {
                        var33 = 74.09;
                    }
                }
            } else {
                var33 = 80.28;
            }
        }
    }
    double var34;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[1] <= 26.020000457763672) {
                if (input[2] <= 162.1699981689453) {
                    if (input[0] <= 3.0) {
                        var34 = 36.77;
                    } else {
                        if (input[0] <= 5.5) {
                            var34 = 39.14;
                        } else {
                            if (input[1] <= 22.085000038146973) {
                                var34 = 39.78;
                            } else {
                                var34 = 39.48;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 207.1300048828125) {
                        var34 = 35.16;
                    } else {
                        var34 = 35.42;
                    }
                }
            } else {
                if (input[1] <= 28.5) {
                    if (input[1] <= 28.28499984741211) {
                        if (input[0] <= 10.0) {
                            if (input[0] <= 7.5) {
                                var34 = 32.47;
                            } else {
                                var34 = 32.23;
                            }
                        } else {
                            var34 = 34.54;
                        }
                    } else {
                        var34 = 34.91;
                    }
                } else {
                    if (input[2] <= 172.30500030517578) {
                        if (input[0] <= 5.5) {
                            var34 = 38.4;
                        } else {
                            var34 = 37.89;
                        }
                    } else {
                        var34 = 36.25;
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 81.82500076293945) {
                    if (input[2] <= 54.564998626708984) {
                        if (input[0] <= 6.0) {
                            var34 = 31.5;
                        } else {
                            var34 = 31.17;
                        }
                    } else {
                        if (input[2] <= 70.68999862670898) {
                            var34 = 29.28;
                        } else {
                            var34 = 30.22;
                        }
                    }
                } else {
                    if (input[1] <= 36.7549991607666) {
                        if (input[2] <= 128.65499877929688) {
                            var34 = 35.17;
                        } else {
                            var34 = 35.16;
                        }
                    } else {
                        var34 = 35.3;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 38.7450008392334) {
                            if (input[2] <= 216.77999877929688) {
                                if (input[1] <= 35.8650016784668) {
                                    var34 = 31.15;
                                } else {
                                    var34 = 30.63;
                                }
                            } else {
                                if (input[0] <= 5.0) {
                                    var34 = 30.34;
                                } else {
                                    var34 = 30.13;
                                }
                            }
                        } else {
                            var34 = 29.5;
                        }
                    } else {
                        var34 = 32.07;
                    }
                } else {
                    var34 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[2] <= 253.2199935913086) {
                if (input[1] <= 39.560001373291016) {
                    if (input[2] <= 210.9000015258789) {
                        var34 = 78.32;
                    } else {
                        var34 = 79.55;
                    }
                } else {
                    var34 = 82.48;
                }
            } else {
                if (input[1] <= 31.25) {
                    var34 = 83.02;
                } else {
                    var34 = 87.95;
                }
            }
        } else {
            if (input[0] <= 5.5) {
                var34 = 74.09;
            } else {
                if (input[0] <= 10.5) {
                    var34 = 76.33;
                } else {
                    var34 = 75.92;
                }
            }
        }
    }
    double var35;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[2] <= 211.9550018310547) {
                if (input[2] <= 76.15499877929688) {
                    if (input[1] <= 24.28499984741211) {
                        var35 = 39.52;
                    } else {
                        if (input[0] <= 7.5) {
                            if (input[1] <= 27.90999984741211) {
                                var35 = 36.43;
                            } else {
                                var35 = 34.91;
                            }
                        } else {
                            if (input[2] <= 35.429999113082886) {
                                var35 = 32.94;
                            } else {
                                var35 = 32.23;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 136.75) {
                        if (input[1] <= 22.649999618530273) {
                            var35 = 44.31;
                        } else {
                            if (input[0] <= 6.5) {
                                if (input[2] <= 118.80499649047852) {
                                    var35 = 38.4;
                                } else {
                                    var35 = 39.14;
                                }
                            } else {
                                if (input[0] <= 10.5) {
                                    var35 = 39.48;
                                } else {
                                    var35 = 40.31;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 192.48500061035156) {
                            if (input[0] <= 6.5) {
                                if (input[2] <= 163.57500457763672) {
                                    var35 = 34.54;
                                } else {
                                    if (input[1] <= 21.27999973297119) {
                                        var35 = 35.16;
                                    } else {
                                        var35 = 35.59;
                                    }
                                }
                            } else {
                                var35 = 33.27;
                            }
                        } else {
                            if (input[1] <= 27.429999351501465) {
                                var35 = 36.76;
                            } else {
                                var35 = 36.25;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 7.0) {
                    var35 = 39.98;
                } else {
                    var35 = 41.93;
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[1] <= 36.7400016784668) {
                            if (input[2] <= 234.93000030517578) {
                                var35 = 31.15;
                            } else {
                                var35 = 30.34;
                            }
                        } else {
                            var35 = 29.28;
                        }
                    } else {
                        var35 = 31.5;
                    }
                } else {
                    if (input[2] <= 231.69000244140625) {
                        if (input[1] <= 35.98499870300293) {
                            var35 = 35.17;
                        } else {
                            if (input[1] <= 38.44999885559082) {
                                var35 = 35.3;
                            } else {
                                var35 = 35.22;
                            }
                        }
                    } else {
                        var35 = 29.5;
                    }
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[0] <= 7.5) {
                        if (input[2] <= 118.94500350952148) {
                            var35 = 30.22;
                        } else {
                            var35 = 30.63;
                        }
                    } else {
                        var35 = 31.17;
                    }
                } else {
                    if (input[2] <= 212.5) {
                        if (input[1] <= 38.93499946594238) {
                            var35 = 28.69;
                        } else {
                            var35 = 28.17;
                        }
                    } else {
                        var35 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.34000015258789) {
            if (input[1] <= 30.34000015258789) {
                var35 = 88.23;
            } else {
                if (input[0] <= 5.5) {
                    if (input[2] <= 114.42500114440918) {
                        var35 = 82.02;
                    } else {
                        var35 = 78.32;
                    }
                } else {
                    if (input[2] <= 122.375) {
                        var35 = 84.62;
                    } else {
                        if (input[1] <= 36.73500061035156) {
                            var35 = 83.02;
                        } else {
                            var35 = 82.48;
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 6.0) {
                var35 = 70.41;
            } else {
                var35 = 75.92;
            }
        }
    }
    double var36;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 162.28500366210938) {
                if (input[2] <= 73.08499908447266) {
                    if (input[2] <= 47.97499942779541) {
                        if (input[1] <= 24.769999504089355) {
                            var36 = 39.52;
                        } else {
                            var36 = 36.43;
                        }
                    } else {
                        var36 = 32.23;
                    }
                } else {
                    if (input[2] <= 98.61000061035156) {
                        if (input[0] <= 10.5) {
                            if (input[1] <= 22.085000038146973) {
                                var36 = 39.78;
                            } else {
                                var36 = 39.48;
                            }
                        } else {
                            var36 = 40.31;
                        }
                    } else {
                        if (input[1] <= 27.09500026702881) {
                            var36 = 39.14;
                        } else {
                            if (input[0] <= 5.5) {
                                var36 = 38.4;
                            } else {
                                var36 = 37.89;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 26.274999618530273) {
                        if (input[1] <= 22.739999771118164) {
                            if (input[2] <= 207.1300048828125) {
                                var36 = 35.16;
                            } else {
                                var36 = 35.42;
                            }
                        } else {
                            var36 = 36.76;
                        }
                    } else {
                        var36 = 32.47;
                    }
                } else {
                    if (input[2] <= 211.9550018310547) {
                        var36 = 36.25;
                    } else {
                        var36 = 41.93;
                    }
                }
            }
        } else {
            if (input[0] <= 10.5) {
                if (input[2] <= 218.81500244140625) {
                    if (input[2] <= 83.63999938964844) {
                        if (input[2] <= 54.564998626708984) {
                            if (input[0] <= 6.0) {
                                var36 = 31.5;
                            } else {
                                var36 = 31.17;
                            }
                        } else {
                            if (input[1] <= 38.295000076293945) {
                                var36 = 30.22;
                            } else {
                                var36 = 29.28;
                            }
                        }
                    } else {
                        if (input[0] <= 5.0) {
                            if (input[2] <= 154.50500106811523) {
                                var36 = 35.3;
                            } else {
                                var36 = 35.22;
                            }
                        } else {
                            if (input[1] <= 36.8700008392334) {
                                if (input[1] <= 34.3700008392334) {
                                    var36 = 32.91;
                                } else {
                                    var36 = 35.16;
                                }
                            } else {
                                var36 = 30.63;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 38.55000114440918) {
                        if (input[2] <= 276.06500244140625) {
                            if (input[0] <= 5.0) {
                                var36 = 30.34;
                            } else {
                                var36 = 30.13;
                            }
                        } else {
                            var36 = 32.07;
                        }
                    } else {
                        var36 = 26.88;
                    }
                }
            } else {
                var36 = 27.52;
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[1] <= 43.11000061035156) {
                if (input[1] <= 30.574999809265137) {
                    var36 = 80.11;
                } else {
                    if (input[2] <= 122.375) {
                        var36 = 84.62;
                    } else {
                        if (input[1] <= 36.73500061035156) {
                            var36 = 83.02;
                        } else {
                            var36 = 82.48;
                        }
                    }
                }
            } else {
                if (input[2] <= 171.34000396728516) {
                    if (input[0] <= 5.5) {
                        var36 = 82.02;
                    } else {
                        var36 = 80.28;
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var36 = 76.33;
                    } else {
                        var36 = 74.62;
                    }
                }
            }
        } else {
            var36 = 70.41;
        }
    }
    double var37;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[0] <= 3.0) {
                if (input[1] <= 22.190000534057617) {
                    var37 = 34.54;
                } else {
                    var37 = 36.77;
                }
            } else {
                if (input[2] <= 225.98500061035156) {
                    if (input[0] <= 5.5) {
                        if (input[1] <= 25.730000495910645) {
                            var37 = 39.14;
                        } else {
                            var37 = 39.98;
                        }
                    } else {
                        if (input[0] <= 6.5) {
                            var37 = 44.31;
                        } else {
                            if (input[0] <= 8.0) {
                                var37 = 39.78;
                            } else {
                                var37 = 41.93;
                            }
                        }
                    }
                } else {
                    var37 = 35.42;
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[2] <= 173.2699966430664) {
                    if (input[0] <= 7.5) {
                        if (input[0] <= 6.5) {
                            if (input[0] <= 5.0) {
                                if (input[1] <= 35.98499870300293) {
                                    var37 = 35.17;
                                } else {
                                    var37 = 35.3;
                                }
                            } else {
                                if (input[2] <= 113.84499740600586) {
                                    var37 = 30.22;
                                } else {
                                    var37 = 32.91;
                                }
                            }
                        } else {
                            if (input[1] <= 27.90999984741211) {
                                var37 = 36.43;
                            } else {
                                if (input[1] <= 31.914999961853027) {
                                    var37 = 34.91;
                                } else {
                                    var37 = 35.16;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 34.07500076293945) {
                            if (input[1] <= 28.890000343322754) {
                                var37 = 32.23;
                            } else {
                                if (input[1] <= 31.70500087738037) {
                                    var37 = 32.94;
                                } else {
                                    var37 = 33.27;
                                }
                            }
                        } else {
                            var37 = 31.17;
                        }
                    }
                } else {
                    if (input[1] <= 32.19000053405762) {
                        if (input[1] <= 29.394999504089355) {
                            var37 = 32.47;
                        } else {
                            var37 = 36.25;
                        }
                    } else {
                        if (input[2] <= 221.5) {
                            var37 = 27.52;
                        } else {
                            var37 = 30.34;
                        }
                    }
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    var37 = 30.63;
                } else {
                    if (input[0] <= 4.0) {
                        var37 = 29.28;
                    } else {
                        var37 = 28.69;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.27500057220459) {
                var37 = 88.23;
            } else {
                if (input[1] <= 34.53500175476074) {
                    if (input[2] <= 273.96998596191406) {
                        if (input[2] <= 180.48499298095703) {
                            var37 = 84.62;
                        } else {
                            var37 = 87.95;
                        }
                    } else {
                        if (input[2] <= 280.1549987792969) {
                            var37 = 80.11;
                        } else {
                            var37 = 83.02;
                        }
                    }
                } else {
                    if (input[2] <= 169.4000015258789) {
                        if (input[0] <= 5.5) {
                            var37 = 82.02;
                        } else {
                            var37 = 82.48;
                        }
                    } else {
                        if (input[2] <= 210.9000015258789) {
                            var37 = 78.32;
                        } else {
                            var37 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[2] <= 168.19000244140625) {
                    var37 = 75.92;
                } else {
                    if (input[1] <= 46.974998474121094) {
                        var37 = 74.09;
                    } else {
                        var37 = 74.62;
                    }
                }
            } else {
                var37 = 70.41;
            }
        }
    }
    double var38;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[2] <= 211.9550018310547) {
                if (input[1] <= 20.69499969482422) {
                    var38 = 39.78;
                } else {
                    if (input[1] <= 27.47000026702881) {
                        if (input[2] <= 44.33500003814697) {
                            var38 = 39.52;
                        } else {
                            if (input[0] <= 7.0) {
                                if (input[2] <= 192.48500061035156) {
                                    if (input[2] <= 112.84000396728516) {
                                        if (input[2] <= 70.875) {
                                            var38 = 34.8;
                                        } else {
                                            var38 = 36.77;
                                        }
                                    } else {
                                        if (input[0] <= 2.5) {
                                            var38 = 34.54;
                                        } else {
                                            if (input[1] <= 21.27999973297119) {
                                                var38 = 35.16;
                                            } else {
                                                var38 = 35.59;
                                            }
                                        }
                                    }
                                } else {
                                    var38 = 36.76;
                                }
                            } else {
                                var38 = 32.23;
                            }
                        }
                    } else {
                        if (input[0] <= 9.5) {
                            var38 = 36.43;
                        } else {
                            if (input[1] <= 29.869999885559082) {
                                var38 = 40.31;
                            } else {
                                var38 = 36.25;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 21.19499969482422) {
                    var38 = 35.42;
                } else {
                    if (input[0] <= 10.5) {
                        if (input[0] <= 7.0) {
                            if (input[2] <= 221.11000061035156) {
                                var38 = 39.67;
                            } else {
                                var38 = 39.98;
                            }
                        } else {
                            var38 = 41.93;
                        }
                    } else {
                        var38 = 34.54;
                    }
                }
            }
        } else {
            if (input[2] <= 100.63999938964844) {
                if (input[2] <= 83.63999938964844) {
                    if (input[0] <= 10.5) {
                        if (input[2] <= 54.564998626708984) {
                            if (input[1] <= 37.885000228881836) {
                                var38 = 31.17;
                            } else {
                                var38 = 31.5;
                            }
                        } else {
                            if (input[0] <= 4.5) {
                                var38 = 29.28;
                            } else {
                                var38 = 30.22;
                            }
                        }
                    } else {
                        var38 = 32.94;
                    }
                } else {
                    var38 = 35.3;
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[2] <= 257.91500091552734) {
                        if (input[0] <= 5.5) {
                            var38 = 28.69;
                        } else {
                            if (input[0] <= 7.0) {
                                var38 = 30.63;
                            } else {
                                var38 = 30.13;
                            }
                        }
                    } else {
                        var38 = 32.07;
                    }
                } else {
                    if (input[1] <= 37.03000068664551) {
                        var38 = 27.52;
                    } else {
                        var38 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[2] <= 175.05999755859375) {
            if (input[1] <= 31.560001373291016) {
                var38 = 88.23;
            } else {
                if (input[0] <= 6.0) {
                    var38 = 82.02;
                } else {
                    var38 = 84.62;
                }
            }
        } else {
            if (input[2] <= 210.9000015258789) {
                var38 = 78.32;
            } else {
                if (input[1] <= 33.250000953674316) {
                    var38 = 80.11;
                } else {
                    var38 = 79.55;
                }
            }
        }
    }
    double var39;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 22.725000381469727) {
                    if (input[1] <= 21.31999969482422) {
                        if (input[0] <= 7.5) {
                            if (input[1] <= 20.734999656677246) {
                                var39 = 39.78;
                            } else {
                                var39 = 39.67;
                            }
                        } else {
                            var39 = 35.42;
                        }
                    } else {
                        if (input[2] <= 163.57500457763672) {
                            var39 = 34.54;
                        } else {
                            var39 = 35.59;
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var39 = 36.76;
                    } else {
                        if (input[1] <= 23.625) {
                            var39 = 41.93;
                        } else {
                            if (input[1] <= 25.730000495910645) {
                                if (input[0] <= 6.5) {
                                    var39 = 39.14;
                                } else {
                                    var39 = 39.48;
                                }
                            } else {
                                var39 = 39.98;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 136.86500549316406) {
                    if (input[2] <= 76.15499877929688) {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 30.609999656677246) {
                                var39 = 36.43;
                            } else {
                                if (input[0] <= 6.5) {
                                    var39 = 34.8;
                                } else {
                                    var39 = 34.91;
                                }
                            }
                        } else {
                            if (input[0] <= 10.0) {
                                var39 = 32.23;
                            } else {
                                var39 = 32.94;
                            }
                        }
                    } else {
                        if (input[2] <= 91.59000015258789) {
                            var39 = 40.31;
                        } else {
                            if (input[0] <= 5.5) {
                                var39 = 38.4;
                            } else {
                                var39 = 37.89;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        var39 = 33.27;
                    } else {
                        var39 = 34.54;
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.56500053405762) {
                    if (input[0] <= 10.5) {
                        if (input[2] <= 165.7750015258789) {
                            if (input[1] <= 35.75) {
                                if (input[2] <= 160.67499542236328) {
                                    var39 = 32.91;
                                } else {
                                    var39 = 35.16;
                                }
                            } else {
                                if (input[1] <= 36.46999931335449) {
                                    var39 = 31.17;
                                } else {
                                    var39 = 30.22;
                                }
                            }
                        } else {
                            if (input[1] <= 33.66000175476074) {
                                var39 = 31.15;
                            } else {
                                if (input[2] <= 195.8550033569336) {
                                    var39 = 30.63;
                                } else {
                                    if (input[2] <= 243.01000213623047) {
                                        var39 = 30.13;
                                    } else {
                                        var39 = 30.34;
                                    }
                                }
                            }
                        }
                    } else {
                        var39 = 27.52;
                    }
                } else {
                    var39 = 35.22;
                }
            } else {
                if (input[2] <= 212.5) {
                    if (input[0] <= 6.0) {
                        var39 = 29.28;
                    } else {
                        var39 = 28.17;
                    }
                } else {
                    var39 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[1] <= 30.27500057220459) {
                var39 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var39 = 80.11;
                } else {
                    if (input[1] <= 31.860000610351562) {
                        var39 = 83.02;
                    } else {
                        var39 = 84.62;
                    }
                }
            }
        } else {
            if (input[1] <= 46.334999084472656) {
                if (input[2] <= 108.48000144958496) {
                    var39 = 82.02;
                } else {
                    if (input[2] <= 179.24500274658203) {
                        var39 = 76.33;
                    } else {
                        if (input[2] <= 210.9000015258789) {
                            var39 = 78.32;
                        } else {
                            var39 = 79.55;
                        }
                    }
                }
            } else {
                if (input[2] <= 236.56000518798828) {
                    var39 = 74.62;
                } else {
                    var39 = 70.41;
                }
            }
        }
    }
    double var40;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 22.795000076293945) {
                    if (input[1] <= 21.84000015258789) {
                        if (input[2] <= 206.34000396728516) {
                            var40 = 35.59;
                        } else {
                            var40 = 35.42;
                        }
                    } else {
                        var40 = 36.77;
                    }
                } else {
                    if (input[1] <= 23.625) {
                        var40 = 41.93;
                    } else {
                        if (input[0] <= 3.5) {
                            var40 = 36.76;
                        } else {
                            if (input[2] <= 181.02499389648438) {
                                if (input[2] <= 109.53999710083008) {
                                    var40 = 39.48;
                                } else {
                                    var40 = 39.14;
                                }
                            } else {
                                var40 = 39.98;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 4.0) {
                    var40 = 38.4;
                } else {
                    if (input[2] <= 30.609999656677246) {
                        var40 = 36.43;
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[0] <= 6.5) {
                                var40 = 34.8;
                            } else {
                                if (input[1] <= 28.28499984741211) {
                                    if (input[2] <= 144.02999877929688) {
                                        var40 = 32.23;
                                    } else {
                                        var40 = 32.47;
                                    }
                                } else {
                                    if (input[2] <= 103.69000244140625) {
                                        var40 = 34.91;
                                    } else {
                                        var40 = 33.27;
                                    }
                                }
                            }
                        } else {
                            if (input[2] <= 177.6699981689453) {
                                var40 = 37.89;
                            } else {
                                var40 = 34.54;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.834999084472656) {
                    if (input[0] <= 10.5) {
                        if (input[0] <= 6.5) {
                            if (input[1] <= 38.510000228881836) {
                                if (input[1] <= 37.474998474121094) {
                                    if (input[1] <= 33.3650016784668) {
                                        var40 = 32.91;
                                    } else {
                                        if (input[1] <= 33.66000175476074) {
                                            var40 = 31.15;
                                        } else {
                                            if (input[2] <= 166.10000228881836) {
                                                var40 = 30.22;
                                            } else {
                                                var40 = 30.34;
                                            }
                                        }
                                    }
                                } else {
                                    if (input[2] <= 131.54500198364258) {
                                        var40 = 35.3;
                                    } else {
                                        var40 = 30.63;
                                    }
                                }
                            } else {
                                var40 = 28.69;
                            }
                        } else {
                            if (input[1] <= 35.75) {
                                var40 = 35.16;
                            } else {
                                var40 = 31.17;
                            }
                        }
                    } else {
                        var40 = 27.52;
                    }
                } else {
                    var40 = 35.22;
                }
            } else {
                if (input[2] <= 112.84000015258789) {
                    var40 = 31.5;
                } else {
                    if (input[1] <= 39.20000076293945) {
                        var40 = 28.17;
                    } else {
                        var40 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[1] <= 30.27500057220459) {
                var40 = 88.23;
            } else {
                if (input[2] <= 280.1549987792969) {
                    if (input[2] <= 195.11000061035156) {
                        var40 = 82.48;
                    } else {
                        if (input[1] <= 33.250000953674316) {
                            var40 = 80.11;
                        } else {
                            var40 = 79.55;
                        }
                    }
                } else {
                    var40 = 83.02;
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[2] <= 186.8350067138672) {
                    var40 = 74.62;
                } else {
                    var40 = 74.09;
                }
            } else {
                var40 = 70.41;
            }
        }
    }
    double var41;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 8.5) {
                if (input[1] <= 26.020000457763672) {
                    if (input[2] <= 138.625) {
                        if (input[0] <= 3.0) {
                            var41 = 36.77;
                        } else {
                            if (input[1] <= 23.78499984741211) {
                                if (input[2] <= 63.910000801086426) {
                                    var41 = 39.52;
                                } else {
                                    var41 = 39.78;
                                }
                            } else {
                                var41 = 39.14;
                            }
                        }
                    } else {
                        if (input[0] <= 2.5) {
                            if (input[2] <= 178.7100067138672) {
                                var41 = 34.54;
                            } else {
                                var41 = 39.67;
                            }
                        } else {
                            if (input[2] <= 207.1300048828125) {
                                var41 = 35.16;
                            } else {
                                var41 = 35.42;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 30.570000648498535) {
                        if (input[1] <= 26.985000610351562) {
                            var41 = 32.23;
                        } else {
                            if (input[2] <= 147.0999984741211) {
                                if (input[0] <= 6.5) {
                                    var41 = 34.8;
                                } else {
                                    var41 = 34.91;
                                }
                            } else {
                                var41 = 32.47;
                            }
                        }
                    } else {
                        var41 = 38.4;
                    }
                }
            } else {
                if (input[2] <= 176.31000518798828) {
                    if (input[2] <= 109.65500259399414) {
                        var41 = 39.48;
                    } else {
                        var41 = 37.89;
                    }
                } else {
                    var41 = 41.93;
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 81.82500076293945) {
                    if (input[0] <= 7.5) {
                        if (input[1] <= 38.295000076293945) {
                            var41 = 30.22;
                        } else {
                            var41 = 29.28;
                        }
                    } else {
                        var41 = 31.17;
                    }
                } else {
                    if (input[1] <= 38.39499855041504) {
                        if (input[1] <= 33.60000038146973) {
                            var41 = 32.91;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[2] <= 128.65499877929688) {
                                    var41 = 35.17;
                                } else {
                                    var41 = 35.16;
                                }
                            } else {
                                var41 = 35.3;
                            }
                        }
                    } else {
                        var41 = 28.69;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[1] <= 33.66000175476074) {
                        var41 = 31.15;
                    } else {
                        if (input[2] <= 195.8550033569336) {
                            var41 = 30.63;
                        } else {
                            if (input[1] <= 35.10500144958496) {
                                var41 = 30.34;
                            } else {
                                var41 = 30.13;
                            }
                        }
                    }
                } else {
                    var41 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[1] <= 32.470001220703125) {
                if (input[2] <= 217.37998962402344) {
                    var41 = 88.23;
                } else {
                    var41 = 87.95;
                }
            } else {
                var41 = 84.62;
            }
        } else {
            if (input[2] <= 188.45000457763672) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var41 = 78.32;
                    } else {
                        if (input[1] <= 45.96000099182129) {
                            var41 = 82.48;
                        } else {
                            var41 = 80.28;
                        }
                    }
                } else {
                    var41 = 75.92;
                }
            } else {
                if (input[1] <= 48.21999931335449) {
                    var41 = 74.09;
                } else {
                    var41 = 70.41;
                }
            }
        }
    }
    double var42;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 202.2550048828125) {
                        if (input[1] <= 21.699999809265137) {
                            var42 = 35.16;
                        } else {
                            var42 = 36.77;
                        }
                    } else {
                        var42 = 39.67;
                    }
                } else {
                    if (input[1] <= 21.714999198913574) {
                        if (input[0] <= 6.5) {
                            var42 = 44.31;
                        } else {
                            var42 = 39.78;
                        }
                    } else {
                        if (input[1] <= 25.730000495910645) {
                            if (input[0] <= 6.0) {
                                var42 = 39.14;
                            } else {
                                var42 = 39.52;
                            }
                        } else {
                            var42 = 39.98;
                        }
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[2] <= 60.529998779296875) {
                        if (input[1] <= 27.47000026702881) {
                            var42 = 34.8;
                        } else {
                            var42 = 36.43;
                        }
                    } else {
                        if (input[2] <= 144.02999877929688) {
                            var42 = 32.23;
                        } else {
                            var42 = 32.47;
                        }
                    }
                } else {
                    if (input[2] <= 109.33000183105469) {
                        var42 = 40.31;
                    } else {
                        if (input[0] <= 10.5) {
                            var42 = 37.89;
                        } else {
                            var42 = 36.25;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[1] <= 35.75) {
                    if (input[0] <= 3.0) {
                        var42 = 38.4;
                    } else {
                        if (input[1] <= 33.60000038146973) {
                            if (input[1] <= 32.69500160217285) {
                                if (input[0] <= 10.0) {
                                    var42 = 33.27;
                                } else {
                                    var42 = 32.94;
                                }
                            } else {
                                var42 = 32.91;
                            }
                        } else {
                            if (input[0] <= 5.5) {
                                var42 = 35.17;
                            } else {
                                var42 = 35.16;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 88.04000091552734) {
                        if (input[2] <= 54.915000915527344) {
                            if (input[2] <= 29.540000915527344) {
                                var42 = 31.17;
                            } else {
                                var42 = 31.5;
                            }
                        } else {
                            var42 = 30.22;
                        }
                    } else {
                        var42 = 28.69;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[2] <= 218.81500244140625) {
                        var42 = 35.22;
                    } else {
                        if (input[1] <= 38.55000114440918) {
                            if (input[2] <= 276.06500244140625) {
                                if (input[2] <= 243.01000213623047) {
                                    var42 = 30.13;
                                } else {
                                    var42 = 30.34;
                                }
                            } else {
                                var42 = 32.07;
                            }
                        } else {
                            var42 = 26.88;
                        }
                    }
                } else {
                    var42 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 30.27500057220459) {
                var42 = 88.23;
            } else {
                if (input[2] <= 195.11000061035156) {
                    if (input[2] <= 122.375) {
                        var42 = 84.62;
                    } else {
                        var42 = 82.48;
                    }
                } else {
                    if (input[1] <= 33.250000953674316) {
                        var42 = 80.11;
                    } else {
                        var42 = 79.55;
                    }
                }
            }
        } else {
            if (input[0] <= 5.5) {
                if (input[1] <= 48.21999931335449) {
                    var42 = 74.09;
                } else {
                    var42 = 70.41;
                }
            } else {
                if (input[1] <= 48.14500045776367) {
                    if (input[0] <= 10.5) {
                        var42 = 76.33;
                    } else {
                        var42 = 75.92;
                    }
                } else {
                    var42 = 80.28;
                }
            }
        }
    }
    double var43;
    if (input[3] <= 0.5) {
        if (input[1] <= 32.02000045776367) {
            if (input[0] <= 8.5) {
                if (input[1] <= 26.020000457763672) {
                    if (input[2] <= 138.625) {
                        if (input[1] <= 21.714999198913574) {
                            var43 = 44.31;
                        } else {
                            if (input[0] <= 6.0) {
                                var43 = 39.14;
                            } else {
                                var43 = 39.52;
                            }
                        }
                    } else {
                        if (input[2] <= 192.48500061035156) {
                            if (input[0] <= 2.5) {
                                var43 = 34.54;
                            } else {
                                if (input[1] <= 21.27999973297119) {
                                    var43 = 35.16;
                                } else {
                                    var43 = 35.59;
                                }
                            }
                        } else {
                            var43 = 36.76;
                        }
                    }
                } else {
                    if (input[1] <= 26.985000610351562) {
                        var43 = 32.23;
                    } else {
                        if (input[2] <= 30.609999656677246) {
                            var43 = 36.43;
                        } else {
                            if (input[0] <= 6.5) {
                                var43 = 34.8;
                            } else {
                                var43 = 34.91;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 29.869999885559082) {
                    if (input[1] <= 26.55500030517578) {
                        var43 = 39.48;
                    } else {
                        var43 = 40.31;
                    }
                } else {
                    var43 = 36.25;
                }
            }
        } else {
            if (input[2] <= 100.63999938964844) {
                if (input[2] <= 81.82500076293945) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[2] <= 70.68999862670898) {
                            var43 = 29.28;
                        } else {
                            var43 = 30.22;
                        }
                    } else {
                        var43 = 31.5;
                    }
                } else {
                    if (input[1] <= 35.98499870300293) {
                        var43 = 35.17;
                    } else {
                        var43 = 35.3;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[1] <= 38.510000228881836) {
                        if (input[1] <= 34.935001373291016) {
                            var43 = 31.15;
                        } else {
                            if (input[0] <= 7.0) {
                                var43 = 30.63;
                            } else {
                                var43 = 30.13;
                            }
                        }
                    } else {
                        if (input[1] <= 39.28000068664551) {
                            if (input[0] <= 4.5) {
                                var43 = 29.5;
                            } else {
                                var43 = 28.69;
                            }
                        } else {
                            var43 = 26.88;
                        }
                    }
                } else {
                    var43 = 27.52;
                }
            }
        }
    } else {
        if (input[2] <= 167.15499877929688) {
            if (input[1] <= 31.560001373291016) {
                var43 = 88.23;
            } else {
                if (input[0] <= 10.5) {
                    if (input[2] <= 98.63500022888184) {
                        var43 = 82.02;
                    } else {
                        var43 = 82.48;
                    }
                } else {
                    var43 = 84.62;
                }
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[1] <= 37.01499938964844) {
                    if (input[1] <= 30.574999809265137) {
                        var43 = 80.11;
                    } else {
                        var43 = 83.02;
                    }
                } else {
                    if (input[1] <= 48.13999938964844) {
                        if (input[1] <= 45.28999900817871) {
                            var43 = 76.33;
                        } else {
                            var43 = 74.62;
                        }
                    } else {
                        var43 = 80.28;
                    }
                }
            } else {
                var43 = 70.41;
            }
        }
    }
    double var44;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[2] <= 76.15499877929688) {
                if (input[1] <= 27.890000343322754) {
                    var44 = 34.8;
                } else {
                    var44 = 34.91;
                }
            } else {
                if (input[2] <= 136.86500549316406) {
                    if (input[1] <= 21.81999969482422) {
                        if (input[0] <= 6.5) {
                            var44 = 44.31;
                        } else {
                            var44 = 39.78;
                        }
                    } else {
                        if (input[2] <= 83.75500106811523) {
                            if (input[0] <= 10.5) {
                                var44 = 39.48;
                            } else {
                                var44 = 40.31;
                            }
                        } else {
                            if (input[1] <= 23.890000343322754) {
                                var44 = 36.77;
                            } else {
                                if (input[1] <= 27.09500026702881) {
                                    var44 = 39.14;
                                } else {
                                    if (input[2] <= 118.92000198364258) {
                                        var44 = 38.4;
                                    } else {
                                        var44 = 37.89;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (input[2] <= 192.48500061035156) {
                        if (input[1] <= 27.135001182556152) {
                            if (input[1] <= 21.630000114440918) {
                                var44 = 35.16;
                            } else {
                                var44 = 34.54;
                            }
                        } else {
                            var44 = 33.27;
                        }
                    } else {
                        if (input[2] <= 217.63999938964844) {
                            if (input[1] <= 23.81999969482422) {
                                if (input[1] <= 22.274999618530273) {
                                    var44 = 39.67;
                                } else {
                                    var44 = 41.93;
                                }
                            } else {
                                if (input[0] <= 7.5) {
                                    var44 = 36.76;
                                } else {
                                    var44 = 36.25;
                                }
                            }
                        } else {
                            if (input[2] <= 222.51499938964844) {
                                var44 = 34.54;
                            } else {
                                var44 = 35.42;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 134.86999893188477) {
                if (input[1] <= 39.71000099182129) {
                    if (input[1] <= 37.85999870300293) {
                        var44 = 30.22;
                    } else {
                        if (input[1] <= 39.21500015258789) {
                            var44 = 28.69;
                        } else {
                            var44 = 29.28;
                        }
                    }
                } else {
                    var44 = 31.5;
                }
            } else {
                if (input[2] <= 218.81500244140625) {
                    if (input[1] <= 34.4950008392334) {
                        var44 = 31.15;
                    } else {
                        if (input[2] <= 188.73500061035156) {
                            var44 = 35.16;
                        } else {
                            var44 = 35.22;
                        }
                    }
                } else {
                    if (input[1] <= 37.845001220703125) {
                        if (input[2] <= 243.01000213623047) {
                            var44 = 30.13;
                        } else {
                            var44 = 30.34;
                        }
                    } else {
                        var44 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.685001373291016) {
                if (input[2] <= 273.96998596191406) {
                    if (input[2] <= 128.03499603271484) {
                        var44 = 84.62;
                    } else {
                        if (input[0] <= 5.5) {
                            var44 = 87.95;
                        } else {
                            var44 = 88.23;
                        }
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var44 = 80.11;
                    } else {
                        var44 = 83.02;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    if (input[2] <= 98.63500022888184) {
                        var44 = 82.02;
                    } else {
                        var44 = 82.48;
                    }
                } else {
                    var44 = 78.32;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                var44 = 80.28;
            } else {
                if (input[0] <= 6.0) {
                    var44 = 74.09;
                } else {
                    var44 = 74.62;
                }
            }
        }
    }
    double var45;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 22.795000076293945) {
                    if (input[1] <= 20.69499969482422) {
                        var45 = 39.78;
                    } else {
                        if (input[0] <= 2.5) {
                            var45 = 36.77;
                        } else {
                            if (input[1] <= 21.15499973297119) {
                                var45 = 35.16;
                            } else {
                                if (input[2] <= 206.34000396728516) {
                                    var45 = 35.59;
                                } else {
                                    var45 = 35.42;
                                }
                            }
                        }
                    }
                } else {
                    if (input[1] <= 23.625) {
                        var45 = 41.93;
                    } else {
                        if (input[1] <= 24.93000030517578) {
                            var45 = 39.48;
                        } else {
                            var45 = 39.98;
                        }
                    }
                }
            } else {
                if (input[1] <= 26.795000076293945) {
                    var45 = 32.23;
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[1] <= 28.079999923706055) {
                            if (input[0] <= 6.5) {
                                var45 = 34.8;
                            } else {
                                var45 = 36.43;
                            }
                        } else {
                            if (input[0] <= 5.5) {
                                var45 = 38.4;
                            } else {
                                var45 = 37.89;
                            }
                        }
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[2] <= 180.4800033569336) {
                                var45 = 33.27;
                            } else {
                                var45 = 32.47;
                            }
                        } else {
                            if (input[2] <= 213.31499481201172) {
                                var45 = 36.25;
                            } else {
                                var45 = 34.54;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[1] <= 36.7400016784668) {
                            if (input[2] <= 234.93000030517578) {
                                var45 = 31.15;
                            } else {
                                var45 = 30.34;
                            }
                        } else {
                            var45 = 29.28;
                        }
                    } else {
                        var45 = 31.5;
                    }
                } else {
                    if (input[1] <= 38.44999885559082) {
                        var45 = 35.3;
                    } else {
                        var45 = 35.22;
                    }
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[2] <= 165.7750015258789) {
                        var45 = 35.16;
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[2] <= 257.91500091552734) {
                                if (input[2] <= 195.8550033569336) {
                                    var45 = 30.63;
                                } else {
                                    var45 = 30.13;
                                }
                            } else {
                                var45 = 32.07;
                            }
                        } else {
                            var45 = 27.52;
                        }
                    }
                } else {
                    if (input[2] <= 171.57500076293945) {
                        var45 = 28.69;
                    } else {
                        var45 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[0] <= 5.5) {
                var45 = 87.95;
            } else {
                if (input[2] <= 195.11000061035156) {
                    if (input[2] <= 122.375) {
                        var45 = 84.62;
                    } else {
                        var45 = 82.48;
                    }
                } else {
                    if (input[2] <= 280.1549987792969) {
                        if (input[0] <= 10.5) {
                            var45 = 80.11;
                        } else {
                            var45 = 79.55;
                        }
                    } else {
                        var45 = 83.02;
                    }
                }
            }
        } else {
            if (input[1] <= 48.43499946594238) {
                if (input[0] <= 6.0) {
                    var45 = 74.09;
                } else {
                    var45 = 74.62;
                }
            } else {
                var45 = 70.41;
            }
        }
    }
    double var46;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 136.75) {
                if (input[1] <= 21.714999198913574) {
                    if (input[0] <= 6.5) {
                        var46 = 44.31;
                    } else {
                        var46 = 39.78;
                    }
                } else {
                    if (input[0] <= 7.5) {
                        if (input[2] <= 93.02000045776367) {
                            if (input[0] <= 4.0) {
                                var46 = 36.77;
                            } else {
                                if (input[2] <= 63.599998474121094) {
                                    var46 = 34.8;
                                } else {
                                    var46 = 34.91;
                                }
                            }
                        } else {
                            if (input[0] <= 3.0) {
                                var46 = 38.4;
                            } else {
                                var46 = 39.14;
                            }
                        }
                    } else {
                        if (input[1] <= 26.55500030517578) {
                            if (input[0] <= 8.5) {
                                var46 = 39.52;
                            } else {
                                var46 = 39.48;
                            }
                        } else {
                            var46 = 40.31;
                        }
                    }
                }
            } else {
                if (input[2] <= 211.9550018310547) {
                    if (input[2] <= 161.70000457763672) {
                        var46 = 33.27;
                    } else {
                        if (input[1] <= 22.864999771118164) {
                            if (input[0] <= 4.0) {
                                var46 = 35.16;
                            } else {
                                var46 = 35.59;
                            }
                        } else {
                            if (input[2] <= 202.50499725341797) {
                                var46 = 36.76;
                            } else {
                                var46 = 36.25;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 217.63999938964844) {
                        if (input[0] <= 5.5) {
                            var46 = 39.67;
                        } else {
                            var46 = 41.93;
                        }
                    } else {
                        if (input[1] <= 24.119999885559082) {
                            var46 = 35.42;
                        } else {
                            var46 = 34.54;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[2] <= 165.7750015258789) {
                    if (input[2] <= 160.67499542236328) {
                        if (input[1] <= 34.6200008392334) {
                            var46 = 32.91;
                        } else {
                            var46 = 31.17;
                        }
                    } else {
                        var46 = 35.16;
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 37.310001373291016) {
                            if (input[2] <= 243.01000213623047) {
                                var46 = 30.13;
                            } else {
                                var46 = 30.34;
                            }
                        } else {
                            var46 = 30.63;
                        }
                    } else {
                        var46 = 32.07;
                    }
                }
            } else {
                if (input[1] <= 39.540000915527344) {
                    if (input[2] <= 212.5) {
                        if (input[2] <= 145.9650001525879) {
                            var46 = 28.69;
                        } else {
                            var46 = 28.17;
                        }
                    } else {
                        var46 = 26.88;
                    }
                } else {
                    var46 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 47.579999923706055) {
            if (input[0] <= 5.5) {
                if (input[2] <= 156.74499320983887) {
                    var46 = 82.02;
                } else {
                    var46 = 87.95;
                }
            } else {
                if (input[2] <= 215.85999298095703) {
                    var46 = 82.48;
                } else {
                    var46 = 80.11;
                }
            }
        } else {
            var46 = 70.41;
        }
    }
    double var47;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 21.399999618530273) {
                if (input[2] <= 110.34500122070312) {
                    var47 = 39.78;
                } else {
                    var47 = 44.31;
                }
            } else {
                if (input[2] <= 161.37999725341797) {
                    if (input[2] <= 76.15499877929688) {
                        if (input[1] <= 24.28499984741211) {
                            var47 = 39.52;
                        } else {
                            if (input[0] <= 7.5) {
                                if (input[2] <= 37.3199987411499) {
                                    var47 = 36.43;
                                } else {
                                    var47 = 34.91;
                                }
                            } else {
                                if (input[0] <= 10.0) {
                                    var47 = 32.23;
                                } else {
                                    var47 = 32.94;
                                }
                            }
                        }
                    } else {
                        if (input[0] <= 3.0) {
                            if (input[1] <= 27.535000801086426) {
                                var47 = 36.77;
                            } else {
                                var47 = 38.4;
                            }
                        } else {
                            if (input[1] <= 27.355000495910645) {
                                if (input[1] <= 24.72000026702881) {
                                    var47 = 39.48;
                                } else {
                                    var47 = 39.14;
                                }
                            } else {
                                var47 = 40.31;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 213.31499481201172) {
                        if (input[2] <= 197.13999938964844) {
                            var47 = 35.59;
                        } else {
                            var47 = 36.25;
                        }
                    } else {
                        var47 = 34.54;
                    }
                }
            }
        } else {
            if (input[0] <= 8.5) {
                if (input[2] <= 218.81500244140625) {
                    if (input[2] <= 81.82500076293945) {
                        if (input[2] <= 54.915000915527344) {
                            var47 = 31.5;
                        } else {
                            var47 = 30.22;
                        }
                    } else {
                        if (input[0] <= 5.0) {
                            if (input[1] <= 35.98499870300293) {
                                var47 = 35.17;
                            } else {
                                if (input[1] <= 38.44999885559082) {
                                    var47 = 35.3;
                                } else {
                                    var47 = 35.22;
                                }
                            }
                        } else {
                            if (input[1] <= 36.8700008392334) {
                                if (input[2] <= 160.67499542236328) {
                                    var47 = 32.91;
                                } else {
                                    var47 = 35.16;
                                }
                            } else {
                                var47 = 30.63;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 38.55000114440918) {
                        if (input[2] <= 276.06500244140625) {
                            if (input[2] <= 243.01000213623047) {
                                var47 = 30.13;
                            } else {
                                var47 = 30.34;
                            }
                        } else {
                            var47 = 32.07;
                        }
                    } else {
                        var47 = 26.88;
                    }
                }
            } else {
                if (input[2] <= 184.36499786376953) {
                    var47 = 27.52;
                } else {
                    var47 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[0] <= 10.5) {
                if (input[2] <= 227.50999450683594) {
                    if (input[1] <= 40.885000228881836) {
                        var47 = 78.32;
                    } else {
                        if (input[2] <= 106.5200023651123) {
                            var47 = 82.02;
                        } else {
                            var47 = 80.28;
                        }
                    }
                } else {
                    if (input[0] <= 5.5) {
                        var47 = 87.95;
                    } else {
                        var47 = 80.11;
                    }
                }
            } else {
                var47 = 75.92;
            }
        } else {
            var47 = 70.41;
        }
    }
    double var48;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.350000381469727) {
            if (input[1] <= 25.414999961853027) {
                if (input[0] <= 8.5) {
                    if (input[2] <= 58.320000648498535) {
                        var48 = 39.52;
                    } else {
                        if (input[0] <= 4.0) {
                            if (input[1] <= 21.670000076293945) {
                                var48 = 39.67;
                            } else {
                                if (input[1] <= 22.190000534057617) {
                                    var48 = 34.54;
                                } else {
                                    if (input[0] <= 2.5) {
                                        var48 = 36.77;
                                    } else {
                                        var48 = 36.76;
                                    }
                                }
                            }
                        } else {
                            if (input[2] <= 206.34000396728516) {
                                var48 = 35.59;
                            } else {
                                var48 = 35.42;
                            }
                        }
                    }
                } else {
                    var48 = 41.93;
                }
            } else {
                if (input[1] <= 28.454999923706055) {
                    if (input[2] <= 60.529998779296875) {
                        if (input[1] <= 27.47000026702881) {
                            var48 = 34.8;
                        } else {
                            var48 = 36.43;
                        }
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[1] <= 27.380000114440918) {
                                var48 = 32.23;
                            } else {
                                var48 = 32.47;
                            }
                        } else {
                            var48 = 34.54;
                        }
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var48 = 37.89;
                    } else {
                        var48 = 36.25;
                    }
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[2] <= 81.82500076293945) {
                    var48 = 30.22;
                } else {
                    if (input[2] <= 212.93000030517578) {
                        if (input[1] <= 33.05500030517578) {
                            var48 = 33.27;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[2] <= 128.65499877929688) {
                                    var48 = 35.17;
                                } else {
                                    var48 = 35.16;
                                }
                            } else {
                                var48 = 35.3;
                            }
                        }
                    } else {
                        var48 = 30.34;
                    }
                }
            } else {
                if (input[1] <= 38.989999771118164) {
                    if (input[2] <= 189.81000518798828) {
                        if (input[0] <= 5.5) {
                            var48 = 28.69;
                        } else {
                            var48 = 30.63;
                        }
                    } else {
                        var48 = 35.22;
                    }
                } else {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 39.71000099182129) {
                            if (input[1] <= 39.45000076293945) {
                                var48 = 29.5;
                            } else {
                                var48 = 29.28;
                            }
                        } else {
                            var48 = 31.5;
                        }
                    } else {
                        if (input[2] <= 212.5) {
                            var48 = 28.17;
                        } else {
                            var48 = 26.88;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[1] <= 33.92500114440918) {
                if (input[0] <= 10.5) {
                    if (input[2] <= 217.37998962402344) {
                        var48 = 88.23;
                    } else {
                        var48 = 87.95;
                    }
                } else {
                    var48 = 83.02;
                }
            } else {
                if (input[2] <= 154.01499938964844) {
                    if (input[1] <= 44.15500068664551) {
                        var48 = 82.48;
                    } else {
                        var48 = 82.02;
                    }
                } else {
                    if (input[1] <= 48.14500045776367) {
                        if (input[1] <= 39.84000015258789) {
                            if (input[2] <= 210.9000015258789) {
                                var48 = 78.32;
                            } else {
                                var48 = 79.55;
                            }
                        } else {
                            if (input[2] <= 163.86000061035156) {
                                var48 = 75.92;
                            } else {
                                var48 = 76.33;
                            }
                        }
                    } else {
                        var48 = 80.28;
                    }
                }
            }
        } else {
            var48 = 70.41;
        }
    }
    double var49;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[0] <= 8.5) {
                if (input[1] <= 26.230000495910645) {
                    if (input[2] <= 118.43000411987305) {
                        if (input[1] <= 22.15499973297119) {
                            if (input[2] <= 63.910000801086426) {
                                var49 = 39.52;
                            } else {
                                var49 = 39.78;
                            }
                        } else {
                            var49 = 36.77;
                        }
                    } else {
                        if (input[1] <= 24.030000686645508) {
                            if (input[2] <= 163.57500457763672) {
                                var49 = 34.54;
                            } else {
                                if (input[0] <= 4.0) {
                                    var49 = 35.16;
                                } else {
                                    if (input[2] <= 206.34000396728516) {
                                        var49 = 35.59;
                                    } else {
                                        var49 = 35.42;
                                    }
                                }
                            }
                        } else {
                            var49 = 39.98;
                        }
                    }
                } else {
                    if (input[0] <= 7.5) {
                        if (input[2] <= 147.0999984741211) {
                            if (input[2] <= 30.609999656677246) {
                                var49 = 36.43;
                            } else {
                                if (input[0] <= 6.5) {
                                    var49 = 34.8;
                                } else {
                                    var49 = 34.91;
                                }
                            }
                        } else {
                            var49 = 32.47;
                        }
                    } else {
                        var49 = 32.23;
                    }
                }
            } else {
                if (input[2] <= 217.31999969482422) {
                    if (input[1] <= 29.869999885559082) {
                        if (input[2] <= 176.31000518798828) {
                            if (input[2] <= 109.65500259399414) {
                                if (input[0] <= 10.5) {
                                    var49 = 39.48;
                                } else {
                                    var49 = 40.31;
                                }
                            } else {
                                var49 = 37.89;
                            }
                        } else {
                            var49 = 41.93;
                        }
                    } else {
                        var49 = 36.25;
                    }
                } else {
                    var49 = 34.54;
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[0] <= 6.5) {
                    if (input[1] <= 33.3650016784668) {
                        var49 = 32.91;
                    } else {
                        if (input[2] <= 249.83499908447266) {
                            if (input[2] <= 187.7750015258789) {
                                if (input[1] <= 37.59000015258789) {
                                    var49 = 30.22;
                                } else {
                                    var49 = 30.63;
                                }
                            } else {
                                var49 = 31.149999999999995;
                            }
                        } else {
                            var49 = 32.07;
                        }
                    }
                } else {
                    if (input[0] <= 7.5) {
                        var49 = 35.16;
                    } else {
                        if (input[1] <= 34.07500076293945) {
                            if (input[2] <= 71.8800036907196) {
                                var49 = 32.94;
                            } else {
                                var49 = 33.27;
                            }
                        } else {
                            var49 = 31.17;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.45000076293945) {
                        var49 = 29.5;
                    } else {
                        var49 = 29.28;
                    }
                } else {
                    if (input[0] <= 7.0) {
                        var49 = 28.69;
                    } else {
                        var49 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 10.5) {
                    if (input[1] <= 30.950000762939453) {
                        var49 = 88.23;
                    } else {
                        var49 = 87.95;
                    }
                } else {
                    if (input[2] <= 186.67000579833984) {
                        var49 = 84.62;
                    } else {
                        var49 = 83.02;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    var49 = 82.48;
                } else {
                    if (input[1] <= 36.14000129699707) {
                        var49 = 79.55;
                    } else {
                        var49 = 78.32;
                    }
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[2] <= 177.6300048828125) {
                    if (input[1] <= 45.295000076293945) {
                        var49 = 76.33;
                    } else {
                        var49 = 75.92;
                    }
                } else {
                    if (input[1] <= 46.974998474121094) {
                        var49 = 74.09;
                    } else {
                        var49 = 74.62;
                    }
                }
            } else {
                var49 = 70.41;
            }
        }
    }
    double var50;
    if (input[3] <= 0.5) {
        if (input[1] <= 27.864999771118164) {
            if (input[1] <= 26.505000114440918) {
                if (input[2] <= 132.73500442504883) {
                    if (input[2] <= 103.6500015258789) {
                        var50 = 39.48;
                    } else {
                        var50 = 44.31;
                    }
                } else {
                    if (input[1] <= 22.725000381469727) {
                        if (input[0] <= 3.5) {
                            if (input[2] <= 178.7100067138672) {
                                var50 = 34.54;
                            } else {
                                var50 = 39.67;
                            }
                        } else {
                            if (input[2] <= 206.34000396728516) {
                                var50 = 35.59;
                            } else {
                                var50 = 35.42;
                            }
                        }
                    } else {
                        if (input[0] <= 7.0) {
                            var50 = 39.98;
                        } else {
                            var50 = 41.93;
                        }
                    }
                }
            } else {
                if (input[1] <= 27.27999973297119) {
                    var50 = 34.54;
                } else {
                    var50 = 36.43;
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 54.564998626708984) {
                        var50 = 31.5;
                    } else {
                        if (input[1] <= 36.7400016784668) {
                            if (input[0] <= 2.5) {
                                var50 = 30.34;
                            } else {
                                var50 = 31.15;
                            }
                        } else {
                            var50 = 29.28;
                        }
                    }
                } else {
                    if (input[1] <= 39.06999969482422) {
                        if (input[1] <= 35.98499870300293) {
                            var50 = 35.17;
                        } else {
                            if (input[2] <= 154.50500106811523) {
                                var50 = 35.3;
                            } else {
                                var50 = 35.22;
                            }
                        }
                    } else {
                        var50 = 29.5;
                    }
                }
            } else {
                if (input[1] <= 34.10500144958496) {
                    if (input[0] <= 10.0) {
                        if (input[1] <= 30.195000648498535) {
                            var50 = 32.47;
                        } else {
                            if (input[0] <= 7.0) {
                                var50 = 32.91;
                            } else {
                                var50 = 33.27;
                            }
                        }
                    } else {
                        if (input[1] <= 30.90499973297119) {
                            var50 = 36.25;
                        } else {
                            var50 = 32.94;
                        }
                    }
                } else {
                    if (input[1] <= 35.23500061035156) {
                        var50 = 27.52;
                    } else {
                        if (input[1] <= 35.75) {
                            var50 = 35.16;
                        } else {
                            if (input[2] <= 257.91500091552734) {
                                if (input[1] <= 38.510000228881836) {
                                    if (input[2] <= 45.665000915527344) {
                                        var50 = 31.17;
                                    } else {
                                        if (input[1] <= 37.59000015258789) {
                                            if (input[0] <= 7.0) {
                                                var50 = 30.22;
                                            } else {
                                                var50 = 30.13;
                                            }
                                        } else {
                                            var50 = 30.63;
                                        }
                                    }
                                } else {
                                    var50 = 28.69;
                                }
                            } else {
                                var50 = 32.07;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[1] <= 30.27500057220459) {
                var50 = 88.23;
            } else {
                if (input[0] <= 5.5) {
                    var50 = 78.32;
                } else {
                    if (input[1] <= 30.574999809265137) {
                        var50 = 80.11;
                    } else {
                        if (input[1] <= 36.73500061035156) {
                            var50 = 83.02;
                        } else {
                            var50 = 82.48;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 48.13999938964844) {
                if (input[1] <= 46.974998474121094) {
                    var50 = 74.09;
                } else {
                    var50 = 74.62;
                }
            } else {
                var50 = 80.28;
            }
        }
    }
    double var51;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.505000114440918) {
                if (input[1] <= 22.795000076293945) {
                    if (input[1] <= 20.69499969482422) {
                        var51 = 39.78;
                    } else {
                        if (input[2] <= 112.84000396728516) {
                            var51 = 36.77;
                        } else {
                            if (input[2] <= 163.57500457763672) {
                                var51 = 34.54;
                            } else {
                                if (input[1] <= 21.15499973297119) {
                                    var51 = 35.16;
                                } else {
                                    if (input[1] <= 21.295000076293945) {
                                        var51 = 35.42;
                                    } else {
                                        var51 = 35.59;
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var51 = 36.76;
                    } else {
                        if (input[0] <= 7.0) {
                            if (input[2] <= 181.02499389648438) {
                                var51 = 39.14;
                            } else {
                                var51 = 39.98;
                            }
                        } else {
                            var51 = 41.93;
                        }
                    }
                }
            } else {
                if (input[1] <= 32.035000801086426) {
                    if (input[2] <= 221.28499603271484) {
                        if (input[1] <= 30.90499973297119) {
                            if (input[1] <= 29.4399995803833) {
                                if (input[2] <= 144.4949951171875) {
                                    if (input[2] <= 63.599998474121094) {
                                        var51 = 34.8;
                                    } else {
                                        var51 = 34.91;
                                    }
                                } else {
                                    var51 = 34.54;
                                }
                            } else {
                                var51 = 36.25;
                            }
                        } else {
                            var51 = 32.94;
                        }
                    } else {
                        var51 = 32.47;
                    }
                } else {
                    var51 = 38.4;
                }
            }
        } else {
            if (input[0] <= 7.5) {
                if (input[1] <= 38.39499855041504) {
                    if (input[2] <= 81.82500076293945) {
                        var51 = 30.22;
                    } else {
                        if (input[1] <= 33.89500045776367) {
                            if (input[0] <= 4.0) {
                                var51 = 30.34;
                            } else {
                                var51 = 32.91;
                            }
                        } else {
                            if (input[1] <= 35.98499870300293) {
                                var51 = 35.17;
                            } else {
                                var51 = 35.3;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 38.834999084472656) {
                        var51 = 28.69;
                    } else {
                        if (input[1] <= 39.06999969482422) {
                            var51 = 35.22;
                        } else {
                            if (input[1] <= 39.71000099182129) {
                                if (input[1] <= 39.45000076293945) {
                                    var51 = 29.5;
                                } else {
                                    var51 = 29.28;
                                }
                            } else {
                                var51 = 31.5;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 101.06499862670898) {
                    var51 = 31.17;
                } else {
                    if (input[2] <= 184.36499786376953) {
                        var51 = 27.52;
                    } else {
                        var51 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 45.010000228881836) {
            if (input[1] <= 34.53500175476074) {
                if (input[2] <= 273.96998596191406) {
                    if (input[0] <= 6.0) {
                        var51 = 87.95;
                    } else {
                        var51 = 84.62;
                    }
                } else {
                    if (input[2] <= 280.1549987792969) {
                        var51 = 80.11;
                    } else {
                        var51 = 83.02;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    var51 = 82.48;
                } else {
                    if (input[1] <= 36.14000129699707) {
                        var51 = 79.55;
                    } else {
                        var51 = 78.32;
                    }
                }
            }
        } else {
            var51 = 74.62;
        }
    }
    double var52;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 217.63999938964844) {
                if (input[1] <= 22.085000038146973) {
                    if (input[1] <= 21.299999237060547) {
                        if (input[0] <= 4.5) {
                            var52 = 39.67;
                        } else {
                            var52 = 39.78;
                        }
                    } else {
                        if (input[0] <= 7.0) {
                            var52 = 44.31;
                        } else {
                            var52 = 39.52;
                        }
                    }
                } else {
                    if (input[2] <= 211.9550018310547) {
                        if (input[2] <= 136.86500549316406) {
                            if (input[2] <= 93.02000045776367) {
                                if (input[2] <= 77.58499908447266) {
                                    var52 = 34.91;
                                } else {
                                    var52 = 36.77;
                                }
                            } else {
                                if (input[1] <= 27.09500026702881) {
                                    var52 = 39.14;
                                } else {
                                    if (input[0] <= 5.5) {
                                        var52 = 38.4;
                                    } else {
                                        var52 = 37.89;
                                    }
                                }
                            }
                        } else {
                            if (input[2] <= 168.94000244140625) {
                                if (input[1] <= 27.135001182556152) {
                                    var52 = 34.54;
                                } else {
                                    var52 = 33.27;
                                }
                            } else {
                                if (input[0] <= 7.5) {
                                    var52 = 36.76;
                                } else {
                                    var52 = 36.25;
                                }
                            }
                        }
                    } else {
                        var52 = 41.93;
                    }
                }
            } else {
                if (input[2] <= 222.51499938964844) {
                    var52 = 34.54;
                } else {
                    var52 = 35.42;
                }
            }
        } else {
            if (input[1] <= 38.39499855041504) {
                if (input[2] <= 81.82500076293945) {
                    if (input[1] <= 36.46999931335449) {
                        var52 = 31.17;
                    } else {
                        var52 = 30.22;
                    }
                } else {
                    if (input[2] <= 126.44499588012695) {
                        if (input[2] <= 94.42499923706055) {
                            var52 = 35.17;
                        } else {
                            var52 = 35.3;
                        }
                    } else {
                        if (input[0] <= 4.0) {
                            var52 = 31.15;
                        } else {
                            if (input[0] <= 5.5) {
                                var52 = 32.07;
                            } else {
                                var52 = 32.91;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 39.71000099182129) {
                    if (input[2] <= 212.5) {
                        if (input[2] <= 87.68999862670898) {
                            var52 = 29.28;
                        } else {
                            if (input[2] <= 145.9650001525879) {
                                var52 = 28.69;
                            } else {
                                var52 = 28.17;
                            }
                        }
                    } else {
                        var52 = 26.88;
                    }
                } else {
                    var52 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[2] <= 273.96998596191406) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var52 = 87.95;
                    } else {
                        var52 = 88.23;
                    }
                } else {
                    var52 = 84.62;
                }
            } else {
                var52 = 80.11;
            }
        } else {
            if (input[2] <= 171.34000396728516) {
                if (input[2] <= 161.49500274658203) {
                    if (input[0] <= 5.5) {
                        var52 = 82.02;
                    } else {
                        var52 = 82.48;
                    }
                } else {
                    var52 = 80.28;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[1] <= 45.07499885559082) {
                        if (input[0] <= 5.5) {
                            var52 = 78.32;
                        } else {
                            var52 = 76.33;
                        }
                    } else {
                        if (input[1] <= 46.974998474121094) {
                            var52 = 74.09;
                        } else {
                            var52 = 74.62;
                        }
                    }
                } else {
                    var52 = 70.41;
                }
            }
        }
    }
    double var53;
    if (input[3] <= 0.5) {
        if (input[1] <= 38.989999771118164) {
            if (input[1] <= 25.414999961853027) {
                if (input[2] <= 221.47500610351562) {
                    if (input[1] <= 24.114999771118164) {
                        if (input[1] <= 23.625) {
                            if (input[0] <= 5.5) {
                                var53 = 39.67;
                            } else {
                                var53 = 41.93;
                            }
                        } else {
                            var53 = 39.48;
                        }
                    } else {
                        var53 = 36.76;
                    }
                } else {
                    var53 = 35.42;
                }
            } else {
                if (input[1] <= 33.025001525878906) {
                    if (input[0] <= 4.0) {
                        var53 = 38.4;
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[2] <= 60.529998779296875) {
                                if (input[1] <= 27.47000026702881) {
                                    var53 = 34.8;
                                } else {
                                    var53 = 36.43;
                                }
                            } else {
                                if (input[1] <= 30.195000648498535) {
                                    if (input[2] <= 144.02999877929688) {
                                        var53 = 32.23;
                                    } else {
                                        var53 = 32.47;
                                    }
                                } else {
                                    var53 = 33.27;
                                }
                            }
                        } else {
                            if (input[2] <= 172.30500030517578) {
                                var53 = 37.89;
                            } else {
                                var53 = 36.25;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 5.0) {
                        if (input[1] <= 33.89500045776367) {
                            var53 = 30.34;
                        } else {
                            if (input[1] <= 35.98499870300293) {
                                var53 = 35.17;
                            } else {
                                if (input[2] <= 154.50500106811523) {
                                    var53 = 35.3;
                                } else {
                                    var53 = 35.22;
                                }
                            }
                        }
                    } else {
                        if (input[1] <= 34.6200008392334) {
                            var53 = 32.91;
                        } else {
                            if (input[2] <= 45.665000915527344) {
                                var53 = 31.17;
                            } else {
                                if (input[2] <= 118.94500350952148) {
                                    var53 = 30.22;
                                } else {
                                    var53 = 30.63;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 39.71000099182129) {
                if (input[1] <= 39.170000076293945) {
                    var53 = 28.17;
                } else {
                    if (input[1] <= 39.45000076293945) {
                        var53 = 29.5;
                    } else {
                        var53 = 29.28;
                    }
                }
            } else {
                var53 = 31.5;
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[1] <= 32.470001220703125) {
                    if (input[0] <= 5.5) {
                        var53 = 87.95;
                    } else {
                        var53 = 88.23;
                    }
                } else {
                    var53 = 84.62;
                }
            } else {
                if (input[0] <= 10.5) {
                    var53 = 80.11;
                } else {
                    var53 = 83.02;
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[1] <= 46.119998931884766) {
                    if (input[2] <= 108.48000144958496) {
                        var53 = 82.02;
                    } else {
                        if (input[1] <= 39.84000015258789) {
                            if (input[0] <= 6.0) {
                                var53 = 78.32;
                            } else {
                                var53 = 79.55;
                            }
                        } else {
                            var53 = 76.33;
                        }
                    }
                } else {
                    if (input[1] <= 47.19499969482422) {
                        if (input[1] <= 46.974998474121094) {
                            var53 = 74.09;
                        } else {
                            var53 = 74.62;
                        }
                    } else {
                        var53 = 75.92;
                    }
                }
            } else {
                var53 = 70.41;
            }
        }
    }
    double var54;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.295000076293945) {
                if (input[1] <= 21.19499969482422) {
                    if (input[2] <= 207.1300048828125) {
                        var54 = 35.16;
                    } else {
                        var54 = 35.42;
                    }
                } else {
                    if (input[0] <= 8.5) {
                        if (input[1] <= 23.179999351501465) {
                            if (input[0] <= 5.0) {
                                var54 = 39.67;
                            } else {
                                var54 = 39.52;
                            }
                        } else {
                            if (input[0] <= 3.5) {
                                var54 = 36.76;
                            } else {
                                var54 = 39.14;
                            }
                        }
                    } else {
                        if (input[2] <= 149.30500411987305) {
                            var54 = 39.48;
                        } else {
                            var54 = 41.93;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.0) {
                    var54 = 38.4;
                } else {
                    if (input[2] <= 221.28499603271484) {
                        if (input[1] <= 30.90499973297119) {
                            if (input[1] <= 29.4399995803833) {
                                if (input[0] <= 9.5) {
                                    if (input[2] <= 63.599998474121094) {
                                        var54 = 34.8;
                                    } else {
                                        var54 = 34.91;
                                    }
                                } else {
                                    var54 = 34.54;
                                }
                            } else {
                                var54 = 36.25;
                            }
                        } else {
                            if (input[2] <= 71.8800036907196) {
                                var54 = 32.94;
                            } else {
                                var54 = 33.27;
                            }
                        }
                    } else {
                        var54 = 32.47;
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[1] <= 36.57000160217285) {
                            var54 = 31.15;
                        } else {
                            var54 = 29.28;
                        }
                    } else {
                        var54 = 31.5;
                    }
                } else {
                    if (input[2] <= 94.42499923706055) {
                        var54 = 35.17;
                    } else {
                        if (input[1] <= 38.44999885559082) {
                            var54 = 35.3;
                        } else {
                            var54 = 35.22;
                        }
                    }
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[0] <= 10.5) {
                        if (input[1] <= 34.6200008392334) {
                            var54 = 32.91;
                        } else {
                            if (input[0] <= 5.5) {
                                var54 = 32.07;
                            } else {
                                if (input[1] <= 36.19000053405762) {
                                    var54 = 31.17;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[2] <= 147.95000076293945) {
                                            var54 = 30.22;
                                        } else {
                                            var54 = 30.13;
                                        }
                                    } else {
                                        var54 = 30.63;
                                    }
                                }
                            }
                        }
                    } else {
                        var54 = 27.52;
                    }
                } else {
                    if (input[2] <= 212.5) {
                        if (input[1] <= 38.93499946594238) {
                            var54 = 28.69;
                        } else {
                            var54 = 28.17;
                        }
                    } else {
                        var54 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[2] <= 273.96998596191406) {
                    if (input[2] <= 180.48499298095703) {
                        var54 = 84.62;
                    } else {
                        var54 = 87.95;
                    }
                } else {
                    var54 = 80.11;
                }
            } else {
                if (input[2] <= 163.4550018310547) {
                    if (input[2] <= 98.63500022888184) {
                        var54 = 82.02;
                    } else {
                        var54 = 82.48;
                    }
                } else {
                    if (input[2] <= 179.24500274658203) {
                        var54 = 76.33;
                    } else {
                        if (input[0] <= 6.0) {
                            var54 = 78.32;
                        } else {
                            var54 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[1] <= 47.19499969482422) {
                    if (input[1] <= 46.974998474121094) {
                        var54 = 74.09;
                    } else {
                        var54 = 74.62;
                    }
                } else {
                    var54 = 75.92;
                }
            } else {
                var54 = 70.41;
            }
        }
    }
    double var55;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[0] <= 8.5) {
                if (input[1] <= 26.695000648498535) {
                    if (input[1] <= 24.100000381469727) {
                        if (input[2] <= 141.18500137329102) {
                            if (input[1] <= 22.15499973297119) {
                                if (input[2] <= 63.910000801086426) {
                                    var55 = 39.52;
                                } else {
                                    var55 = 39.78;
                                }
                            } else {
                                var55 = 36.77;
                            }
                        } else {
                            if (input[0] <= 6.5) {
                                var55 = 35.59;
                            } else {
                                var55 = 35.42;
                            }
                        }
                    } else {
                        var55 = 39.98;
                    }
                } else {
                    if (input[2] <= 147.0999984741211) {
                        if (input[2] <= 30.609999656677246) {
                            var55 = 36.43;
                        } else {
                            if (input[0] <= 6.5) {
                                var55 = 34.8;
                            } else {
                                var55 = 34.91;
                            }
                        }
                    } else {
                        var55 = 32.47;
                    }
                }
            } else {
                if (input[1] <= 29.869999885559082) {
                    if (input[2] <= 176.31000518798828) {
                        if (input[0] <= 10.5) {
                            var55 = 37.89;
                        } else {
                            var55 = 40.31;
                        }
                    } else {
                        var55 = 41.93;
                    }
                } else {
                    var55 = 36.25;
                }
            }
        } else {
            if (input[0] <= 5.5) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 54.564998626708984) {
                        var55 = 31.5;
                    } else {
                        if (input[1] <= 36.57000160217285) {
                            var55 = 31.15;
                        } else {
                            var55 = 29.28;
                        }
                    }
                } else {
                    if (input[0] <= 4.5) {
                        if (input[1] <= 35.98499870300293) {
                            var55 = 35.17;
                        } else {
                            if (input[2] <= 154.50500106811523) {
                                var55 = 35.3;
                            } else {
                                var55 = 35.22;
                            }
                        }
                    } else {
                        var55 = 32.07;
                    }
                }
            } else {
                if (input[1] <= 34.10500144958496) {
                    if (input[2] <= 81.66999697685242) {
                        var55 = 32.94;
                    } else {
                        var55 = 32.91;
                    }
                } else {
                    if (input[2] <= 174.34500122070312) {
                        if (input[2] <= 45.665000915527344) {
                            var55 = 31.17;
                        } else {
                            if (input[2] <= 118.94500350952148) {
                                var55 = 30.22;
                            } else {
                                var55 = 30.63;
                            }
                        }
                    } else {
                        if (input[0] <= 8.5) {
                            var55 = 30.13;
                        } else {
                            if (input[0] <= 10.5) {
                                var55 = 28.17;
                            } else {
                                var55 = 27.52;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[1] <= 31.25) {
                if (input[0] <= 10.5) {
                    var55 = 80.11;
                } else {
                    var55 = 83.02;
                }
            } else {
                if (input[2] <= 180.48499298095703) {
                    var55 = 84.62;
                } else {
                    var55 = 87.95;
                }
            }
        } else {
            if (input[2] <= 154.01499938964844) {
                if (input[0] <= 5.5) {
                    var55 = 82.02;
                } else {
                    var55 = 82.48;
                }
            } else {
                if (input[1] <= 48.14500045776367) {
                    if (input[1] <= 39.84000015258789) {
                        if (input[0] <= 6.0) {
                            var55 = 78.32;
                        } else {
                            var55 = 79.55;
                        }
                    } else {
                        if (input[2] <= 177.6300048828125) {
                            if (input[1] <= 45.295000076293945) {
                                var55 = 76.33;
                            } else {
                                var55 = 75.92;
                            }
                        } else {
                            if (input[0] <= 6.0) {
                                var55 = 74.09;
                            } else {
                                var55 = 74.62;
                            }
                        }
                    }
                } else {
                    var55 = 80.28;
                }
            }
        }
    }
    double var56;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.67000102996826) {
            if (input[1] <= 28.320000648498535) {
                if (input[1] <= 26.505000114440918) {
                    if (input[0] <= 8.5) {
                        if (input[2] <= 118.43000411987305) {
                            if (input[1] <= 22.15499973297119) {
                                if (input[1] <= 21.149999618530273) {
                                    var56 = 39.78;
                                } else {
                                    var56 = 39.52;
                                }
                            } else {
                                var56 = 36.77;
                            }
                        } else {
                            if (input[1] <= 25.125) {
                                if (input[1] <= 23.21500015258789) {
                                    if (input[2] <= 163.57500457763672) {
                                        var56 = 34.54;
                                    } else {
                                        if (input[2] <= 206.34000396728516) {
                                            var56 = 35.59;
                                        } else {
                                            var56 = 35.42;
                                        }
                                    }
                                } else {
                                    var56 = 36.76;
                                }
                            } else {
                                var56 = 39.98;
                            }
                        }
                    } else {
                        var56 = 41.93;
                    }
                } else {
                    if (input[1] <= 27.260000228881836) {
                        var56 = 34.54;
                    } else {
                        var56 = 34.8;
                    }
                }
            } else {
                var56 = 40.31;
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[1] <= 35.75) {
                    if (input[1] <= 33.05500030517578) {
                        var56 = 33.27;
                    } else {
                        if (input[0] <= 5.5) {
                            var56 = 35.17;
                        } else {
                            var56 = 35.16;
                        }
                    }
                } else {
                    if (input[0] <= 4.5) {
                        var56 = 35.3;
                    } else {
                        if (input[1] <= 37.85999870300293) {
                            if (input[2] <= 45.665000915527344) {
                                var56 = 31.17;
                            } else {
                                var56 = 30.22;
                            }
                        } else {
                            var56 = 28.69;
                        }
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 38.7450008392334) {
                        if (input[2] <= 276.06500244140625) {
                            if (input[1] <= 33.66000175476074) {
                                var56 = 31.15;
                            } else {
                                if (input[2] <= 195.8550033569336) {
                                    var56 = 30.63;
                                } else {
                                    if (input[0] <= 5.0) {
                                        var56 = 30.34;
                                    } else {
                                        var56 = 30.13;
                                    }
                                }
                            }
                        } else {
                            var56 = 32.07;
                        }
                    } else {
                        var56 = 29.5;
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var56 = 28.17;
                    } else {
                        var56 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 31.1850004196167) {
                    var56 = 80.11;
                } else {
                    if (input[0] <= 6.0) {
                        var56 = 87.95;
                    } else {
                        var56 = 84.62;
                    }
                }
            } else {
                if (input[1] <= 48.13999938964844) {
                    if (input[1] <= 41.52499961853027) {
                        if (input[0] <= 6.0) {
                            var56 = 78.32;
                        } else {
                            var56 = 79.55;
                        }
                    } else {
                        if (input[1] <= 46.974998474121094) {
                            var56 = 74.09;
                        } else {
                            var56 = 74.62;
                        }
                    }
                } else {
                    var56 = 80.28;
                }
            }
        } else {
            var56 = 70.41;
        }
    }
    double var57;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[0] <= 5.5) {
                if (input[2] <= 202.2550048828125) {
                    if (input[1] <= 22.190000534057617) {
                        if (input[0] <= 2.5) {
                            var57 = 34.54;
                        } else {
                            if (input[0] <= 4.0) {
                                var57 = 35.16;
                            } else {
                                var57 = 35.59;
                            }
                        }
                    } else {
                        if (input[1] <= 23.890000343322754) {
                            var57 = 36.77;
                        } else {
                            var57 = 39.14;
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var57 = 39.67;
                    } else {
                        var57 = 39.98;
                    }
                }
            } else {
                if (input[1] <= 21.274999618530273) {
                    if (input[2] <= 161.19500350952148) {
                        var57 = 39.78;
                    } else {
                        var57 = 35.42;
                    }
                } else {
                    var57 = 44.31;
                }
            }
        } else {
            if (input[1] <= 34.46500015258789) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 234.93000030517578) {
                        var57 = 31.15;
                    } else {
                        var57 = 30.34;
                    }
                } else {
                    if (input[1] <= 26.795000076293945) {
                        var57 = 32.23;
                    } else {
                        if (input[2] <= 5.509999990463257) {
                            var57 = 36.43;
                        } else {
                            if (input[2] <= 31.78999972343445) {
                                var57 = 32.94;
                            } else {
                                if (input[2] <= 124.62999725341797) {
                                    if (input[2] <= 74.75) {
                                        var57 = 34.8;
                                    } else {
                                        var57 = 35.17;
                                    }
                                } else {
                                    if (input[1] <= 30.155000686645508) {
                                        var57 = 34.54;
                                    } else {
                                        var57 = 32.91;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 83.28999710083008) {
                        var57 = 29.28;
                    } else {
                        if (input[2] <= 154.50500106811523) {
                            var57 = 35.3;
                        } else {
                            var57 = 35.22;
                        }
                    }
                } else {
                    if (input[2] <= 264.54000091552734) {
                        if (input[0] <= 8.5) {
                            if (input[0] <= 5.5) {
                                if (input[1] <= 39.045000076293945) {
                                    var57 = 28.69;
                                } else {
                                    var57 = 26.88;
                                }
                            } else {
                                if (input[1] <= 36.65999984741211) {
                                    var57 = 30.13;
                                } else {
                                    var57 = 30.22;
                                }
                            }
                        } else {
                            if (input[0] <= 10.5) {
                                var57 = 28.17;
                            } else {
                                var57 = 27.52;
                            }
                        }
                    } else {
                        var57 = 32.07;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 33.92500114440918) {
            if (input[2] <= 276.01499938964844) {
                if (input[2] <= 217.37998962402344) {
                    var57 = 88.23;
                } else {
                    var57 = 87.95;
                }
            } else {
                var57 = 83.02;
            }
        } else {
            if (input[2] <= 171.34000396728516) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var57 = 82.02;
                    } else {
                        var57 = 80.28;
                    }
                } else {
                    var57 = 75.92;
                }
            } else {
                if (input[0] <= 5.5) {
                    if (input[2] <= 241.43500518798828) {
                        var57 = 74.09;
                    } else {
                        var57 = 70.41;
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var57 = 76.33;
                    } else {
                        var57 = 79.55;
                    }
                }
            }
        }
    }
    double var58;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[1] <= 22.085000038146973) {
                if (input[0] <= 7.0) {
                    var58 = 44.31;
                } else {
                    if (input[2] <= 129.06500339508057) {
                        var58 = 39.52;
                    } else {
                        var58 = 35.42;
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[2] <= 224.75499725341797) {
                        if (input[1] <= 27.864999771118164) {
                            if (input[0] <= 7.5) {
                                if (input[1] <= 22.190000534057617) {
                                    var58 = 34.54;
                                } else {
                                    if (input[1] <= 25.880000114440918) {
                                        if (input[1] <= 23.28499984741211) {
                                            var58 = 36.77;
                                        } else {
                                            var58 = 36.76;
                                        }
                                    } else {
                                        if (input[0] <= 6.5) {
                                            var58 = 34.8;
                                        } else {
                                            var58 = 36.43;
                                        }
                                    }
                                }
                            } else {
                                var58 = 32.23;
                            }
                        } else {
                            var58 = 32.47;
                        }
                    } else {
                        var58 = 39.98;
                    }
                } else {
                    if (input[1] <= 29.869999885559082) {
                        if (input[2] <= 176.31000518798828) {
                            if (input[0] <= 10.5) {
                                var58 = 37.89;
                            } else {
                                var58 = 40.31;
                            }
                        } else {
                            var58 = 41.93;
                        }
                    } else {
                        var58 = 36.25;
                    }
                }
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[0] <= 4.5) {
                    if (input[2] <= 236.96500396728516) {
                        if (input[2] <= 94.42499923706055) {
                            var58 = 35.17;
                        } else {
                            if (input[1] <= 38.44999885559082) {
                                var58 = 35.3;
                            } else {
                                var58 = 35.22;
                            }
                        }
                    } else {
                        var58 = 30.34;
                    }
                } else {
                    if (input[1] <= 33.560001373291016) {
                        if (input[1] <= 31.70500087738037) {
                            var58 = 32.94;
                        } else {
                            var58 = 33.27;
                        }
                    } else {
                        if (input[0] <= 10.5) {
                            if (input[1] <= 38.28499984741211) {
                                if (input[0] <= 5.5) {
                                    var58 = 32.07;
                                } else {
                                    if (input[2] <= 45.665000915527344) {
                                        var58 = 31.17;
                                    } else {
                                        if (input[0] <= 7.0) {
                                            var58 = 30.22;
                                        } else {
                                            var58 = 30.13;
                                        }
                                    }
                                }
                            } else {
                                var58 = 28.69;
                            }
                        } else {
                            var58 = 27.52;
                        }
                    }
                }
            } else {
                if (input[0] <= 3.5) {
                    var58 = 29.28;
                } else {
                    var58 = 29.5;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 6.0) {
                var58 = 87.95;
            } else {
                if (input[2] <= 186.67000579833984) {
                    var58 = 84.62;
                } else {
                    var58 = 83.02;
                }
            }
        } else {
            if (input[1] <= 46.119998931884766) {
                if (input[2] <= 108.48000144958496) {
                    var58 = 82.02;
                } else {
                    if (input[0] <= 10.5) {
                        var58 = 76.33;
                    } else {
                        var58 = 79.55;
                    }
                }
            } else {
                if (input[2] <= 168.19000244140625) {
                    var58 = 75.92;
                } else {
                    if (input[2] <= 186.8350067138672) {
                        var58 = 74.62;
                    } else {
                        var58 = 74.09;
                    }
                }
            }
        }
    }
    double var59;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 24.114999771118164) {
                if (input[0] <= 4.0) {
                    if (input[1] <= 21.670000076293945) {
                        var59 = 39.67;
                    } else {
                        if (input[1] <= 22.190000534057617) {
                            var59 = 34.54;
                        } else {
                            var59 = 36.77;
                        }
                    }
                } else {
                    if (input[0] <= 6.5) {
                        var59 = 44.31;
                    } else {
                        if (input[2] <= 156.00000381469727) {
                            if (input[0] <= 7.5) {
                                var59 = 39.78;
                            } else {
                                if (input[1] <= 22.984999656677246) {
                                    var59 = 39.52;
                                } else {
                                    var59 = 39.48;
                                }
                            }
                        } else {
                            var59 = 41.93;
                        }
                    }
                }
            } else {
                if (input[2] <= 76.15499877929688) {
                    if (input[0] <= 7.5) {
                        if (input[1] <= 27.90999984741211) {
                            var59 = 36.43;
                        } else {
                            var59 = 34.91;
                        }
                    } else {
                        if (input[2] <= 35.429999113082886) {
                            var59 = 32.94;
                        } else {
                            var59 = 32.23;
                        }
                    }
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[2] <= 91.59000015258789) {
                            var59 = 40.31;
                        } else {
                            if (input[1] <= 30.74000072479248) {
                                var59 = 37.89;
                            } else {
                                var59 = 38.4;
                            }
                        }
                    } else {
                        if (input[1] <= 26.505000114440918) {
                            if (input[2] <= 211.33999633789062) {
                                var59 = 36.76;
                            } else {
                                var59 = 39.98;
                            }
                        } else {
                            if (input[2] <= 177.875) {
                                var59 = 33.27;
                            } else {
                                var59 = 34.54;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.44000053405762) {
                if (input[0] <= 10.5) {
                    if (input[1] <= 33.3650016784668) {
                        var59 = 32.91;
                    } else {
                        if (input[1] <= 37.364999771118164) {
                            if (input[1] <= 36.19000053405762) {
                                if (input[0] <= 2.5) {
                                    var59 = 30.34;
                                } else {
                                    if (input[2] <= 114.49499893188477) {
                                        var59 = 31.17;
                                    } else {
                                        var59 = 31.15;
                                    }
                                }
                            } else {
                                if (input[2] <= 147.95000076293945) {
                                    var59 = 30.22;
                                } else {
                                    var59 = 30.13;
                                }
                            }
                        } else {
                            var59 = 32.07;
                        }
                    }
                } else {
                    var59 = 27.52;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        var59 = 29.28;
                    } else {
                        var59 = 29.5;
                    }
                } else {
                    if (input[1] <= 39.20000076293945) {
                        var59 = 28.17;
                    } else {
                        var59 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.27500057220459) {
                var59 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var59 = 80.11;
                } else {
                    if (input[2] <= 259.4050064086914) {
                        if (input[2] <= 195.11000061035156) {
                            if (input[0] <= 5.5) {
                                var59 = 82.02;
                            } else {
                                var59 = 82.48;
                            }
                        } else {
                            var59 = 79.55;
                        }
                    } else {
                        var59 = 83.02;
                    }
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[1] <= 47.19499969482422) {
                    if (input[1] <= 46.974998474121094) {
                        var59 = 74.09;
                    } else {
                        var59 = 74.62;
                    }
                } else {
                    var59 = 75.92;
                }
            } else {
                var59 = 70.41;
            }
        }
    }
    double var60;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 5.5) {
                    if (input[2] <= 202.2550048828125) {
                        if (input[1] <= 23.890000343322754) {
                            if (input[2] <= 112.84000396728516) {
                                var60 = 36.77;
                            } else {
                                if (input[1] <= 21.770000457763672) {
                                    if (input[1] <= 21.27999973297119) {
                                        var60 = 35.16;
                                    } else {
                                        var60 = 35.59;
                                    }
                                } else {
                                    var60 = 34.54;
                                }
                            }
                        } else {
                            var60 = 39.14;
                        }
                    } else {
                        if (input[1] <= 23.579999923706055) {
                            var60 = 39.67;
                        } else {
                            var60 = 39.98;
                        }
                    }
                } else {
                    if (input[1] <= 21.274999618530273) {
                        var60 = 35.42;
                    } else {
                        if (input[0] <= 7.5) {
                            var60 = 44.31;
                        } else {
                            var60 = 41.93;
                        }
                    }
                }
            } else {
                if (input[2] <= 136.86500549316406) {
                    if (input[1] <= 27.005000114440918) {
                        var60 = 32.23;
                    } else {
                        if (input[1] <= 28.079999923706055) {
                            var60 = 36.43;
                        } else {
                            if (input[0] <= 5.5) {
                                var60 = 38.4;
                            } else {
                                var60 = 37.89;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        if (input[2] <= 180.4800033569336) {
                            var60 = 33.27;
                        } else {
                            var60 = 32.47;
                        }
                    } else {
                        var60 = 34.54;
                    }
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[2] <= 182.67499542236328) {
                    if (input[0] <= 5.0) {
                        if (input[2] <= 94.42499923706055) {
                            var60 = 35.17;
                        } else {
                            var60 = 35.3;
                        }
                    } else {
                        if (input[2] <= 88.46999740600586) {
                            var60 = 31.17;
                        } else {
                            var60 = 32.91;
                        }
                    }
                } else {
                    if (input[1] <= 33.66000175476074) {
                        var60 = 31.15;
                    } else {
                        if (input[1] <= 35.10500144958496) {
                            var60 = 30.34;
                        } else {
                            var60 = 30.13;
                        }
                    }
                }
            } else {
                if (input[0] <= 7.5) {
                    if (input[2] <= 54.564998626708984) {
                        var60 = 31.5;
                    } else {
                        if (input[1] <= 38.94500160217285) {
                            var60 = 30.63;
                        } else {
                            var60 = 29.28;
                        }
                    }
                } else {
                    var60 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.34000015258789) {
                var60 = 88.23;
            } else {
                if (input[2] <= 162.93000602722168) {
                    var60 = 82.02;
                } else {
                    var60 = 83.02;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[0] <= 10.5) {
                    var60 = 80.28;
                } else {
                    var60 = 75.92;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[1] <= 46.974998474121094) {
                        var60 = 74.09;
                    } else {
                        var60 = 74.62;
                    }
                } else {
                    var60 = 70.41;
                }
            }
        }
    }
    double var61;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 24.114999771118164) {
                if (input[0] <= 4.0) {
                    var61 = 34.54;
                } else {
                    if (input[2] <= 221.1550064086914) {
                        if (input[0] <= 6.5) {
                            var61 = 44.31;
                        } else {
                            if (input[2] <= 156.00000381469727) {
                                if (input[0] <= 8.0) {
                                    var61 = 39.78;
                                } else {
                                    var61 = 39.48;
                                }
                            } else {
                                var61 = 41.93;
                            }
                        }
                    } else {
                        var61 = 35.42;
                    }
                }
            } else {
                if (input[2] <= 136.86500549316406) {
                    if (input[2] <= 76.15499877929688) {
                        if (input[1] <= 27.90999984741211) {
                            var61 = 36.43;
                        } else {
                            var61 = 34.91;
                        }
                    } else {
                        if (input[0] <= 10.5) {
                            if (input[1] <= 27.09500026702881) {
                                var61 = 39.14;
                            } else {
                                if (input[0] <= 5.5) {
                                    var61 = 38.4;
                                } else {
                                    var61 = 37.89;
                                }
                            }
                        } else {
                            var61 = 40.31;
                        }
                    }
                } else {
                    if (input[0] <= 5.0) {
                        var61 = 36.76;
                    } else {
                        if (input[1] <= 27.65499973297119) {
                            var61 = 34.54;
                        } else {
                            if (input[2] <= 180.4800033569336) {
                                var61 = 33.27;
                            } else {
                                var61 = 32.47;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[1] <= 39.06999969482422) {
                    if (input[2] <= 236.96500396728516) {
                        if (input[2] <= 94.42499923706055) {
                            var61 = 35.17;
                        } else {
                            if (input[2] <= 154.50500106811523) {
                                var61 = 35.3;
                            } else {
                                var61 = 35.22;
                            }
                        }
                    } else {
                        var61 = 30.34;
                    }
                } else {
                    if (input[1] <= 39.71000099182129) {
                        if (input[0] <= 3.5) {
                            var61 = 29.28;
                        } else {
                            var61 = 29.5;
                        }
                    } else {
                        var61 = 31.5;
                    }
                }
            } else {
                if (input[0] <= 10.5) {
                    if (input[1] <= 38.510000228881836) {
                        if (input[1] <= 34.6200008392334) {
                            var61 = 32.91;
                        } else {
                            if (input[2] <= 257.91500091552734) {
                                if (input[1] <= 36.19000053405762) {
                                    var61 = 31.17;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[0] <= 7.0) {
                                            var61 = 30.22;
                                        } else {
                                            var61 = 30.13;
                                        }
                                    } else {
                                        var61 = 30.63;
                                    }
                                }
                            } else {
                                var61 = 32.07;
                            }
                        }
                    } else {
                        if (input[2] <= 212.5) {
                            if (input[0] <= 7.0) {
                                var61 = 28.69;
                            } else {
                                var61 = 28.17;
                            }
                        } else {
                            var61 = 26.88;
                        }
                    }
                } else {
                    var61 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 46.334999084472656) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var61 = 87.95;
                    } else {
                        var61 = 88.23;
                    }
                } else {
                    var61 = 84.62;
                }
            } else {
                if (input[0] <= 6.0) {
                    var61 = 82.02;
                } else {
                    var61 = 79.55;
                }
            }
        } else {
            if (input[2] <= 236.56000518798828) {
                if (input[2] <= 168.19000244140625) {
                    var61 = 75.92;
                } else {
                    var61 = 74.62;
                }
            } else {
                var61 = 70.41;
            }
        }
    }
    double var62;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 76.15499877929688) {
                if (input[2] <= 38.499998807907104) {
                    var62 = 32.94;
                } else {
                    var62 = 34.91;
                }
            } else {
                if (input[0] <= 8.0) {
                    if (input[2] <= 138.625) {
                        if (input[0] <= 3.0) {
                            var62 = 38.4;
                        } else {
                            var62 = 39.14;
                        }
                    } else {
                        if (input[2] <= 205.9000015258789) {
                            if (input[1] <= 21.770000457763672) {
                                if (input[0] <= 4.0) {
                                    var62 = 35.16;
                                } else {
                                    var62 = 35.59;
                                }
                            } else {
                                var62 = 34.54;
                            }
                        } else {
                            var62 = 32.47;
                        }
                    }
                } else {
                    if (input[1] <= 23.625) {
                        var62 = 41.93;
                    } else {
                        if (input[2] <= 109.65500259399414) {
                            if (input[2] <= 82.32500076293945) {
                                var62 = 40.31;
                            } else {
                                var62 = 39.48;
                            }
                        } else {
                            if (input[2] <= 172.30500030517578) {
                                var62 = 37.89;
                            } else {
                                var62 = 36.25;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.56500053405762) {
                    if (input[1] <= 35.75) {
                        if (input[0] <= 6.5) {
                            if (input[2] <= 182.67499542236328) {
                                var62 = 32.91;
                            } else {
                                if (input[2] <= 234.93000030517578) {
                                    var62 = 31.15;
                                } else {
                                    var62 = 30.34;
                                }
                            }
                        } else {
                            var62 = 35.16;
                        }
                    } else {
                        if (input[2] <= 257.91500091552734) {
                            if (input[0] <= 8.5) {
                                if (input[1] <= 37.59000015258789) {
                                    if (input[0] <= 7.0) {
                                        var62 = 30.22;
                                    } else {
                                        var62 = 30.13;
                                    }
                                } else {
                                    var62 = 30.63;
                                }
                            } else {
                                var62 = 31.17;
                            }
                        } else {
                            var62 = 32.07;
                        }
                    }
                } else {
                    var62 = 35.22;
                }
            } else {
                if (input[2] <= 54.564998626708984) {
                    var62 = 31.5;
                } else {
                    if (input[0] <= 4.5) {
                        if (input[2] <= 160.4749984741211) {
                            var62 = 29.28;
                        } else {
                            var62 = 29.5;
                        }
                    } else {
                        if (input[2] <= 212.5) {
                            var62 = 28.17;
                        } else {
                            var62 = 26.88;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[1] <= 30.27500057220459) {
                var62 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var62 = 80.11;
                } else {
                    if (input[1] <= 31.860000610351562) {
                        var62 = 83.02;
                    } else {
                        var62 = 84.62;
                    }
                }
            }
        } else {
            if (input[2] <= 171.34000396728516) {
                if (input[2] <= 106.5200023651123) {
                    var62 = 82.02;
                } else {
                    var62 = 80.28;
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[1] <= 45.07499885559082) {
                        if (input[0] <= 5.5) {
                            var62 = 78.32;
                        } else {
                            var62 = 76.33;
                        }
                    } else {
                        if (input[1] <= 46.974998474121094) {
                            var62 = 74.09;
                        } else {
                            var62 = 74.62;
                        }
                    }
                } else {
                    var62 = 70.41;
                }
            }
        }
    }
    double var63;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[1] <= 22.085000038146973) {
                if (input[0] <= 6.5) {
                    var63 = 44.31;
                } else {
                    if (input[2] <= 161.19500350952148) {
                        if (input[0] <= 7.5) {
                            var63 = 39.78;
                        } else {
                            var63 = 39.52;
                        }
                    } else {
                        var63 = 35.42;
                    }
                }
            } else {
                if (input[2] <= 73.08499908447266) {
                    if (input[2] <= 34.249999046325684) {
                        var63 = 36.43;
                    } else {
                        var63 = 32.23;
                    }
                } else {
                    if (input[2] <= 138.625) {
                        if (input[1] <= 23.09000015258789) {
                            var63 = 36.77;
                        } else {
                            if (input[0] <= 10.5) {
                                if (input[1] <= 24.72000026702881) {
                                    var63 = 39.48;
                                } else {
                                    var63 = 39.14;
                                }
                            } else {
                                var63 = 40.31;
                            }
                        }
                    } else {
                        if (input[2] <= 224.75499725341797) {
                            if (input[2] <= 215.9199981689453) {
                                if (input[1] <= 23.21500015258789) {
                                    var63 = 34.54;
                                } else {
                                    if (input[2] <= 202.50499725341797) {
                                        var63 = 36.76;
                                    } else {
                                        var63 = 36.25;
                                    }
                                }
                            } else {
                                var63 = 32.47;
                            }
                        } else {
                            var63 = 39.98;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.834999084472656) {
                    if (input[1] <= 38.39499855041504) {
                        if (input[2] <= 173.2699966430664) {
                            if (input[2] <= 83.63999938964844) {
                                if (input[1] <= 34.09999942779541) {
                                    var63 = 32.94;
                                } else {
                                    var63 = 30.22;
                                }
                            } else {
                                if (input[1] <= 34.3700008392334) {
                                    if (input[2] <= 146.86000061035156) {
                                        var63 = 33.27;
                                    } else {
                                        var63 = 32.91;
                                    }
                                } else {
                                    if (input[1] <= 36.7549991607666) {
                                        var63 = 35.16;
                                    } else {
                                        var63 = 35.3;
                                    }
                                }
                            }
                        } else {
                            if (input[2] <= 195.2699966430664) {
                                var63 = 27.52;
                            } else {
                                if (input[0] <= 6.5) {
                                    if (input[1] <= 35.64000129699707) {
                                        var63 = 31.15;
                                    } else {
                                        var63 = 32.07;
                                    }
                                } else {
                                    var63 = 30.13;
                                }
                            }
                        }
                    } else {
                        var63 = 28.69;
                    }
                } else {
                    var63 = 35.22;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        var63 = 31.5;
                    } else {
                        var63 = 29.5;
                    }
                } else {
                    if (input[1] <= 39.20000076293945) {
                        var63 = 28.17;
                    } else {
                        var63 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 33.31500053405762) {
            if (input[2] <= 221.51998901367188) {
                var63 = 88.23;
            } else {
                if (input[2] <= 280.1549987792969) {
                    var63 = 80.11;
                } else {
                    var63 = 83.02;
                }
            }
        } else {
            if (input[1] <= 39.84000015258789) {
                if (input[0] <= 6.0) {
                    var63 = 78.32;
                } else {
                    var63 = 79.55;
                }
            } else {
                if (input[2] <= 177.6300048828125) {
                    if (input[1] <= 45.295000076293945) {
                        var63 = 76.33;
                    } else {
                        var63 = 75.92;
                    }
                } else {
                    if (input[1] <= 46.974998474121094) {
                        var63 = 74.09;
                    } else {
                        var63 = 74.62;
                    }
                }
            }
        }
    }
    double var64;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 24.114999771118164) {
                if (input[2] <= 132.73500442504883) {
                    if (input[1] <= 21.714999198913574) {
                        var64 = 44.31;
                    } else {
                        if (input[1] <= 22.984999656677246) {
                            var64 = 39.52;
                        } else {
                            var64 = 39.48;
                        }
                    }
                } else {
                    if (input[2] <= 202.2550048828125) {
                        if (input[0] <= 2.5) {
                            var64 = 34.54;
                        } else {
                            var64 = 35.16;
                        }
                    } else {
                        if (input[0] <= 5.0) {
                            var64 = 39.67;
                        } else {
                            var64 = 35.42;
                        }
                    }
                }
            } else {
                if (input[0] <= 5.5) {
                    if (input[1] <= 28.5600004196167) {
                        var64 = 36.76;
                    } else {
                        var64 = 38.4;
                    }
                } else {
                    if (input[2] <= 100.41500091552734) {
                        if (input[2] <= 35.429999113082886) {
                            var64 = 32.94;
                        } else {
                            var64 = 32.23;
                        }
                    } else {
                        if (input[2] <= 136.86500549316406) {
                            var64 = 37.89;
                        } else {
                            if (input[1] <= 31.350000381469727) {
                                if (input[2] <= 213.31499481201172) {
                                    var64 = 36.25;
                                } else {
                                    var64 = 34.54;
                                }
                            } else {
                                var64 = 33.27;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[1] <= 36.57000160217285) {
                        var64 = 31.15;
                    } else {
                        if (input[1] <= 39.71000099182129) {
                            var64 = 29.28;
                        } else {
                            var64 = 31.5;
                        }
                    }
                } else {
                    if (input[1] <= 35.98499870300293) {
                        var64 = 35.17;
                    } else {
                        if (input[2] <= 154.50500106811523) {
                            var64 = 35.3;
                        } else {
                            var64 = 35.22;
                        }
                    }
                }
            } else {
                if (input[1] <= 34.10500144958496) {
                    var64 = 32.91;
                } else {
                    if (input[2] <= 264.54000091552734) {
                        if (input[0] <= 10.0) {
                            if (input[0] <= 5.5) {
                                if (input[1] <= 39.045000076293945) {
                                    var64 = 28.69;
                                } else {
                                    var64 = 26.88;
                                }
                            } else {
                                if (input[1] <= 37.59000015258789) {
                                    if (input[2] <= 147.95000076293945) {
                                        var64 = 30.22;
                                    } else {
                                        var64 = 30.13;
                                    }
                                } else {
                                    var64 = 30.63;
                                }
                            }
                        } else {
                            var64 = 27.52;
                        }
                    } else {
                        var64 = 32.07;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 33.92500114440918) {
            if (input[2] <= 276.01499938964844) {
                var64 = 87.95;
            } else {
                var64 = 83.02;
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[2] <= 99.03999900817871) {
                    var64 = 82.02;
                } else {
                    if (input[2] <= 214.16000366210938) {
                        if (input[1] <= 48.14500045776367) {
                            if (input[2] <= 182.5050048828125) {
                                if (input[2] <= 163.86000061035156) {
                                    var64 = 75.92;
                                } else {
                                    var64 = 76.33;
                                }
                            } else {
                                var64 = 74.09;
                            }
                        } else {
                            var64 = 80.28;
                        }
                    } else {
                        var64 = 79.55;
                    }
                }
            } else {
                var64 = 70.41;
            }
        }
    }
    double var65;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.215001106262207) {
            if (input[0] <= 4.0) {
                if (input[2] <= 192.48500061035156) {
                    if (input[0] <= 2.5) {
                        var65 = 34.54;
                    } else {
                        var65 = 35.16;
                    }
                } else {
                    var65 = 36.76;
                }
            } else {
                if (input[1] <= 26.230000495910645) {
                    if (input[2] <= 225.98500061035156) {
                        if (input[2] <= 110.34500122070312) {
                            if (input[2] <= 89.34500122070312) {
                                if (input[1] <= 22.984999656677246) {
                                    var65 = 39.52;
                                } else {
                                    var65 = 39.48;
                                }
                            } else {
                                var65 = 39.78;
                            }
                        } else {
                            if (input[2] <= 170.30500411987305) {
                                var65 = 44.31;
                            } else {
                                if (input[0] <= 7.0) {
                                    var65 = 39.98;
                                } else {
                                    var65 = 41.93;
                                }
                            }
                        }
                    } else {
                        var65 = 35.42;
                    }
                } else {
                    if (input[1] <= 28.5) {
                        if (input[1] <= 26.795000076293945) {
                            var65 = 32.23;
                        } else {
                            if (input[2] <= 30.609999656677246) {
                                var65 = 36.43;
                            } else {
                                if (input[1] <= 27.260000228881836) {
                                    var65 = 34.54;
                                } else {
                                    if (input[1] <= 27.890000343322754) {
                                        var65 = 34.8;
                                    } else {
                                        var65 = 34.91;
                                    }
                                }
                            }
                        }
                    } else {
                        if (input[0] <= 10.5) {
                            var65 = 37.89;
                        } else {
                            var65 = 40.31;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 100.63999938964844) {
                if (input[1] <= 38.88999938964844) {
                    if (input[1] <= 35.98499870300293) {
                        var65 = 35.17;
                    } else {
                        var65 = 35.3;
                    }
                } else {
                    var65 = 31.5;
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[2] <= 165.7750015258789) {
                        if (input[1] <= 34.3700008392334) {
                            var65 = 32.91;
                        } else {
                            var65 = 35.16;
                        }
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[1] <= 33.66000175476074) {
                                var65 = 31.15;
                            } else {
                                if (input[2] <= 195.8550033569336) {
                                    var65 = 30.63;
                                } else {
                                    if (input[0] <= 5.0) {
                                        var65 = 30.34;
                                    } else {
                                        var65 = 30.13;
                                    }
                                }
                            }
                        } else {
                            var65 = 27.52;
                        }
                    }
                } else {
                    if (input[1] <= 39.28000068664551) {
                        if (input[0] <= 4.5) {
                            var65 = 29.5;
                        } else {
                            if (input[2] <= 145.9650001525879) {
                                var65 = 28.69;
                            } else {
                                var65 = 28.17;
                            }
                        }
                    } else {
                        var65 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 10.5) {
                var65 = 88.23;
            } else {
                if (input[1] <= 31.860000610351562) {
                    var65 = 83.02;
                } else {
                    var65 = 84.62;
                }
            }
        } else {
            if (input[1] <= 44.795000076293945) {
                if (input[2] <= 169.4000015258789) {
                    var65 = 82.48;
                } else {
                    if (input[0] <= 6.0) {
                        var65 = 78.32;
                    } else {
                        var65 = 79.55;
                    }
                }
            } else {
                if (input[2] <= 175.67000579833984) {
                    var65 = 80.28;
                } else {
                    if (input[1] <= 48.43499946594238) {
                        if (input[2] <= 186.8350067138672) {
                            var65 = 74.62;
                        } else {
                            var65 = 74.09;
                        }
                    } else {
                        var65 = 70.41;
                    }
                }
            }
        }
    }
    double var66;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 8.5) {
                if (input[0] <= 4.5) {
                    if (input[2] <= 93.02000045776367) {
                        var66 = 36.77;
                    } else {
                        if (input[1] <= 29.165000915527344) {
                            if (input[0] <= 3.0) {
                                var66 = 39.67;
                            } else {
                                var66 = 39.14;
                            }
                        } else {
                            var66 = 38.4;
                        }
                    }
                } else {
                    if (input[1] <= 27.864999771118164) {
                        if (input[1] <= 27.47000026702881) {
                            if (input[2] <= 121.61000061035156) {
                                var66 = 34.8;
                            } else {
                                if (input[2] <= 206.34000396728516) {
                                    var66 = 35.59;
                                } else {
                                    var66 = 35.42;
                                }
                            }
                        } else {
                            var66 = 36.43;
                        }
                    } else {
                        if (input[2] <= 103.69000244140625) {
                            var66 = 34.91;
                        } else {
                            if (input[0] <= 7.5) {
                                var66 = 32.47;
                            } else {
                                var66 = 33.27;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 29.869999885559082) {
                    if (input[1] <= 26.260000228881836) {
                        var66 = 41.93;
                    } else {
                        var66 = 40.31;
                    }
                } else {
                    if (input[2] <= 107.31999850273132) {
                        var66 = 32.94;
                    } else {
                        var66 = 36.25;
                    }
                }
            }
        } else {
            if (input[0] <= 3.5) {
                if (input[2] <= 54.564998626708984) {
                    var66 = 31.5;
                } else {
                    if (input[2] <= 165.75) {
                        var66 = 29.28;
                    } else {
                        var66 = 30.34;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 94.42499923706055) {
                        var66 = 35.17;
                    } else {
                        if (input[2] <= 154.50500106811523) {
                            var66 = 35.3;
                        } else {
                            var66 = 35.22;
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        if (input[2] <= 130.84499740600586) {
                            var66 = 28.69;
                        } else {
                            if (input[0] <= 7.0) {
                                if (input[1] <= 38.01500129699707) {
                                    if (input[2] <= 223.80999755859375) {
                                        var66 = 32.91;
                                    } else {
                                        var66 = 32.07;
                                    }
                                } else {
                                    var66 = 30.63;
                                }
                            } else {
                                var66 = 30.13;
                            }
                        }
                    } else {
                        var66 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.334999084472656) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 31.25) {
                    if (input[2] <= 280.1549987792969) {
                        var66 = 80.11;
                    } else {
                        var66 = 83.02;
                    }
                } else {
                    if (input[0] <= 6.0) {
                        var66 = 87.95;
                    } else {
                        var66 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 163.4550018310547) {
                    if (input[0] <= 5.5) {
                        var66 = 82.02;
                    } else {
                        var66 = 82.48;
                    }
                } else {
                    if (input[2] <= 179.24500274658203) {
                        var66 = 76.33;
                    } else {
                        if (input[2] <= 210.9000015258789) {
                            var66 = 78.32;
                        } else {
                            var66 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 236.56000518798828) {
                var66 = 74.62;
            } else {
                var66 = 70.41;
            }
        }
    }
    double var67;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 83.17499923706055) {
                if (input[0] <= 7.5) {
                    if (input[1] <= 27.90999984741211) {
                        var67 = 36.43;
                    } else {
                        var67 = 34.91;
                    }
                } else {
                    if (input[1] <= 28.890000343322754) {
                        var67 = 32.23;
                    } else {
                        var67 = 32.94;
                    }
                }
            } else {
                if (input[2] <= 220.24500274658203) {
                    if (input[2] <= 206.51000213623047) {
                        if (input[2] <= 138.74000549316406) {
                            if (input[1] <= 24.460000038146973) {
                                var67 = 39.78;
                            } else {
                                if (input[0] <= 5.5) {
                                    var67 = 38.4;
                                } else {
                                    var67 = 37.89;
                                }
                            }
                        } else {
                            if (input[2] <= 191.69499969482422) {
                                if (input[2] <= 163.57500457763672) {
                                    var67 = 34.54;
                                } else {
                                    var67 = 35.59;
                                }
                            } else {
                                var67 = 36.76;
                            }
                        }
                    } else {
                        if (input[0] <= 5.5) {
                            var67 = 39.67;
                        } else {
                            var67 = 41.93;
                        }
                    }
                } else {
                    if (input[0] <= 6.0) {
                        var67 = 39.98;
                    } else {
                        if (input[1] <= 24.704999923706055) {
                            var67 = 35.42;
                        } else {
                            var67 = 32.47;
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 8.0) {
                if (input[1] <= 38.39499855041504) {
                    if (input[2] <= 186.6999969482422) {
                        if (input[1] <= 33.60000038146973) {
                            var67 = 32.91;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[0] <= 5.5) {
                                    var67 = 35.17;
                                } else {
                                    var67 = 35.16;
                                }
                            } else {
                                var67 = 35.3;
                            }
                        }
                    } else {
                        if (input[0] <= 4.0) {
                            if (input[2] <= 234.93000030517578) {
                                var67 = 31.15;
                            } else {
                                var67 = 30.34;
                            }
                        } else {
                            var67 = 32.07;
                        }
                    }
                } else {
                    if (input[0] <= 4.0) {
                        var67 = 31.5;
                    } else {
                        var67 = 28.69;
                    }
                }
            } else {
                if (input[2] <= 101.06499862670898) {
                    var67 = 31.17;
                } else {
                    if (input[0] <= 10.5) {
                        var67 = 28.17;
                    } else {
                        var67 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[1] <= 32.470001220703125) {
                if (input[0] <= 5.5) {
                    var67 = 87.95;
                } else {
                    var67 = 88.23;
                }
            } else {
                var67 = 84.62;
            }
        } else {
            if (input[1] <= 43.11000061035156) {
                if (input[2] <= 169.4000015258789) {
                    var67 = 82.48;
                } else {
                    if (input[2] <= 210.9000015258789) {
                        var67 = 78.32;
                    } else {
                        var67 = 79.55;
                    }
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    if (input[1] <= 45.07499885559082) {
                        var67 = 76.33;
                    } else {
                        if (input[1] <= 46.974998474121094) {
                            var67 = 74.09;
                        } else {
                            var67 = 74.62;
                        }
                    }
                } else {
                    var67 = 70.41;
                }
            }
        }
    }
    double var68;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.020000457763672) {
            if (input[0] <= 8.5) {
                if (input[2] <= 138.625) {
                    if (input[0] <= 3.0) {
                        var68 = 36.77;
                    } else {
                        if (input[0] <= 6.0) {
                            var68 = 39.14;
                        } else {
                            var68 = 39.52;
                        }
                    }
                } else {
                    if (input[2] <= 191.69499969482422) {
                        if (input[2] <= 163.57500457763672) {
                            var68 = 34.54;
                        } else {
                            var68 = 35.59;
                        }
                    } else {
                        if (input[0] <= 2.5) {
                            var68 = 39.67;
                        } else {
                            if (input[0] <= 5.5) {
                                var68 = 36.76;
                            } else {
                                var68 = 35.42;
                            }
                        }
                    }
                }
            } else {
                var68 = 41.93;
            }
        } else {
            if (input[1] <= 34.46500015258789) {
                if (input[2] <= 239.9199981689453) {
                    if (input[0] <= 3.0) {
                        var68 = 38.4;
                    } else {
                        if (input[2] <= 67.23999786376953) {
                            if (input[1] <= 28.890000343322754) {
                                var68 = 32.23;
                            } else {
                                var68 = 32.94;
                            }
                        } else {
                            if (input[1] <= 31.350000381469727) {
                                if (input[1] <= 29.4399995803833) {
                                    if (input[1] <= 27.699999809265137) {
                                        var68 = 34.54;
                                    } else {
                                        var68 = 34.91;
                                    }
                                } else {
                                    var68 = 36.25;
                                }
                            } else {
                                if (input[2] <= 114.84000396728516) {
                                    var68 = 35.17;
                                } else {
                                    var68 = 33.27;
                                }
                            }
                        }
                    }
                } else {
                    var68 = 30.34;
                }
            } else {
                if (input[1] <= 38.510000228881836) {
                    if (input[0] <= 10.5) {
                        if (input[1] <= 35.75) {
                            var68 = 35.16;
                        } else {
                            if (input[0] <= 5.5) {
                                var68 = 32.07;
                            } else {
                                if (input[0] <= 8.5) {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[1] <= 36.65999984741211) {
                                            var68 = 30.13;
                                        } else {
                                            var68 = 30.22;
                                        }
                                    } else {
                                        var68 = 30.63;
                                    }
                                } else {
                                    var68 = 31.17;
                                }
                            }
                        }
                    } else {
                        var68 = 27.52;
                    }
                } else {
                    if (input[1] <= 39.71000099182129) {
                        if (input[0] <= 4.5) {
                            if (input[1] <= 39.45000076293945) {
                                var68 = 29.5;
                            } else {
                                var68 = 29.28;
                            }
                        } else {
                            if (input[2] <= 212.5) {
                                if (input[0] <= 7.0) {
                                    var68 = 28.69;
                                } else {
                                    var68 = 28.17;
                                }
                            } else {
                                var68 = 26.88;
                            }
                        }
                    } else {
                        var68 = 31.5;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[1] <= 31.25) {
                if (input[0] <= 10.5) {
                    var68 = 80.11;
                } else {
                    var68 = 83.02;
                }
            } else {
                if (input[1] <= 32.470001220703125) {
                    var68 = 87.95;
                } else {
                    var68 = 84.62;
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[1] <= 39.84000015258789) {
                    var68 = 78.32;
                } else {
                    if (input[2] <= 177.6300048828125) {
                        if (input[1] <= 45.295000076293945) {
                            var68 = 76.33;
                        } else {
                            var68 = 75.92;
                        }
                    } else {
                        if (input[2] <= 186.8350067138672) {
                            var68 = 74.62;
                        } else {
                            var68 = 74.09;
                        }
                    }
                }
            } else {
                var68 = 70.41;
            }
        }
    }
    double var69;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[2] <= 69.44499969482422) {
                if (input[0] <= 9.5) {
                    if (input[2] <= 30.609999656677246) {
                        var69 = 36.43;
                    } else {
                        var69 = 34.8;
                    }
                } else {
                    var69 = 32.94;
                }
            } else {
                if (input[1] <= 22.795000076293945) {
                    if (input[1] <= 20.710000038146973) {
                        var69 = 39.78;
                    } else {
                        if (input[2] <= 135.59500122070312) {
                            var69 = 36.77;
                        } else {
                            if (input[2] <= 206.34000396728516) {
                                var69 = 35.59;
                            } else {
                                var69 = 35.42;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 27.09000015258789) {
                        if (input[0] <= 3.5) {
                            var69 = 36.76;
                        } else {
                            if (input[1] <= 23.625) {
                                var69 = 41.93;
                            } else {
                                if (input[1] <= 25.730000495910645) {
                                    if (input[1] <= 24.72000026702881) {
                                        var69 = 39.48;
                                    } else {
                                        var69 = 39.14;
                                    }
                                } else {
                                    var69 = 39.98;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 215.9199981689453) {
                            if (input[2] <= 172.30500030517578) {
                                if (input[0] <= 10.5) {
                                    if (input[2] <= 118.92000198364258) {
                                        var69 = 38.4;
                                    } else {
                                        var69 = 37.89;
                                    }
                                } else {
                                    var69 = 40.31;
                                }
                            } else {
                                var69 = 36.25;
                            }
                        } else {
                            var69 = 32.47;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 37.474998474121094) {
                if (input[0] <= 10.5) {
                    if (input[1] <= 36.19000053405762) {
                        if (input[1] <= 34.665000915527344) {
                            if (input[2] <= 234.93000030517578) {
                                var69 = 31.15;
                            } else {
                                var69 = 30.34;
                            }
                        } else {
                            if (input[2] <= 92.49499893188477) {
                                var69 = 31.17;
                            } else {
                                var69 = 35.16;
                            }
                        }
                    } else {
                        if (input[1] <= 36.65999984741211) {
                            var69 = 30.13;
                        } else {
                            var69 = 30.22;
                        }
                    }
                } else {
                    var69 = 27.52;
                }
            } else {
                if (input[1] <= 39.06999969482422) {
                    if (input[2] <= 154.50500106811523) {
                        var69 = 35.3;
                    } else {
                        var69 = 35.22;
                    }
                } else {
                    var69 = 29.5;
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[1] <= 31.25) {
                if (input[2] <= 280.1549987792969) {
                    var69 = 80.11;
                } else {
                    var69 = 83.02;
                }
            } else {
                if (input[2] <= 180.48499298095703) {
                    var69 = 84.62;
                } else {
                    var69 = 87.95;
                }
            }
        } else {
            if (input[0] <= 10.5) {
                if (input[2] <= 177.28500366210938) {
                    if (input[0] <= 5.5) {
                        var69 = 82.02;
                    } else {
                        var69 = 80.28;
                    }
                } else {
                    var69 = 78.32;
                }
            } else {
                if (input[1] <= 47.19499969482422) {
                    var69 = 74.62;
                } else {
                    var69 = 75.92;
                }
            }
        }
    }
    double var70;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 44.34500002861023) {
                if (input[0] <= 9.5) {
                    var70 = 36.43;
                } else {
                    var70 = 32.94;
                }
            } else {
                if (input[2] <= 136.5449981689453) {
                    if (input[1] <= 21.81999969482422) {
                        var70 = 44.31;
                    } else {
                        if (input[0] <= 3.0) {
                            if (input[2] <= 93.02000045776367) {
                                var70 = 36.77;
                            } else {
                                var70 = 38.4;
                            }
                        } else {
                            if (input[2] <= 82.32500076293945) {
                                var70 = 40.31;
                            } else {
                                if (input[2] <= 109.53999710083008) {
                                    var70 = 39.48;
                                } else {
                                    var70 = 39.14;
                                }
                            }
                        }
                    }
                } else {
                    if (input[1] <= 26.505000114440918) {
                        if (input[1] <= 22.725000381469727) {
                            if (input[2] <= 201.46500396728516) {
                                if (input[0] <= 3.5) {
                                    var70 = 34.54;
                                } else {
                                    var70 = 35.59;
                                }
                            } else {
                                if (input[2] <= 221.47500610351562) {
                                    var70 = 39.67;
                                } else {
                                    var70 = 35.42;
                                }
                            }
                        } else {
                            if (input[0] <= 7.0) {
                                var70 = 39.98;
                            } else {
                                var70 = 41.93;
                            }
                        }
                    } else {
                        if (input[2] <= 213.31499481201172) {
                            if (input[0] <= 10.5) {
                                var70 = 37.89;
                            } else {
                                var70 = 36.25;
                            }
                        } else {
                            if (input[1] <= 27.65499973297119) {
                                var70 = 34.54;
                            } else {
                                var70 = 32.47;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 34.46500015258789) {
                if (input[2] <= 124.62999725341797) {
                    var70 = 35.17;
                } else {
                    if (input[2] <= 182.67499542236328) {
                        var70 = 32.91;
                    } else {
                        var70 = 31.15;
                    }
                }
            } else {
                if (input[0] <= 10.0) {
                    if (input[1] <= 35.94000053405762) {
                        var70 = 35.16;
                    } else {
                        if (input[1] <= 38.510000228881836) {
                            if (input[0] <= 4.5) {
                                var70 = 35.3;
                            } else {
                                if (input[0] <= 5.5) {
                                    var70 = 32.07;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        if (input[1] <= 36.65999984741211) {
                                            var70 = 30.13;
                                        } else {
                                            var70 = 30.22;
                                        }
                                    } else {
                                        var70 = 30.63;
                                    }
                                }
                            }
                        } else {
                            if (input[1] <= 39.71000099182129) {
                                if (input[1] <= 39.01499938964844) {
                                    var70 = 28.69;
                                } else {
                                    if (input[0] <= 3.5) {
                                        var70 = 29.28;
                                    } else {
                                        var70 = 29.5;
                                    }
                                }
                            } else {
                                var70 = 31.5;
                            }
                        }
                    }
                } else {
                    var70 = 27.52;
                }
            }
        }
    } else {
        if (input[1] <= 49.385000228881836) {
            if (input[1] <= 30.34000015258789) {
                var70 = 88.23;
            } else {
                if (input[1] <= 33.46500015258789) {
                    var70 = 83.02;
                } else {
                    if (input[2] <= 171.34000396728516) {
                        if (input[2] <= 161.49500274658203) {
                            var70 = 82.48;
                        } else {
                            var70 = 80.28;
                        }
                    } else {
                        if (input[0] <= 5.5) {
                            var70 = 78.32;
                        } else {
                            var70 = 76.33;
                        }
                    }
                }
            }
        } else {
            var70 = 70.41;
        }
    }
    double var71;
    if (input[3] <= 0.5) {
        if (input[1] <= 22.085000038146973) {
            if (input[2] <= 110.34500122070312) {
                if (input[2] <= 63.910000801086426) {
                    var71 = 39.52;
                } else {
                    var71 = 39.78;
                }
            } else {
                var71 = 44.31;
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[2] <= 221.28499603271484) {
                    if (input[0] <= 10.5) {
                        if (input[1] <= 26.985000610351562) {
                            if (input[2] <= 102.49500274658203) {
                                var71 = 32.23;
                            } else {
                                var71 = 34.54;
                            }
                        } else {
                            if (input[0] <= 3.5) {
                                var71 = 31.15;
                            } else {
                                if (input[1] <= 30.95500087738037) {
                                    if (input[2] <= 103.48500061035156) {
                                        if (input[2] <= 30.609999656677246) {
                                            var71 = 36.43;
                                        } else {
                                            if (input[1] <= 27.890000343322754) {
                                                var71 = 34.8;
                                            } else {
                                                var71 = 34.91;
                                            }
                                        }
                                    } else {
                                        var71 = 37.89;
                                    }
                                } else {
                                    if (input[0] <= 5.0) {
                                        if (input[1] <= 35.98499870300293) {
                                            var71 = 35.17;
                                        } else {
                                            if (input[2] <= 154.50500106811523) {
                                                var71 = 35.3;
                                            } else {
                                                var71 = 35.22;
                                            }
                                        }
                                    } else {
                                        if (input[2] <= 160.67499542236328) {
                                            if (input[0] <= 7.5) {
                                                var71 = 32.91;
                                            } else {
                                                var71 = 31.17;
                                            }
                                        } else {
                                            var71 = 35.16;
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 144.9749984741211) {
                            var71 = 40.31;
                        } else {
                            if (input[1] <= 28.809999465942383) {
                                var71 = 34.54;
                            } else {
                                var71 = 36.25;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var71 = 30.34;
                    } else {
                        if (input[1] <= 33.015000343322754) {
                            var71 = 32.47;
                        } else {
                            var71 = 32.07;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.510000228881836) {
                        var71 = 29.5;
                    } else {
                        var71 = 31.5;
                    }
                } else {
                    if (input[0] <= 7.0) {
                        var71 = 26.88;
                    } else {
                        var71 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[2] <= 167.15499877929688) {
            if (input[0] <= 5.5) {
                var71 = 82.02;
            } else {
                var71 = 88.23;
            }
        } else {
            if (input[1] <= 39.84000015258789) {
                if (input[2] <= 210.9000015258789) {
                    var71 = 78.32;
                } else {
                    var71 = 79.55;
                }
            } else {
                if (input[2] <= 177.6300048828125) {
                    if (input[1] <= 46.239999771118164) {
                        var71 = 76.33;
                    } else {
                        var71 = 80.28;
                    }
                } else {
                    if (input[2] <= 241.43500518798828) {
                        if (input[1] <= 46.974998474121094) {
                            var71 = 74.09;
                        } else {
                            var71 = 74.62;
                        }
                    } else {
                        var71 = 70.41;
                    }
                }
            }
        }
    }
    double var72;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.295000076293945) {
            if (input[0] <= 5.5) {
                if (input[1] <= 23.890000343322754) {
                    if (input[1] <= 21.31999969482422) {
                        var72 = 39.67;
                    } else {
                        if (input[1] <= 22.190000534057617) {
                            if (input[1] <= 21.770000457763672) {
                                var72 = 35.59;
                            } else {
                                var72 = 34.54;
                            }
                        } else {
                            var72 = 36.77;
                        }
                    }
                } else {
                    var72 = 39.14;
                }
            } else {
                if (input[1] <= 22.354999542236328) {
                    var72 = 44.31;
                } else {
                    if (input[2] <= 149.30500411987305) {
                        var72 = 39.48;
                    } else {
                        var72 = 41.93;
                    }
                }
            }
        } else {
            if (input[1] <= 33.150001525878906) {
                if (input[0] <= 4.5) {
                    var72 = 38.4;
                } else {
                    if (input[1] <= 31.350000381469727) {
                        if (input[1] <= 28.5) {
                            if (input[2] <= 37.3199987411499) {
                                var72 = 36.43;
                            } else {
                                if (input[2] <= 144.4949951171875) {
                                    var72 = 34.91;
                                } else {
                                    var72 = 34.54;
                                }
                            }
                        } else {
                            if (input[2] <= 172.30500030517578) {
                                var72 = 37.89;
                            } else {
                                var72 = 36.25;
                            }
                        }
                    } else {
                        var72 = 33.27;
                    }
                }
            } else {
                if (input[0] <= 8.0) {
                    if (input[2] <= 231.69000244140625) {
                        if (input[0] <= 3.5) {
                            if (input[2] <= 123.74499893188477) {
                                var72 = 31.5;
                            } else {
                                var72 = 31.15;
                            }
                        } else {
                            if (input[0] <= 5.0) {
                                if (input[2] <= 94.42499923706055) {
                                    var72 = 35.17;
                                } else {
                                    if (input[2] <= 154.50500106811523) {
                                        var72 = 35.3;
                                    } else {
                                        var72 = 35.22;
                                    }
                                }
                            } else {
                                if (input[2] <= 165.7750015258789) {
                                    var72 = 35.16;
                                } else {
                                    var72 = 30.63;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 276.06500244140625) {
                            if (input[1] <= 36.540000915527344) {
                                var72 = 30.34;
                            } else {
                                var72 = 29.5;
                            }
                        } else {
                            var72 = 32.07;
                        }
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var72 = 28.17;
                    } else {
                        var72 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 30.27500057220459) {
            var72 = 88.23;
        } else {
            if (input[1] <= 46.334999084472656) {
                if (input[1] <= 39.560001373291016) {
                    if (input[2] <= 280.1549987792969) {
                        if (input[2] <= 210.9000015258789) {
                            var72 = 78.32;
                        } else {
                            if (input[2] <= 257.35999298095703) {
                                var72 = 79.55;
                            } else {
                                var72 = 80.11;
                            }
                        }
                    } else {
                        var72 = 83.02;
                    }
                } else {
                    if (input[2] <= 98.63500022888184) {
                        var72 = 82.02;
                    } else {
                        var72 = 82.48;
                    }
                }
            } else {
                if (input[1] <= 48.14500045776367) {
                    if (input[2] <= 168.19000244140625) {
                        var72 = 75.92;
                    } else {
                        var72 = 74.62;
                    }
                } else {
                    var72 = 80.28;
                }
            }
        }
    }
    double var73;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[2] <= 225.98500061035156) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 206.8300018310547) {
                        if (input[1] <= 21.699999809265137) {
                            var73 = 35.16;
                        } else {
                            if (input[2] <= 140.95999908447266) {
                                var73 = 36.77;
                            } else {
                                var73 = 36.76;
                            }
                        }
                    } else {
                        var73 = 39.67;
                    }
                } else {
                    if (input[0] <= 8.5) {
                        if (input[0] <= 4.5) {
                            var73 = 39.14;
                        } else {
                            if (input[0] <= 7.5) {
                                if (input[0] <= 6.0) {
                                    var73 = 39.98;
                                } else {
                                    var73 = 39.78;
                                }
                            } else {
                                var73 = 39.52;
                            }
                        }
                    } else {
                        var73 = 41.93;
                    }
                }
            } else {
                var73 = 35.42;
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 8.5) {
                        if (input[1] <= 37.89999961853027) {
                            if (input[2] <= 124.62999725341797) {
                                if (input[1] <= 26.985000610351562) {
                                    var73 = 32.23;
                                } else {
                                    if (input[2] <= 81.45999908447266) {
                                        if (input[2] <= 63.599998474121094) {
                                            var73 = 34.8;
                                        } else {
                                            var73 = 34.91;
                                        }
                                    } else {
                                        var73 = 35.17;
                                    }
                                }
                            } else {
                                if (input[0] <= 4.0) {
                                    var73 = 31.15;
                                } else {
                                    if (input[2] <= 190.2699966430664) {
                                        var73 = 32.91;
                                    } else {
                                        if (input[0] <= 6.0) {
                                            var73 = 32.07;
                                        } else {
                                            var73 = 32.47;
                                        }
                                    }
                                }
                            }
                        } else {
                            if (input[1] <= 38.44999885559082) {
                                var73 = 35.3;
                            } else {
                                var73 = 35.22;
                            }
                        }
                    } else {
                        var73 = 37.89;
                    }
                } else {
                    if (input[1] <= 33.11500072479248) {
                        if (input[2] <= 112.68499636650085) {
                            var73 = 32.94;
                        } else {
                            var73 = 34.54;
                        }
                    } else {
                        var73 = 27.52;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 54.564998626708984) {
                        var73 = 31.5;
                    } else {
                        if (input[0] <= 3.5) {
                            var73 = 29.28;
                        } else {
                            var73 = 29.5;
                        }
                    }
                } else {
                    var73 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 10.5) {
                    if (input[2] <= 217.37998962402344) {
                        var73 = 88.23;
                    } else {
                        var73 = 87.95;
                    }
                } else {
                    if (input[2] <= 186.67000579833984) {
                        var73 = 84.62;
                    } else {
                        var73 = 83.02;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    if (input[2] <= 98.63500022888184) {
                        var73 = 82.02;
                    } else {
                        var73 = 82.48;
                    }
                } else {
                    if (input[1] <= 36.14000129699707) {
                        var73 = 79.55;
                    } else {
                        var73 = 78.32;
                    }
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[2] <= 173.06500244140625) {
                    var73 = 75.92;
                } else {
                    var73 = 74.09;
                }
            } else {
                var73 = 70.41;
            }
        }
    }
    double var74;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[0] <= 6.5) {
                if (input[0] <= 5.5) {
                    if (input[2] <= 206.8300018310547) {
                        if (input[1] <= 23.21500015258789) {
                            if (input[1] <= 21.770000457763672) {
                                var74 = 35.59;
                            } else {
                                var74 = 34.54;
                            }
                        } else {
                            if (input[1] <= 28.5600004196167) {
                                var74 = 36.76;
                            } else {
                                var74 = 38.4;
                            }
                        }
                    } else {
                        if (input[0] <= 3.5) {
                            var74 = 39.67;
                        } else {
                            var74 = 39.98;
                        }
                    }
                } else {
                    var74 = 44.31;
                }
            } else {
                if (input[2] <= 177.6699981689453) {
                    if (input[1] <= 25.704999923706055) {
                        if (input[0] <= 8.5) {
                            var74 = 39.52;
                        } else {
                            var74 = 39.48;
                        }
                    } else {
                        if (input[2] <= 103.48500061035156) {
                            if (input[0] <= 9.5) {
                                if (input[1] <= 27.90999984741211) {
                                    var74 = 36.43;
                                } else {
                                    var74 = 34.91;
                                }
                            } else {
                                var74 = 32.94;
                            }
                        } else {
                            var74 = 37.89;
                        }
                    }
                } else {
                    if (input[0] <= 7.5) {
                        var74 = 32.47;
                    } else {
                        if (input[2] <= 222.51499938964844) {
                            var74 = 34.54;
                        } else {
                            var74 = 35.42;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 218.81500244140625) {
                if (input[2] <= 134.86999893188477) {
                    if (input[2] <= 100.63999938964844) {
                        if (input[2] <= 67.51499938964844) {
                            if (input[0] <= 6.0) {
                                var74 = 31.5;
                            } else {
                                var74 = 31.17;
                            }
                        } else {
                            var74 = 35.3;
                        }
                    } else {
                        var74 = 28.69;
                    }
                } else {
                    if (input[1] <= 34.4950008392334) {
                        var74 = 31.15;
                    } else {
                        if (input[1] <= 37.19499969482422) {
                            var74 = 35.16;
                        } else {
                            var74 = 35.22;
                        }
                    }
                }
            } else {
                if (input[1] <= 38.55000114440918) {
                    if (input[1] <= 37.08500099182129) {
                        var74 = 30.13;
                    } else {
                        var74 = 32.07;
                    }
                } else {
                    var74 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 6.0) {
                var74 = 87.95;
            } else {
                if (input[1] <= 31.860000610351562) {
                    var74 = 83.02;
                } else {
                    var74 = 84.62;
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[2] <= 99.03999900817871) {
                    var74 = 82.02;
                } else {
                    if (input[1] <= 39.84000015258789) {
                        if (input[2] <= 210.9000015258789) {
                            var74 = 78.32;
                        } else {
                            var74 = 79.55;
                        }
                    } else {
                        if (input[2] <= 182.5050048828125) {
                            if (input[0] <= 10.5) {
                                var74 = 76.33;
                            } else {
                                var74 = 75.92;
                            }
                        } else {
                            var74 = 74.09;
                        }
                    }
                }
            } else {
                var74 = 70.41;
            }
        }
    }
    double var75;
    if (input[3] <= 0.5) {
        if (input[1] <= 26.230000495910645) {
            if (input[0] <= 5.5) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 21.84000015258789) {
                        var75 = 35.59;
                    } else {
                        if (input[1] <= 23.28499984741211) {
                            var75 = 36.77;
                        } else {
                            var75 = 36.76;
                        }
                    }
                } else {
                    if (input[2] <= 221.11000061035156) {
                        var75 = 39.67;
                    } else {
                        var75 = 39.98;
                    }
                }
            } else {
                if (input[2] <= 221.1550064086914) {
                    if (input[2] <= 110.34500122070312) {
                        if (input[1] <= 22.085000038146973) {
                            var75 = 39.78;
                        } else {
                            var75 = 39.48;
                        }
                    } else {
                        if (input[1] <= 22.354999542236328) {
                            var75 = 44.31;
                        } else {
                            var75 = 41.93;
                        }
                    }
                } else {
                    var75 = 35.42;
                }
            }
        } else {
            if (input[1] <= 39.06999969482422) {
                if (input[1] <= 35.75) {
                    if (input[1] <= 26.985000610351562) {
                        var75 = 32.23;
                    } else {
                        if (input[0] <= 6.5) {
                            if (input[2] <= 124.62999725341797) {
                                if (input[2] <= 74.75) {
                                    var75 = 34.8;
                                } else {
                                    var75 = 35.17;
                                }
                            } else {
                                var75 = 32.91;
                            }
                        } else {
                            if (input[1] <= 33.02499961853027) {
                                if (input[1] <= 29.609999656677246) {
                                    if (input[0] <= 8.0) {
                                        var75 = 36.43;
                                    } else {
                                        var75 = 37.89;
                                    }
                                } else {
                                    var75 = 36.25;
                                }
                            } else {
                                var75 = 35.16;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 5.0) {
                        if (input[2] <= 154.50500106811523) {
                            var75 = 35.3;
                        } else {
                            var75 = 35.22;
                        }
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[2] <= 195.8550033569336) {
                                var75 = 30.63;
                            } else {
                                var75 = 30.13;
                            }
                        } else {
                            var75 = 31.17;
                        }
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[0] <= 3.5) {
                            var75 = 29.28;
                        } else {
                            var75 = 29.5;
                        }
                    } else {
                        var75 = 31.5;
                    }
                } else {
                    var75 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[0] <= 5.5) {
                var75 = 87.95;
            } else {
                if (input[1] <= 30.27500057220459) {
                    var75 = 88.23;
                } else {
                    if (input[1] <= 39.41000175476074) {
                        if (input[2] <= 280.1549987792969) {
                            if (input[0] <= 10.5) {
                                var75 = 80.11;
                            } else {
                                var75 = 79.55;
                            }
                        } else {
                            var75 = 83.02;
                        }
                    } else {
                        var75 = 82.48;
                    }
                }
            }
        } else {
            if (input[2] <= 180.54500579833984) {
                if (input[0] <= 10.5) {
                    var75 = 80.28;
                } else {
                    var75 = 75.92;
                }
            } else {
                if (input[1] <= 48.21999931335449) {
                    var75 = 74.09;
                } else {
                    var75 = 70.41;
                }
            }
        }
    }
    double var76;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 21.399999618530273) {
                if (input[1] <= 21.299999237060547) {
                    if (input[2] <= 202.2550048828125) {
                        var76 = 35.16;
                    } else {
                        var76 = 39.67;
                    }
                } else {
                    var76 = 44.31;
                }
            } else {
                if (input[2] <= 76.47999954223633) {
                    if (input[0] <= 7.5) {
                        if (input[0] <= 6.5) {
                            var76 = 34.8;
                        } else {
                            var76 = 34.91;
                        }
                    } else {
                        if (input[2] <= 35.429999113082886) {
                            var76 = 32.94;
                        } else {
                            var76 = 32.23;
                        }
                    }
                } else {
                    if (input[2] <= 136.86500549316406) {
                        if (input[1] <= 23.09000015258789) {
                            var76 = 36.77;
                        } else {
                            if (input[1] <= 27.09500026702881) {
                                if (input[1] <= 24.72000026702881) {
                                    var76 = 39.48;
                                } else {
                                    var76 = 39.14;
                                }
                            } else {
                                if (input[2] <= 118.92000198364258) {
                                    var76 = 38.4;
                                } else {
                                    var76 = 37.89;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 224.75499725341797) {
                            if (input[1] <= 26.274999618530273) {
                                if (input[2] <= 191.69499969482422) {
                                    if (input[0] <= 3.5) {
                                        var76 = 34.54;
                                    } else {
                                        var76 = 35.59;
                                    }
                                } else {
                                    var76 = 36.76;
                                }
                            } else {
                                if (input[2] <= 180.4800033569336) {
                                    var76 = 33.27;
                                } else {
                                    var76 = 32.47;
                                }
                            }
                        } else {
                            var76 = 39.98;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[1] <= 37.89999961853027) {
                    if (input[0] <= 4.0) {
                        if (input[2] <= 234.93000030517578) {
                            var76 = 31.15;
                        } else {
                            var76 = 30.34;
                        }
                    } else {
                        if (input[1] <= 35.51500129699707) {
                            var76 = 32.91;
                        } else {
                            var76 = 32.07;
                        }
                    }
                } else {
                    var76 = 35.3;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.06999969482422) {
                        var76 = 35.22;
                    } else {
                        if (input[1] <= 39.71000099182129) {
                            if (input[2] <= 160.4749984741211) {
                                var76 = 29.28;
                            } else {
                                var76 = 29.5;
                            }
                        } else {
                            var76 = 31.5;
                        }
                    }
                } else {
                    if (input[1] <= 38.510000228881836) {
                        var76 = 30.63;
                    } else {
                        if (input[0] <= 7.0) {
                            var76 = 28.69;
                        } else {
                            var76 = 28.17;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 34.53500175476074) {
                if (input[1] <= 31.25) {
                    if (input[2] <= 280.1549987792969) {
                        var76 = 80.11;
                    } else {
                        var76 = 83.02;
                    }
                } else {
                    if (input[1] <= 32.470001220703125) {
                        var76 = 87.95;
                    } else {
                        var76 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 169.4000015258789) {
                    var76 = 82.48;
                } else {
                    if (input[2] <= 210.9000015258789) {
                        var76 = 78.32;
                    } else {
                        var76 = 79.55;
                    }
                }
            }
        } else {
            if (input[2] <= 182.5050048828125) {
                if (input[1] <= 46.239999771118164) {
                    var76 = 76.33;
                } else {
                    var76 = 80.28;
                }
            } else {
                if (input[2] <= 241.43500518798828) {
                    var76 = 74.09;
                } else {
                    var76 = 70.41;
                }
            }
        }
    }
    double var77;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[2] <= 73.08499908447266) {
                if (input[1] <= 26.985000610351562) {
                    var77 = 32.23;
                } else {
                    var77 = 34.8;
                }
            } else {
                if (input[2] <= 136.5449981689453) {
                    if (input[0] <= 5.0) {
                        if (input[1] <= 23.890000343322754) {
                            var77 = 36.77;
                        } else {
                            var77 = 39.14;
                        }
                    } else {
                        if (input[0] <= 6.5) {
                            var77 = 44.31;
                        } else {
                            if (input[2] <= 89.02000045776367) {
                                var77 = 40.31;
                            } else {
                                var77 = 39.78;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 217.63999938964844) {
                        if (input[2] <= 211.9550018310547) {
                            if (input[1] <= 25.395000457763672) {
                                if (input[0] <= 2.5) {
                                    var77 = 34.54;
                                } else {
                                    var77 = 35.16;
                                }
                            } else {
                                if (input[1] <= 29.609999656677246) {
                                    var77 = 37.89;
                                } else {
                                    var77 = 36.25;
                                }
                            }
                        } else {
                            if (input[1] <= 22.274999618530273) {
                                var77 = 39.67;
                            } else {
                                var77 = 41.93;
                            }
                        }
                    } else {
                        if (input[1] <= 27.65499973297119) {
                            if (input[2] <= 222.51499938964844) {
                                var77 = 34.54;
                            } else {
                                var77 = 35.42;
                            }
                        } else {
                            var77 = 32.47;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 83.63999938964844) {
                    if (input[1] <= 34.09999942779541) {
                        var77 = 32.94;
                    } else {
                        if (input[2] <= 54.915000915527344) {
                            var77 = 31.5;
                        } else {
                            var77 = 30.22;
                        }
                    }
                } else {
                    if (input[2] <= 130.46999740600586) {
                        var77 = 35.3;
                    } else {
                        var77 = 35.16;
                    }
                }
            } else {
                if (input[1] <= 38.989999771118164) {
                    if (input[1] <= 38.56500053405762) {
                        if (input[0] <= 10.0) {
                            if (input[2] <= 276.06500244140625) {
                                if (input[1] <= 33.66000175476074) {
                                    var77 = 31.15;
                                } else {
                                    if (input[1] <= 37.310001373291016) {
                                        if (input[0] <= 5.0) {
                                            var77 = 30.34;
                                        } else {
                                            var77 = 30.13;
                                        }
                                    } else {
                                        var77 = 30.63;
                                    }
                                }
                            } else {
                                var77 = 32.07;
                            }
                        } else {
                            var77 = 27.52;
                        }
                    } else {
                        var77 = 35.22;
                    }
                } else {
                    if (input[0] <= 4.5) {
                        var77 = 29.5;
                    } else {
                        if (input[2] <= 212.5) {
                            var77 = 28.17;
                        } else {
                            var77 = 26.88;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 221.51998901367188) {
                if (input[0] <= 10.5) {
                    var77 = 88.23;
                } else {
                    var77 = 84.62;
                }
            } else {
                if (input[0] <= 10.5) {
                    var77 = 80.11;
                } else {
                    var77 = 83.02;
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[1] <= 41.52499961853027) {
                    if (input[1] <= 36.14000129699707) {
                        var77 = 79.55;
                    } else {
                        var77 = 78.32;
                    }
                } else {
                    if (input[1] <= 47.19499969482422) {
                        if (input[2] <= 186.8350067138672) {
                            var77 = 74.62;
                        } else {
                            var77 = 74.09;
                        }
                    } else {
                        var77 = 75.92;
                    }
                }
            } else {
                var77 = 80.28;
            }
        }
    }
    double var78;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.505000114440918) {
                if (input[0] <= 3.0) {
                    if (input[2] <= 178.7100067138672) {
                        if (input[1] <= 22.190000534057617) {
                            var78 = 34.54;
                        } else {
                            var78 = 36.77;
                        }
                    } else {
                        var78 = 39.67;
                    }
                } else {
                    if (input[2] <= 225.98500061035156) {
                        if (input[2] <= 176.19499969482422) {
                            if (input[2] <= 116.2349967956543) {
                                if (input[2] <= 89.34500122070312) {
                                    if (input[0] <= 8.5) {
                                        var78 = 39.52;
                                    } else {
                                        var78 = 39.48;
                                    }
                                } else {
                                    var78 = 39.78;
                                }
                            } else {
                                var78 = 39.14;
                            }
                        } else {
                            if (input[0] <= 7.0) {
                                var78 = 39.98;
                            } else {
                                var78 = 41.93;
                            }
                        }
                    } else {
                        var78 = 35.42;
                    }
                }
            } else {
                if (input[1] <= 28.71500015258789) {
                    if (input[2] <= 221.28499603271484) {
                        if (input[2] <= 137.78499603271484) {
                            var78 = 34.8;
                        } else {
                            var78 = 34.54;
                        }
                    } else {
                        var78 = 32.47;
                    }
                } else {
                    if (input[1] <= 31.000000953674316) {
                        var78 = 40.31;
                    } else {
                        var78 = 38.4;
                    }
                }
            }
        } else {
            if (input[1] <= 38.39499855041504) {
                if (input[2] <= 173.2699966430664) {
                    if (input[2] <= 81.82500076293945) {
                        if (input[2] <= 45.665000915527344) {
                            var78 = 31.17;
                        } else {
                            var78 = 30.22;
                        }
                    } else {
                        if (input[1] <= 33.60000038146973) {
                            var78 = 32.91;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[0] <= 5.5) {
                                    var78 = 35.17;
                                } else {
                                    var78 = 35.16;
                                }
                            } else {
                                var78 = 35.3;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        if (input[1] <= 37.08500099182129) {
                            if (input[2] <= 216.77999877929688) {
                                var78 = 31.15;
                            } else {
                                if (input[0] <= 5.0) {
                                    var78 = 30.34;
                                } else {
                                    var78 = 30.13;
                                }
                            }
                        } else {
                            var78 = 32.07;
                        }
                    } else {
                        var78 = 27.52;
                    }
                }
            } else {
                if (input[2] <= 87.68999862670898) {
                    var78 = 29.28;
                } else {
                    if (input[0] <= 7.0) {
                        var78 = 28.69;
                    } else {
                        var78 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.27500057220459) {
                var78 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var78 = 80.11;
                } else {
                    if (input[1] <= 37.95500183105469) {
                        if (input[0] <= 6.0) {
                            var78 = 87.95;
                        } else {
                            if (input[1] <= 31.860000610351562) {
                                var78 = 83.02;
                            } else {
                                var78 = 84.62;
                            }
                        }
                    } else {
                        if (input[0] <= 5.5) {
                            var78 = 82.02;
                        } else {
                            var78 = 82.48;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 47.19499969482422) {
                if (input[1] <= 46.974998474121094) {
                    var78 = 74.09;
                } else {
                    var78 = 74.62;
                }
            } else {
                var78 = 75.92;
            }
        }
    }
    double var79;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 8.5) {
                    if (input[2] <= 132.73500442504883) {
                        if (input[0] <= 7.0) {
                            var79 = 44.31;
                        } else {
                            var79 = 39.52;
                        }
                    } else {
                        if (input[1] <= 25.125) {
                            if (input[2] <= 192.48500061035156) {
                                if (input[0] <= 2.5) {
                                    var79 = 34.54;
                                } else {
                                    if (input[1] <= 21.27999973297119) {
                                        var79 = 35.16;
                                    } else {
                                        var79 = 35.59;
                                    }
                                }
                            } else {
                                if (input[0] <= 2.5) {
                                    var79 = 39.67;
                                } else {
                                    if (input[0] <= 5.5) {
                                        var79 = 36.76;
                                    } else {
                                        var79 = 35.42;
                                    }
                                }
                            }
                        } else {
                            var79 = 39.98;
                        }
                    }
                } else {
                    if (input[2] <= 149.30500411987305) {
                        var79 = 39.48;
                    } else {
                        var79 = 41.93;
                    }
                }
            } else {
                if (input[1] <= 28.454999923706055) {
                    if (input[2] <= 34.249999046325684) {
                        var79 = 36.43;
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[0] <= 7.5) {
                                var79 = 32.47;
                            } else {
                                var79 = 32.23;
                            }
                        } else {
                            var79 = 34.54;
                        }
                    }
                } else {
                    if (input[2] <= 172.30500030517578) {
                        if (input[2] <= 91.59000015258789) {
                            var79 = 40.31;
                        } else {
                            if (input[2] <= 118.92000198364258) {
                                var79 = 38.4;
                            } else {
                                var79 = 37.89;
                            }
                        }
                    } else {
                        var79 = 36.25;
                    }
                }
            }
        } else {
            if (input[0] <= 7.5) {
                if (input[0] <= 6.5) {
                    if (input[0] <= 4.5) {
                        if (input[0] <= 3.5) {
                            if (input[0] <= 2.5) {
                                var79 = 30.34;
                            } else {
                                if (input[1] <= 36.630001068115234) {
                                    var79 = 31.149999999999995;
                                } else {
                                    var79 = 31.5;
                                }
                            }
                        } else {
                            if (input[2] <= 231.69000244140625) {
                                if (input[2] <= 94.42499923706055) {
                                    var79 = 35.17;
                                } else {
                                    if (input[1] <= 38.44999885559082) {
                                        var79 = 35.3;
                                    } else {
                                        var79 = 35.22;
                                    }
                                }
                            } else {
                                var79 = 29.5;
                            }
                        }
                    } else {
                        if (input[1] <= 35.09000015258789) {
                            var79 = 32.91;
                        } else {
                            if (input[1] <= 38.510000228881836) {
                                if (input[0] <= 5.5) {
                                    var79 = 32.07;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        var79 = 30.22;
                                    } else {
                                        var79 = 30.63;
                                    }
                                }
                            } else {
                                var79 = 28.69;
                            }
                        }
                    }
                } else {
                    var79 = 35.16;
                }
            } else {
                if (input[0] <= 10.5) {
                    if (input[1] <= 37.73500061035156) {
                        if (input[0] <= 8.5) {
                            var79 = 30.13;
                        } else {
                            var79 = 31.17;
                        }
                    } else {
                        var79 = 28.17;
                    }
                } else {
                    var79 = 27.52;
                }
            }
        }
    } else {
        if (input[0] <= 5.5) {
            var79 = 87.95;
        } else {
            if (input[1] <= 39.41000175476074) {
                if (input[0] <= 10.5) {
                    var79 = 80.11;
                } else {
                    var79 = 79.55;
                }
            } else {
                var79 = 82.48;
            }
        }
    }
    double var80;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 136.86500549316406) {
                if (input[1] <= 26.020000457763672) {
                    if (input[1] <= 21.714999198913574) {
                        if (input[1] <= 20.8149995803833) {
                            var80 = 39.78;
                        } else {
                            var80 = 44.31;
                        }
                    } else {
                        if (input[2] <= 109.53999710083008) {
                            if (input[1] <= 22.984999656677246) {
                                var80 = 39.52;
                            } else {
                                var80 = 39.48;
                            }
                        } else {
                            var80 = 39.14;
                        }
                    }
                } else {
                    if (input[1] <= 27.005000114440918) {
                        var80 = 32.23;
                    } else {
                        if (input[1] <= 28.079999923706055) {
                            var80 = 36.43;
                        } else {
                            if (input[2] <= 118.92000198364258) {
                                var80 = 38.4;
                            } else {
                                var80 = 37.89;
                            }
                        }
                    }
                }
            } else {
                if (input[2] <= 222.14999389648438) {
                    if (input[2] <= 163.57500457763672) {
                        if (input[1] <= 27.135001182556152) {
                            var80 = 34.54;
                        } else {
                            var80 = 33.27;
                        }
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[1] <= 22.864999771118164) {
                                if (input[2] <= 187.12000274658203) {
                                    var80 = 35.59;
                                } else {
                                    var80 = 35.16;
                                }
                            } else {
                                var80 = 36.76;
                            }
                        } else {
                            var80 = 34.54;
                        }
                    }
                } else {
                    var80 = 39.98;
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[1] <= 38.39499855041504) {
                    if (input[0] <= 8.0) {
                        if (input[1] <= 33.60000038146973) {
                            var80 = 32.91;
                        } else {
                            if (input[1] <= 36.7549991607666) {
                                if (input[0] <= 5.5) {
                                    var80 = 35.17;
                                } else {
                                    var80 = 35.16;
                                }
                            } else {
                                var80 = 35.3;
                            }
                        }
                    } else {
                        var80 = 31.17;
                    }
                } else {
                    if (input[1] <= 39.71000099182129) {
                        if (input[2] <= 87.68999862670898) {
                            var80 = 29.28;
                        } else {
                            var80 = 28.69;
                        }
                    } else {
                        var80 = 31.5;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 231.69000244140625) {
                        var80 = 35.22;
                    } else {
                        if (input[1] <= 36.540000915527344) {
                            var80 = 30.34;
                        } else {
                            var80 = 29.5;
                        }
                    }
                } else {
                    if (input[2] <= 264.54000091552734) {
                        if (input[1] <= 37.14000129699707) {
                            var80 = 27.52;
                        } else {
                            var80 = 26.88;
                        }
                    } else {
                        var80 = 32.07;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 38.23500061035156) {
                if (input[0] <= 10.5) {
                    if (input[0] <= 5.5) {
                        var80 = 87.95;
                    } else {
                        var80 = 88.23;
                    }
                } else {
                    if (input[2] <= 186.67000579833984) {
                        var80 = 84.62;
                    } else {
                        var80 = 83.02;
                    }
                }
            } else {
                if (input[1] <= 44.43499946594238) {
                    var80 = 76.33;
                } else {
                    var80 = 82.02;
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[2] <= 173.06500244140625) {
                    var80 = 75.92;
                } else {
                    var80 = 74.09;
                }
            } else {
                var80 = 70.41;
            }
        }
    }
    double var81;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[0] <= 5.5) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 21.84000015258789) {
                        if (input[2] <= 187.12000274658203) {
                            var81 = 35.59;
                        } else {
                            var81 = 35.16;
                        }
                    } else {
                        if (input[2] <= 140.95999908447266) {
                            var81 = 36.77;
                        } else {
                            var81 = 36.76;
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var81 = 39.67;
                    } else {
                        var81 = 39.98;
                    }
                }
            } else {
                if (input[1] <= 25.494999885559082) {
                    if (input[2] <= 103.6500015258789) {
                        if (input[0] <= 8.5) {
                            var81 = 39.52;
                        } else {
                            var81 = 39.48;
                        }
                    } else {
                        if (input[2] <= 170.30500411987305) {
                            var81 = 44.31;
                        } else {
                            var81 = 41.93;
                        }
                    }
                } else {
                    if (input[1] <= 28.079999923706055) {
                        if (input[2] <= 30.609999656677246) {
                            var81 = 36.43;
                        } else {
                            if (input[0] <= 9.0) {
                                var81 = 34.8;
                            } else {
                                var81 = 34.54;
                            }
                        }
                    } else {
                        if (input[2] <= 109.33000183105469) {
                            var81 = 40.31;
                        } else {
                            if (input[0] <= 10.5) {
                                var81 = 37.89;
                            } else {
                                var81 = 36.25;
                            }
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 173.2699966430664) {
                if (input[2] <= 81.82500076293945) {
                    if (input[2] <= 13.490000486373901) {
                        var81 = 32.94;
                    } else {
                        if (input[1] <= 36.46999931335449) {
                            var81 = 31.17;
                        } else {
                            if (input[1] <= 38.295000076293945) {
                                var81 = 30.22;
                            } else {
                                var81 = 29.28;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 7.5) {
                        if (input[1] <= 36.7549991607666) {
                            if (input[2] <= 128.65499877929688) {
                                var81 = 35.17;
                            } else {
                                var81 = 35.16;
                            }
                        } else {
                            var81 = 35.3;
                        }
                    } else {
                        var81 = 33.27;
                    }
                }
            } else {
                if (input[2] <= 197.7949981689453) {
                    if (input[1] <= 37.03000068664551) {
                        var81 = 27.52;
                    } else {
                        var81 = 28.17;
                    }
                } else {
                    if (input[1] <= 38.52000045776367) {
                        if (input[2] <= 249.83499908447266) {
                            var81 = 31.15;
                        } else {
                            var81 = 32.07;
                        }
                    } else {
                        var81 = 29.5;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 34.53500175476074) {
                if (input[0] <= 6.0) {
                    var81 = 87.95;
                } else {
                    if (input[2] <= 186.67000579833984) {
                        var81 = 84.62;
                    } else {
                        var81 = 83.02;
                    }
                }
            } else {
                if (input[0] <= 6.0) {
                    var81 = 82.02;
                } else {
                    var81 = 79.55;
                }
            }
        } else {
            if (input[2] <= 175.67000579833984) {
                if (input[2] <= 161.9000015258789) {
                    var81 = 75.92;
                } else {
                    var81 = 80.28;
                }
            } else {
                if (input[1] <= 48.43499946594238) {
                    if (input[2] <= 186.8350067138672) {
                        var81 = 74.62;
                    } else {
                        var81 = 74.09;
                    }
                } else {
                    var81 = 70.41;
                }
            }
        }
    }
    double var82;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 7.5) {
                if (input[2] <= 224.75499725341797) {
                    if (input[2] <= 210.4749984741211) {
                        if (input[1] <= 30.570000648498535) {
                            if (input[2] <= 192.48500061035156) {
                                if (input[2] <= 30.609999656677246) {
                                    var82 = 36.43;
                                } else {
                                    if (input[1] <= 21.770000457763672) {
                                        if (input[0] <= 4.0) {
                                            var82 = 35.16;
                                        } else {
                                            var82 = 35.59;
                                        }
                                    } else {
                                        if (input[0] <= 4.0) {
                                            var82 = 34.54;
                                        } else {
                                            if (input[0] <= 6.5) {
                                                var82 = 34.8;
                                            } else {
                                                var82 = 34.91;
                                            }
                                        }
                                    }
                                }
                            } else {
                                var82 = 36.76;
                            }
                        } else {
                            var82 = 38.4;
                        }
                    } else {
                        var82 = 32.47;
                    }
                } else {
                    var82 = 39.98;
                }
            } else {
                if (input[2] <= 217.31999969482422) {
                    if (input[2] <= 148.9800033569336) {
                        if (input[1] <= 25.619999885559082) {
                            var82 = 39.52;
                        } else {
                            var82 = 40.31;
                        }
                    } else {
                        var82 = 41.93;
                    }
                } else {
                    var82 = 34.54;
                }
            }
        } else {
            if (input[2] <= 100.63999938964844) {
                if (input[2] <= 81.82500076293945) {
                    var82 = 30.22;
                } else {
                    if (input[1] <= 35.98499870300293) {
                        var82 = 35.17;
                    } else {
                        var82 = 35.3;
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 38.510000228881836) {
                        if (input[0] <= 7.0) {
                            if (input[0] <= 4.0) {
                                if (input[2] <= 234.93000030517578) {
                                    var82 = 31.149999999999995;
                                } else {
                                    var82 = 30.34;
                                }
                            } else {
                                if (input[1] <= 38.01500129699707) {
                                    if (input[0] <= 5.5) {
                                        var82 = 32.07;
                                    } else {
                                        var82 = 32.91;
                                    }
                                } else {
                                    var82 = 30.63;
                                }
                            }
                        } else {
                            var82 = 30.13;
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            var82 = 29.5;
                        } else {
                            var82 = 28.69;
                        }
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var82 = 28.17;
                    } else {
                        var82 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 221.51998901367188) {
                if (input[0] <= 10.5) {
                    var82 = 88.23;
                } else {
                    var82 = 84.62;
                }
            } else {
                var82 = 80.11;
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[0] <= 10.5) {
                    var82 = 80.28;
                } else {
                    if (input[1] <= 41.59000015258789) {
                        var82 = 79.55;
                    } else {
                        if (input[2] <= 168.19000244140625) {
                            var82 = 75.92;
                        } else {
                            var82 = 74.62;
                        }
                    }
                }
            } else {
                var82 = 70.41;
            }
        }
    }
    double var83;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 136.86500549316406) {
                if (input[2] <= 76.15499877929688) {
                    if (input[2] <= 30.609999656677246) {
                        var83 = 36.43;
                    } else {
                        if (input[2] <= 63.599998474121094) {
                            var83 = 34.8;
                        } else {
                            var83 = 34.91;
                        }
                    }
                } else {
                    if (input[1] <= 21.81999969482422) {
                        if (input[2] <= 110.34500122070312) {
                            var83 = 39.78;
                        } else {
                            var83 = 44.31;
                        }
                    } else {
                        if (input[1] <= 23.890000343322754) {
                            var83 = 36.77;
                        } else {
                            if (input[2] <= 91.59000015258789) {
                                var83 = 40.31;
                            } else {
                                if (input[1] <= 27.09500026702881) {
                                    var83 = 39.14;
                                } else {
                                    if (input[2] <= 118.92000198364258) {
                                        var83 = 38.4;
                                    } else {
                                        var83 = 37.89;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 21.670000076293945) {
                        if (input[1] <= 21.19499969482422) {
                            if (input[0] <= 5.5) {
                                var83 = 35.16;
                            } else {
                                var83 = 35.42;
                            }
                        } else {
                            var83 = 39.67;
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            var83 = 34.54;
                        } else {
                            if (input[2] <= 180.4800033569336) {
                                var83 = 33.27;
                            } else {
                                var83 = 32.47;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 26.9399995803833) {
                        var83 = 41.93;
                    } else {
                        var83 = 36.25;
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[2] <= 165.7750015258789) {
                    if (input[2] <= 83.63999938964844) {
                        var83 = 30.22;
                    } else {
                        if (input[1] <= 34.3700008392334) {
                            var83 = 32.91;
                        } else {
                            if (input[0] <= 5.5) {
                                var83 = 35.3;
                            } else {
                                var83 = 35.16;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        if (input[2] <= 214.0050048828125) {
                            var83 = 30.63;
                        } else {
                            var83 = 30.34;
                        }
                    } else {
                        var83 = 32.07;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[1] <= 39.45000076293945) {
                            var83 = 29.5;
                        } else {
                            var83 = 29.28;
                        }
                    } else {
                        var83 = 31.5;
                    }
                } else {
                    if (input[2] <= 212.5) {
                        if (input[2] <= 145.9650001525879) {
                            var83 = 28.69;
                        } else {
                            var83 = 28.17;
                        }
                    } else {
                        var83 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 44.795000076293945) {
            if (input[1] <= 34.685001373291016) {
                if (input[1] <= 31.560001373291016) {
                    var83 = 88.23;
                } else {
                    var83 = 84.62;
                }
            } else {
                if (input[0] <= 5.5) {
                    var83 = 78.32;
                } else {
                    var83 = 82.48;
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[0] <= 6.0) {
                    var83 = 74.09;
                } else {
                    var83 = 75.92;
                }
            } else {
                var83 = 80.28;
            }
        }
    }
    double var84;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 6.5) {
                if (input[0] <= 5.5) {
                    if (input[2] <= 202.2550048828125) {
                        if (input[1] <= 27.465001106262207) {
                            if (input[0] <= 2.5) {
                                var84 = 34.54;
                            } else {
                                if (input[1] <= 21.27999973297119) {
                                    var84 = 35.16;
                                } else {
                                    var84 = 35.59;
                                }
                            }
                        } else {
                            var84 = 38.4;
                        }
                    } else {
                        if (input[0] <= 3.5) {
                            var84 = 39.67;
                        } else {
                            var84 = 39.98;
                        }
                    }
                } else {
                    var84 = 44.31;
                }
            } else {
                if (input[1] <= 30.90499973297119) {
                    if (input[1] <= 28.5) {
                        if (input[2] <= 47.97499942779541) {
                            if (input[2] <= 18.05500030517578) {
                                var84 = 36.43;
                            } else {
                                var84 = 39.52;
                            }
                        } else {
                            if (input[2] <= 67.23999786376953) {
                                var84 = 32.23;
                            } else {
                                if (input[1] <= 24.119999885559082) {
                                    var84 = 35.42;
                                } else {
                                    if (input[0] <= 9.5) {
                                        var84 = 34.91;
                                    } else {
                                        var84 = 34.54;
                                    }
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 109.33000183105469) {
                            var84 = 40.31;
                        } else {
                            if (input[1] <= 29.609999656677246) {
                                var84 = 37.89;
                            } else {
                                var84 = 36.25;
                            }
                        }
                    }
                } else {
                    if (input[0] <= 10.0) {
                        var84 = 33.27;
                    } else {
                        var84 = 32.94;
                    }
                }
            }
        } else {
            if (input[0] <= 4.5) {
                if (input[0] <= 3.5) {
                    if (input[2] <= 54.564998626708984) {
                        var84 = 31.5;
                    } else {
                        if (input[2] <= 139.5199966430664) {
                            var84 = 29.28;
                        } else {
                            var84 = 31.15;
                        }
                    }
                } else {
                    if (input[1] <= 35.98499870300293) {
                        var84 = 35.17;
                    } else {
                        var84 = 35.3;
                    }
                }
            } else {
                if (input[1] <= 34.10500144958496) {
                    var84 = 32.91;
                } else {
                    if (input[2] <= 88.04000091552734) {
                        if (input[2] <= 45.665000915527344) {
                            var84 = 31.17;
                        } else {
                            var84 = 30.22;
                        }
                    } else {
                        if (input[2] <= 143.43999862670898) {
                            var84 = 28.69;
                        } else {
                            if (input[1] <= 39.20000076293945) {
                                if (input[0] <= 10.5) {
                                    var84 = 28.17;
                                } else {
                                    var84 = 27.52;
                                }
                            } else {
                                var84 = 26.88;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 30.574999809265137) {
                var84 = 80.11;
            } else {
                if (input[1] <= 34.685001373291016) {
                    if (input[0] <= 6.0) {
                        var84 = 87.95;
                    } else {
                        if (input[1] <= 31.860000610351562) {
                            var84 = 83.02;
                        } else {
                            var84 = 84.62;
                        }
                    }
                } else {
                    if (input[0] <= 5.5) {
                        var84 = 78.32;
                    } else {
                        var84 = 82.48;
                    }
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[0] <= 10.5) {
                    var84 = 76.33;
                } else {
                    var84 = 75.92;
                }
            } else {
                var84 = 70.41;
            }
        }
    }
    double var85;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[1] <= 26.230000495910645) {
                if (input[0] <= 5.5) {
                    if (input[1] <= 24.914999961853027) {
                        if (input[1] <= 23.21500015258789) {
                            if (input[0] <= 2.5) {
                                var85 = 34.54;
                            } else {
                                if (input[2] <= 187.12000274658203) {
                                    var85 = 35.59;
                                } else {
                                    var85 = 35.16;
                                }
                            }
                        } else {
                            var85 = 36.76;
                        }
                    } else {
                        if (input[1] <= 25.730000495910645) {
                            var85 = 39.14;
                        } else {
                            var85 = 39.98;
                        }
                    }
                } else {
                    if (input[1] <= 22.354999542236328) {
                        var85 = 44.31;
                    } else {
                        var85 = 41.93;
                    }
                }
            } else {
                if (input[1] <= 28.760000228881836) {
                    if (input[2] <= 34.249999046325684) {
                        var85 = 36.43;
                    } else {
                        if (input[1] <= 26.795000076293945) {
                            var85 = 32.23;
                        } else {
                            if (input[2] <= 221.28499603271484) {
                                if (input[1] <= 27.699999809265137) {
                                    var85 = 34.54;
                                } else {
                                    var85 = 34.91;
                                }
                            } else {
                                var85 = 32.47;
                            }
                        }
                    }
                } else {
                    var85 = 40.31;
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[0] <= 4.5) {
                    if (input[1] <= 33.89500045776367) {
                        var85 = 30.34;
                    } else {
                        if (input[1] <= 35.98499870300293) {
                            var85 = 35.17;
                        } else {
                            if (input[2] <= 154.50500106811523) {
                                var85 = 35.3;
                            } else {
                                var85 = 35.22;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 173.2699966430664) {
                        if (input[1] <= 35.75) {
                            if (input[1] <= 34.3700008392334) {
                                if (input[0] <= 9.0) {
                                    var85 = 32.91;
                                } else {
                                    var85 = 32.94;
                                }
                            } else {
                                var85 = 35.16;
                            }
                        } else {
                            if (input[0] <= 5.5) {
                                var85 = 28.69;
                            } else {
                                if (input[2] <= 45.665000915527344) {
                                    var85 = 31.17;
                                } else {
                                    var85 = 30.22;
                                }
                            }
                        }
                    } else {
                        if (input[2] <= 203.3499984741211) {
                            var85 = 27.52;
                        } else {
                            var85 = 30.13;
                        }
                    }
                }
            } else {
                if (input[2] <= 212.5) {
                    if (input[0] <= 6.0) {
                        var85 = 29.28;
                    } else {
                        var85 = 28.17;
                    }
                } else {
                    var85 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[0] <= 10.5) {
                var85 = 88.23;
            } else {
                if (input[1] <= 31.860000610351562) {
                    var85 = 83.02;
                } else {
                    var85 = 84.62;
                }
            }
        } else {
            if (input[2] <= 99.03999900817871) {
                var85 = 82.02;
            } else {
                if (input[1] <= 49.385000228881836) {
                    if (input[1] <= 48.14500045776367) {
                        if (input[2] <= 183.57500457763672) {
                            if (input[2] <= 177.6300048828125) {
                                if (input[0] <= 10.5) {
                                    var85 = 76.33;
                                } else {
                                    var85 = 75.92;
                                }
                            } else {
                                var85 = 74.62;
                            }
                        } else {
                            if (input[0] <= 6.0) {
                                var85 = 78.32;
                            } else {
                                var85 = 79.55;
                            }
                        }
                    } else {
                        var85 = 80.28;
                    }
                } else {
                    var85 = 70.41;
                }
            }
        }
    }
    double var86;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 217.31999969482422) {
                if (input[2] <= 73.08499908447266) {
                    if (input[1] <= 26.985000610351562) {
                        var86 = 32.23;
                    } else {
                        if (input[2] <= 30.609999656677246) {
                            var86 = 36.43;
                        } else {
                            var86 = 34.8;
                        }
                    }
                } else {
                    if (input[0] <= 5.5) {
                        if (input[1] <= 24.914999961853027) {
                            if (input[2] <= 192.48500061035156) {
                                if (input[2] <= 163.57500457763672) {
                                    var86 = 34.54;
                                } else {
                                    if (input[1] <= 21.27999973297119) {
                                        var86 = 35.16;
                                    } else {
                                        var86 = 35.59;
                                    }
                                }
                            } else {
                                var86 = 36.76;
                            }
                        } else {
                            if (input[1] <= 29.165000915527344) {
                                var86 = 39.14;
                            } else {
                                var86 = 38.4;
                            }
                        }
                    } else {
                        if (input[0] <= 6.5) {
                            var86 = 44.31;
                        } else {
                            if (input[1] <= 29.869999885559082) {
                                if (input[2] <= 156.00000381469727) {
                                    if (input[1] <= 26.55500030517578) {
                                        if (input[2] <= 89.34500122070312) {
                                            var86 = 39.48;
                                        } else {
                                            var86 = 39.78;
                                        }
                                    } else {
                                        var86 = 40.31;
                                    }
                                } else {
                                    var86 = 41.93;
                                }
                            } else {
                                var86 = 36.25;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 7.5) {
                    var86 = 32.47;
                } else {
                    if (input[2] <= 222.51499938964844) {
                        var86 = 34.54;
                    } else {
                        var86 = 35.42;
                    }
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[1] <= 37.89999961853027) {
                    if (input[1] <= 33.53500175476074) {
                        var86 = 32.91;
                    } else {
                        if (input[2] <= 276.06500244140625) {
                            if (input[0] <= 4.0) {
                                var86 = 30.34;
                            } else {
                                if (input[1] <= 36.65999984741211) {
                                    var86 = 30.13;
                                } else {
                                    var86 = 30.22;
                                }
                            }
                        } else {
                            var86 = 32.07;
                        }
                    }
                } else {
                    var86 = 35.3;
                }
            } else {
                if (input[1] <= 39.71000099182129) {
                    if (input[1] <= 38.510000228881836) {
                        var86 = 30.63;
                    } else {
                        if (input[1] <= 39.01499938964844) {
                            var86 = 28.69;
                        } else {
                            if (input[1] <= 39.45000076293945) {
                                var86 = 29.5;
                            } else {
                                var86 = 29.28;
                            }
                        }
                    }
                } else {
                    var86 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 34.53500175476074) {
            if (input[2] <= 273.96998596191406) {
                if (input[0] <= 6.0) {
                    var86 = 87.95;
                } else {
                    var86 = 84.62;
                }
            } else {
                if (input[2] <= 280.1549987792969) {
                    var86 = 80.11;
                } else {
                    var86 = 83.02;
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[1] <= 39.84000015258789) {
                    if (input[2] <= 210.9000015258789) {
                        var86 = 78.32;
                    } else {
                        var86 = 79.55;
                    }
                } else {
                    if (input[2] <= 182.5050048828125) {
                        if (input[2] <= 163.86000061035156) {
                            var86 = 75.92;
                        } else {
                            var86 = 76.33;
                        }
                    } else {
                        var86 = 74.09;
                    }
                }
            } else {
                var86 = 80.28;
            }
        }
    }
    double var87;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[0] <= 3.5) {
                if (input[1] <= 22.190000534057617) {
                    if (input[1] <= 21.630000114440918) {
                        var87 = 35.16;
                    } else {
                        var87 = 34.54;
                    }
                } else {
                    var87 = 36.77;
                }
            } else {
                if (input[0] <= 7.0) {
                    if (input[0] <= 5.5) {
                        if (input[2] <= 181.02499389648438) {
                            var87 = 39.14;
                        } else {
                            var87 = 39.98;
                        }
                    } else {
                        var87 = 44.31;
                    }
                } else {
                    if (input[2] <= 217.31999969482422) {
                        if (input[1] <= 24.925000190734863) {
                            if (input[0] <= 8.5) {
                                var87 = 39.52;
                            } else {
                                var87 = 41.93;
                            }
                        } else {
                            if (input[1] <= 27.855000495910645) {
                                var87 = 32.23;
                            } else {
                                if (input[1] <= 29.869999885559082) {
                                    var87 = 40.31;
                                } else {
                                    var87 = 36.25;
                                }
                            }
                        }
                    } else {
                        if (input[0] <= 10.0) {
                            var87 = 35.42;
                        } else {
                            var87 = 34.54;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 151.9600067138672) {
                if (input[2] <= 81.4749984741211) {
                    if (input[2] <= 54.564998626708984) {
                        if (input[0] <= 10.5) {
                            if (input[2] <= 29.540000915527344) {
                                var87 = 31.17;
                            } else {
                                var87 = 31.5;
                            }
                        } else {
                            var87 = 32.94;
                        }
                    } else {
                        var87 = 29.28;
                    }
                } else {
                    if (input[2] <= 116.65500259399414) {
                        if (input[2] <= 94.42499923706055) {
                            var87 = 35.17;
                        } else {
                            var87 = 35.3;
                        }
                    } else {
                        var87 = 33.27;
                    }
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 39.28000068664551) {
                        if (input[0] <= 5.5) {
                            if (input[1] <= 39.06999969482422) {
                                if (input[1] <= 38.34000015258789) {
                                    if (input[0] <= 4.0) {
                                        var87 = 31.149999999999995;
                                    } else {
                                        var87 = 32.07;
                                    }
                                } else {
                                    var87 = 35.22;
                                }
                            } else {
                                var87 = 29.5;
                            }
                        } else {
                            if (input[1] <= 37.310001373291016) {
                                var87 = 30.13;
                            } else {
                                var87 = 30.63;
                            }
                        }
                    } else {
                        var87 = 26.88;
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var87 = 28.17;
                    } else {
                        var87 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 33.92500114440918) {
                if (input[0] <= 6.0) {
                    var87 = 87.95;
                } else {
                    var87 = 83.02;
                }
            } else {
                if (input[2] <= 114.42500114440918) {
                    var87 = 82.02;
                } else {
                    if (input[1] <= 36.14000129699707) {
                        var87 = 79.55;
                    } else {
                        var87 = 78.32;
                    }
                }
            }
        } else {
            if (input[1] <= 48.43499946594238) {
                if (input[1] <= 46.974998474121094) {
                    var87 = 74.09;
                } else {
                    var87 = 74.62;
                }
            } else {
                var87 = 70.41;
            }
        }
    }
    double var88;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[2] <= 138.74000549316406) {
                if (input[1] <= 21.714999198913574) {
                    if (input[2] <= 110.34500122070312) {
                        var88 = 39.78;
                    } else {
                        var88 = 44.31;
                    }
                } else {
                    if (input[0] <= 3.0) {
                        var88 = 36.77;
                    } else {
                        if (input[2] <= 18.05500030517578) {
                            var88 = 36.43;
                        } else {
                            if (input[2] <= 136.5449981689453) {
                                if (input[0] <= 10.0) {
                                    if (input[0] <= 6.0) {
                                        var88 = 39.14;
                                    } else {
                                        var88 = 39.52;
                                    }
                                } else {
                                    var88 = 40.31;
                                }
                            } else {
                                var88 = 37.89;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 21.770000457763672) {
                    if (input[0] <= 2.5) {
                        var88 = 39.67;
                    } else {
                        if (input[0] <= 4.0) {
                            var88 = 35.16;
                        } else {
                            if (input[1] <= 21.295000076293945) {
                                var88 = 35.42;
                            } else {
                                var88 = 35.59;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 221.28499603271484) {
                        if (input[2] <= 179.75) {
                            var88 = 34.54;
                        } else {
                            var88 = 34.54;
                        }
                    } else {
                        var88 = 32.47;
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[2] <= 236.96500396728516) {
                    if (input[0] <= 5.0) {
                        if (input[1] <= 35.40999984741211) {
                            var88 = 38.4;
                        } else {
                            if (input[1] <= 38.44999885559082) {
                                var88 = 35.3;
                            } else {
                                var88 = 35.22;
                            }
                        }
                    } else {
                        if (input[1] <= 36.21999931335449) {
                            if (input[1] <= 34.3700008392334) {
                                if (input[2] <= 81.66999697685242) {
                                    var88 = 32.94;
                                } else {
                                    var88 = 32.91;
                                }
                            } else {
                                var88 = 35.16;
                            }
                        } else {
                            if (input[2] <= 118.94500350952148) {
                                var88 = 30.22;
                            } else {
                                var88 = 30.63;
                            }
                        }
                    }
                } else {
                    var88 = 30.34;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[2] <= 54.564998626708984) {
                        var88 = 31.5;
                    } else {
                        if (input[2] <= 160.4749984741211) {
                            var88 = 29.28;
                        } else {
                            var88 = 29.5;
                        }
                    }
                } else {
                    if (input[1] <= 39.20000076293945) {
                        var88 = 28.17;
                    } else {
                        var88 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[2] <= 286.6800079345703) {
            if (input[1] <= 38.23500061035156) {
                if (input[1] <= 30.34000015258789) {
                    var88 = 88.23;
                } else {
                    if (input[1] <= 31.860000610351562) {
                        var88 = 83.02;
                    } else {
                        var88 = 84.62;
                    }
                }
            } else {
                if (input[2] <= 99.03999900817871) {
                    var88 = 82.02;
                } else {
                    if (input[1] <= 48.14500045776367) {
                        if (input[2] <= 177.6300048828125) {
                            if (input[1] <= 45.295000076293945) {
                                var88 = 76.33;
                            } else {
                                var88 = 75.92;
                            }
                        } else {
                            var88 = 74.62;
                        }
                    } else {
                        var88 = 80.28;
                    }
                }
            }
        } else {
            var88 = 70.41;
        }
    }
    double var89;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.230000495910645) {
                if (input[2] <= 138.625) {
                    if (input[1] <= 21.714999198913574) {
                        if (input[1] <= 20.8149995803833) {
                            var89 = 39.78;
                        } else {
                            var89 = 44.31;
                        }
                    } else {
                        if (input[0] <= 6.0) {
                            var89 = 39.14;
                        } else {
                            if (input[0] <= 8.5) {
                                var89 = 39.52;
                            } else {
                                var89 = 39.48;
                            }
                        }
                    }
                } else {
                    if (input[1] <= 22.725000381469727) {
                        if (input[0] <= 3.5) {
                            var89 = 34.54;
                        } else {
                            if (input[2] <= 206.34000396728516) {
                                var89 = 35.59;
                            } else {
                                var89 = 35.42;
                            }
                        }
                    } else {
                        if (input[2] <= 206.51000213623047) {
                            var89 = 36.76;
                        } else {
                            if (input[0] <= 7.0) {
                                var89 = 39.98;
                            } else {
                                var89 = 41.93;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 32.48000144958496) {
                    if (input[0] <= 7.5) {
                        if (input[1] <= 27.90999984741211) {
                            var89 = 36.43;
                        } else {
                            var89 = 34.91;
                        }
                    } else {
                        if (input[0] <= 10.0) {
                            if (input[1] <= 29.33500099182129) {
                                var89 = 32.23;
                            } else {
                                var89 = 33.27;
                            }
                        } else {
                            var89 = 34.54;
                        }
                    }
                } else {
                    var89 = 38.4;
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[0] <= 6.5) {
                    if (input[1] <= 38.834999084472656) {
                        if (input[2] <= 100.63999938964844) {
                            var89 = 35.3;
                        } else {
                            if (input[1] <= 33.3650016784668) {
                                var89 = 32.91;
                            } else {
                                if (input[1] <= 38.510000228881836) {
                                    if (input[2] <= 276.06500244140625) {
                                        if (input[1] <= 33.66000175476074) {
                                            var89 = 31.15;
                                        } else {
                                            if (input[2] <= 214.0050048828125) {
                                                var89 = 30.63;
                                            } else {
                                                var89 = 30.34;
                                            }
                                        }
                                    } else {
                                        var89 = 32.07;
                                    }
                                } else {
                                    var89 = 28.69;
                                }
                            }
                        }
                    } else {
                        var89 = 35.22;
                    }
                } else {
                    var89 = 35.16;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.45000076293945) {
                        var89 = 29.5;
                    } else {
                        var89 = 29.28;
                    }
                } else {
                    if (input[0] <= 7.0) {
                        var89 = 26.88;
                    } else {
                        var89 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 41.375) {
            if (input[2] <= 163.875) {
                var89 = 84.62;
            } else {
                if (input[2] <= 280.1549987792969) {
                    if (input[1] <= 33.250000953674316) {
                        var89 = 80.11;
                    } else {
                        var89 = 79.55;
                    }
                } else {
                    var89 = 83.02;
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[2] <= 186.8350067138672) {
                    var89 = 74.62;
                } else {
                    var89 = 74.09;
                }
            } else {
                var89 = 70.41;
            }
        }
    }
    double var90;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.89000129699707) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 25.125) {
                    if (input[1] <= 20.69499969482422) {
                        var90 = 39.78;
                    } else {
                        if (input[1] <= 22.190000534057617) {
                            if (input[1] <= 21.770000457763672) {
                                if (input[1] <= 21.15499973297119) {
                                    var90 = 35.16;
                                } else {
                                    if (input[1] <= 21.295000076293945) {
                                        var90 = 35.42;
                                    } else {
                                        var90 = 35.59;
                                    }
                                }
                            } else {
                                var90 = 34.54;
                            }
                        } else {
                            if (input[0] <= 2.5) {
                                var90 = 36.77;
                            } else {
                                var90 = 36.76;
                            }
                        }
                    }
                } else {
                    var90 = 39.98;
                }
            } else {
                if (input[2] <= 119.12500381469727) {
                    if (input[2] <= 76.15499877929688) {
                        if (input[0] <= 7.5) {
                            if (input[1] <= 27.90999984741211) {
                                var90 = 36.43;
                            } else {
                                var90 = 34.91;
                            }
                        } else {
                            if (input[0] <= 10.0) {
                                var90 = 32.23;
                            } else {
                                var90 = 32.94;
                            }
                        }
                    } else {
                        if (input[0] <= 7.0) {
                            var90 = 38.4;
                        } else {
                            var90 = 40.31;
                        }
                    }
                } else {
                    if (input[1] <= 27.65499973297119) {
                        var90 = 34.54;
                    } else {
                        if (input[0] <= 7.5) {
                            var90 = 32.47;
                        } else {
                            var90 = 33.27;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 165.7750015258789) {
                if (input[2] <= 134.86999893188477) {
                    if (input[1] <= 38.39499855041504) {
                        if (input[0] <= 6.5) {
                            var90 = 35.3;
                        } else {
                            var90 = 31.17;
                        }
                    } else {
                        if (input[2] <= 54.564998626708984) {
                            var90 = 31.5;
                        } else {
                            if (input[1] <= 39.21500015258789) {
                                var90 = 28.69;
                            } else {
                                var90 = 29.28;
                            }
                        }
                    }
                } else {
                    var90 = 35.16;
                }
            } else {
                if (input[0] <= 8.5) {
                    if (input[1] <= 39.06999969482422) {
                        if (input[0] <= 4.5) {
                            var90 = 35.22;
                        } else {
                            if (input[0] <= 5.5) {
                                var90 = 32.07;
                            } else {
                                if (input[1] <= 37.310001373291016) {
                                    var90 = 30.13;
                                } else {
                                    var90 = 30.63;
                                }
                            }
                        }
                    } else {
                        if (input[0] <= 4.5) {
                            var90 = 29.5;
                        } else {
                            var90 = 26.88;
                        }
                    }
                } else {
                    if (input[0] <= 10.5) {
                        var90 = 28.17;
                    } else {
                        var90 = 27.52;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[2] <= 175.05999755859375) {
                if (input[2] <= 128.03499603271484) {
                    if (input[2] <= 67.39999961853027) {
                        var90 = 82.02;
                    } else {
                        var90 = 84.62;
                    }
                } else {
                    var90 = 88.23;
                }
            } else {
                if (input[2] <= 231.64999389648438) {
                    var90 = 78.32;
                } else {
                    var90 = 80.11;
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[1] <= 48.14500045776367) {
                    if (input[1] <= 47.19499969482422) {
                        if (input[0] <= 6.0) {
                            var90 = 74.09;
                        } else {
                            var90 = 74.62;
                        }
                    } else {
                        var90 = 75.92;
                    }
                } else {
                    var90 = 80.28;
                }
            } else {
                var90 = 70.41;
            }
        }
    }
    double var91;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 6.0) {
                if (input[2] <= 206.8300018310547) {
                    if (input[1] <= 22.864999771118164) {
                        if (input[1] <= 21.27999973297119) {
                            var91 = 35.16;
                        } else {
                            var91 = 35.59;
                        }
                    } else {
                        if (input[2] <= 149.11999893188477) {
                            var91 = 38.4;
                        } else {
                            var91 = 36.76;
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var91 = 39.67;
                    } else {
                        var91 = 39.98;
                    }
                }
            } else {
                if (input[2] <= 5.509999990463257) {
                    var91 = 36.43;
                } else {
                    if (input[2] <= 225.12000274658203) {
                        if (input[1] <= 28.28499984741211) {
                            if (input[1] <= 27.380000114440918) {
                                var91 = 32.23;
                            } else {
                                var91 = 32.47;
                            }
                        } else {
                            if (input[2] <= 38.499998807907104) {
                                var91 = 32.94;
                            } else {
                                var91 = 34.91;
                            }
                        }
                    } else {
                        var91 = 35.42;
                    }
                }
            }
        } else {
            if (input[1] <= 38.7450008392334) {
                if (input[2] <= 165.7750015258789) {
                    if (input[2] <= 58.26499938964844) {
                        var91 = 31.17;
                    } else {
                        if (input[1] <= 34.3700008392334) {
                            var91 = 32.91;
                        } else {
                            if (input[2] <= 130.46999740600586) {
                                var91 = 35.3;
                            } else {
                                var91 = 35.16;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        if (input[1] <= 33.66000175476074) {
                            var91 = 31.15;
                        } else {
                            if (input[2] <= 195.8550033569336) {
                                var91 = 30.63;
                            } else {
                                if (input[0] <= 5.0) {
                                    var91 = 30.34;
                                } else {
                                    var91 = 30.13;
                                }
                            }
                        }
                    } else {
                        var91 = 32.07;
                    }
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.45000076293945) {
                        var91 = 29.5;
                    } else {
                        var91 = 29.28;
                    }
                } else {
                    var91 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[2] <= 175.05999755859375) {
                if (input[1] <= 31.560001373291016) {
                    var91 = 88.23;
                } else {
                    if (input[1] <= 37.95500183105469) {
                        var91 = 84.62;
                    } else {
                        var91 = 82.48;
                    }
                }
            } else {
                if (input[2] <= 280.1549987792969) {
                    if (input[0] <= 5.5) {
                        var91 = 78.32;
                    } else {
                        if (input[2] <= 257.35999298095703) {
                            var91 = 79.55;
                        } else {
                            var91 = 80.11;
                        }
                    }
                } else {
                    var91 = 83.02;
                }
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[1] <= 48.14500045776367) {
                    if (input[2] <= 177.6300048828125) {
                        if (input[1] <= 45.295000076293945) {
                            var91 = 76.33;
                        } else {
                            var91 = 75.92;
                        }
                    } else {
                        if (input[2] <= 186.8350067138672) {
                            var91 = 74.62;
                        } else {
                            var91 = 74.09;
                        }
                    }
                } else {
                    var91 = 80.28;
                }
            } else {
                var91 = 70.41;
            }
        }
    }
    double var92;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.225000381469727) {
            if (input[0] <= 7.5) {
                if (input[2] <= 224.75499725341797) {
                    if (input[1] <= 21.399999618530273) {
                        if (input[1] <= 21.179999351501465) {
                            var92 = 35.16;
                        } else {
                            if (input[0] <= 4.0) {
                                var92 = 39.67;
                            } else {
                                var92 = 44.31;
                            }
                        }
                    } else {
                        if (input[2] <= 210.4749984741211) {
                            if (input[1] <= 22.190000534057617) {
                                if (input[1] <= 21.770000457763672) {
                                    var92 = 35.59;
                                } else {
                                    var92 = 34.54;
                                }
                            } else {
                                if (input[2] <= 110.6449966430664) {
                                    if (input[2] <= 30.609999656677246) {
                                        var92 = 36.43;
                                    } else {
                                        if (input[2] <= 77.58499908447266) {
                                            if (input[1] <= 27.890000343322754) {
                                                var92 = 34.8;
                                            } else {
                                                var92 = 34.91;
                                            }
                                        } else {
                                            var92 = 36.77;
                                        }
                                    }
                                } else {
                                    if (input[2] <= 166.7449951171875) {
                                        var92 = 39.14;
                                    } else {
                                        var92 = 36.76;
                                    }
                                }
                            }
                        } else {
                            var92 = 32.47;
                        }
                    }
                } else {
                    var92 = 39.98;
                }
            } else {
                if (input[2] <= 217.31999969482422) {
                    if (input[2] <= 176.31000518798828) {
                        if (input[2] <= 109.65500259399414) {
                            if (input[0] <= 10.5) {
                                if (input[0] <= 8.5) {
                                    var92 = 39.52;
                                } else {
                                    var92 = 39.48;
                                }
                            } else {
                                var92 = 40.31;
                            }
                        } else {
                            var92 = 37.89;
                        }
                    } else {
                        var92 = 41.93;
                    }
                } else {
                    var92 = 34.54;
                }
            }
        } else {
            if (input[0] <= 2.5) {
                var92 = 38.4;
            } else {
                if (input[0] <= 4.5) {
                    if (input[0] <= 3.5) {
                        if (input[1] <= 39.71000099182129) {
                            if (input[1] <= 36.57000160217285) {
                                var92 = 31.15;
                            } else {
                                var92 = 29.28;
                            }
                        } else {
                            var92 = 31.5;
                        }
                    } else {
                        if (input[1] <= 36.42499923706055) {
                            var92 = 35.17;
                        } else {
                            var92 = 35.22;
                        }
                    }
                } else {
                    if (input[1] <= 38.510000228881836) {
                        if (input[0] <= 10.5) {
                            if (input[0] <= 5.5) {
                                var92 = 32.07;
                            } else {
                                if (input[1] <= 36.46999931335449) {
                                    var92 = 31.17;
                                } else {
                                    if (input[1] <= 37.59000015258789) {
                                        var92 = 30.22;
                                    } else {
                                        var92 = 30.63;
                                    }
                                }
                            }
                        } else {
                            var92 = 32.94;
                        }
                    } else {
                        var92 = 28.69;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 32.470001220703125) {
                if (input[1] <= 30.950000762939453) {
                    var92 = 88.23;
                } else {
                    var92 = 87.95;
                }
            } else {
                if (input[2] <= 195.11000061035156) {
                    if (input[1] <= 37.95500183105469) {
                        var92 = 84.62;
                    } else {
                        if (input[0] <= 5.5) {
                            var92 = 82.02;
                        } else {
                            var92 = 82.48;
                        }
                    }
                } else {
                    var92 = 79.55;
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[0] <= 6.0) {
                    var92 = 74.09;
                } else {
                    var92 = 75.92;
                }
            } else {
                var92 = 80.28;
            }
        }
    }
    double var93;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[1] <= 26.505000114440918) {
                if (input[2] <= 225.98500061035156) {
                    if (input[0] <= 3.5) {
                        if (input[1] <= 21.670000076293945) {
                            var93 = 39.67;
                        } else {
                            if (input[2] <= 112.84000396728516) {
                                var93 = 36.77;
                            } else {
                                var93 = 34.54;
                            }
                        }
                    } else {
                        if (input[2] <= 110.34500122070312) {
                            if (input[1] <= 21.149999618530273) {
                                var93 = 39.78;
                            } else {
                                if (input[1] <= 22.984999656677246) {
                                    var93 = 39.52;
                                } else {
                                    var93 = 39.48;
                                }
                            }
                        } else {
                            if (input[1] <= 22.354999542236328) {
                                var93 = 44.31;
                            } else {
                                if (input[1] <= 24.635000228881836) {
                                    var93 = 41.93;
                                } else {
                                    var93 = 39.98;
                                }
                            }
                        }
                    }
                } else {
                    var93 = 35.42;
                }
            } else {
                if (input[1] <= 28.454999923706055) {
                    if (input[2] <= 30.609999656677246) {
                        var93 = 36.43;
                    } else {
                        if (input[1] <= 27.84500026702881) {
                            if (input[1] <= 27.260000228881836) {
                                var93 = 34.54;
                            } else {
                                var93 = 34.8;
                            }
                        } else {
                            var93 = 32.47;
                        }
                    }
                } else {
                    if (input[2] <= 172.30500030517578) {
                        if (input[2] <= 91.59000015258789) {
                            var93 = 40.31;
                        } else {
                            if (input[2] <= 118.92000198364258) {
                                var93 = 38.4;
                            } else {
                                var93 = 37.89;
                            }
                        }
                    } else {
                        var93 = 36.25;
                    }
                }
            }
        } else {
            if (input[1] <= 35.75) {
                if (input[0] <= 9.5) {
                    if (input[1] <= 33.60000038146973) {
                        var93 = 32.91;
                    } else {
                        if (input[1] <= 34.72999954223633) {
                            var93 = 35.17;
                        } else {
                            var93 = 35.16;
                        }
                    }
                } else {
                    var93 = 27.52;
                }
            } else {
                if (input[2] <= 199.8300018310547) {
                    if (input[2] <= 54.564998626708984) {
                        if (input[2] <= 29.540000915527344) {
                            var93 = 31.17;
                        } else {
                            var93 = 31.5;
                        }
                    } else {
                        if (input[1] <= 38.510000228881836) {
                            var93 = 30.63;
                        } else {
                            if (input[1] <= 39.3700008392334) {
                                if (input[1] <= 38.93499946594238) {
                                    var93 = 28.69;
                                } else {
                                    var93 = 28.17;
                                }
                            } else {
                                var93 = 29.28;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 218.81500244140625) {
                        var93 = 35.22;
                    } else {
                        if (input[2] <= 270.79000091552734) {
                            if (input[1] <= 37.81500053405762) {
                                var93 = 30.13;
                            } else {
                                var93 = 29.5;
                            }
                        } else {
                            var93 = 32.07;
                        }
                    }
                }
            }
        }
    } else {
        if (input[1] <= 34.685001373291016) {
            if (input[2] <= 128.03499603271484) {
                var93 = 84.62;
            } else {
                if (input[0] <= 5.5) {
                    var93 = 87.95;
                } else {
                    var93 = 88.23;
                }
            }
        } else {
            if (input[1] <= 48.44000053405762) {
                if (input[1] <= 39.84000015258789) {
                    var93 = 78.32;
                } else {
                    if (input[0] <= 5.5) {
                        var93 = 74.09;
                    } else {
                        if (input[1] <= 45.295000076293945) {
                            var93 = 76.33;
                        } else {
                            var93 = 75.92;
                        }
                    }
                }
            } else {
                var93 = 70.41;
            }
        }
    }
    double var94;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[0] <= 8.5) {
                if (input[0] <= 6.0) {
                    if (input[1] <= 25.125) {
                        if (input[2] <= 140.95999908447266) {
                            var94 = 36.77;
                        } else {
                            var94 = 36.76;
                        }
                    } else {
                        if (input[2] <= 163.39999771118164) {
                            var94 = 38.4;
                        } else {
                            var94 = 39.98;
                        }
                    }
                } else {
                    if (input[2] <= 225.12000274658203) {
                        if (input[1] <= 30.195000648498535) {
                            if (input[2] <= 144.02999877929688) {
                                var94 = 32.23;
                            } else {
                                var94 = 32.47;
                            }
                        } else {
                            var94 = 33.27;
                        }
                    } else {
                        var94 = 35.42;
                    }
                }
            } else {
                if (input[2] <= 176.31000518798828) {
                    if (input[0] <= 10.5) {
                        var94 = 37.89;
                    } else {
                        var94 = 40.31;
                    }
                } else {
                    var94 = 41.93;
                }
            }
        } else {
            if (input[0] <= 7.5) {
                if (input[2] <= 130.84499740600586) {
                    if (input[2] <= 88.04000091552734) {
                        if (input[2] <= 54.915000915527344) {
                            var94 = 31.5;
                        } else {
                            var94 = 30.22;
                        }
                    } else {
                        var94 = 28.69;
                    }
                } else {
                    if (input[0] <= 3.5) {
                        if (input[2] <= 234.93000030517578) {
                            var94 = 31.15;
                        } else {
                            var94 = 30.34;
                        }
                    } else {
                        if (input[2] <= 251.87000274658203) {
                            if (input[2] <= 160.67499542236328) {
                                var94 = 32.91;
                            } else {
                                if (input[0] <= 5.5) {
                                    var94 = 35.22;
                                } else {
                                    var94 = 35.16;
                                }
                            }
                        } else {
                            var94 = 32.07;
                        }
                    }
                }
            } else {
                if (input[1] <= 37.73500061035156) {
                    if (input[0] <= 8.5) {
                        var94 = 30.13;
                    } else {
                        var94 = 31.17;
                    }
                } else {
                    var94 = 28.17;
                }
            }
        }
    } else {
        if (input[1] <= 33.46500015258789) {
            if (input[1] <= 30.34000015258789) {
                var94 = 88.23;
            } else {
                var94 = 83.02;
            }
        } else {
            if (input[2] <= 171.34000396728516) {
                if (input[0] <= 10.5) {
                    if (input[2] <= 161.49500274658203) {
                        if (input[0] <= 5.5) {
                            var94 = 82.02;
                        } else {
                            var94 = 82.48;
                        }
                    } else {
                        var94 = 80.28;
                    }
                } else {
                    var94 = 75.92;
                }
            } else {
                if (input[1] <= 45.07499885559082) {
                    if (input[2] <= 179.24500274658203) {
                        var94 = 76.33;
                    } else {
                        var94 = 78.32;
                    }
                } else {
                    if (input[2] <= 186.8350067138672) {
                        var94 = 74.62;
                    } else {
                        var94 = 74.09;
                    }
                }
            }
        }
    }
    double var95;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.025001525878906) {
            if (input[2] <= 136.86500549316406) {
                if (input[2] <= 76.15499877929688) {
                    if (input[1] <= 24.28499984741211) {
                        var95 = 39.52;
                    } else {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 30.609999656677246) {
                                var95 = 36.43;
                            } else {
                                if (input[0] <= 6.5) {
                                    var95 = 34.8;
                                } else {
                                    var95 = 34.91;
                                }
                            }
                        } else {
                            if (input[0] <= 10.0) {
                                var95 = 32.23;
                            } else {
                                var95 = 32.94;
                            }
                        }
                    }
                } else {
                    if (input[2] <= 83.75500106811523) {
                        if (input[0] <= 10.5) {
                            var95 = 39.48;
                        } else {
                            var95 = 40.31;
                        }
                    } else {
                        if (input[1] <= 21.255000114440918) {
                            var95 = 39.78;
                        } else {
                            if (input[2] <= 93.02000045776367) {
                                var95 = 36.77;
                            } else {
                                if (input[2] <= 118.92000198364258) {
                                    var95 = 38.4;
                                } else {
                                    var95 = 37.89;
                                }
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 27.09000015258789) {
                    if (input[1] <= 25.125) {
                        if (input[1] <= 23.21500015258789) {
                            if (input[1] <= 21.770000457763672) {
                                if (input[1] <= 21.15499973297119) {
                                    var95 = 35.16;
                                } else {
                                    if (input[2] <= 206.34000396728516) {
                                        var95 = 35.59;
                                    } else {
                                        var95 = 35.42;
                                    }
                                }
                            } else {
                                var95 = 34.54;
                            }
                        } else {
                            var95 = 36.76;
                        }
                    } else {
                        var95 = 39.98;
                    }
                } else {
                    if (input[1] <= 30.195000648498535) {
                        var95 = 32.47;
                    } else {
                        var95 = 33.27;
                    }
                }
            }
        } else {
            if (input[1] <= 38.125) {
                if (input[2] <= 212.93000030517578) {
                    if (input[0] <= 5.0) {
                        var95 = 35.3;
                    } else {
                        if (input[2] <= 160.67499542236328) {
                            if (input[1] <= 34.6200008392334) {
                                var95 = 32.91;
                            } else {
                                var95 = 31.17;
                            }
                        } else {
                            var95 = 35.16;
                        }
                    }
                } else {
                    if (input[2] <= 276.06500244140625) {
                        var95 = 30.34;
                    } else {
                        var95 = 32.07;
                    }
                }
            } else {
                if (input[2] <= 202.4800033569336) {
                    if (input[1] <= 39.71000099182129) {
                        if (input[2] <= 118.59500122070312) {
                            var95 = 29.28;
                        } else {
                            var95 = 30.63;
                        }
                    } else {
                        var95 = 31.5;
                    }
                } else {
                    if (input[0] <= 4.5) {
                        var95 = 29.5;
                    } else {
                        var95 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 43.11000061035156) {
            if (input[1] <= 30.27500057220459) {
                var95 = 88.23;
            } else {
                if (input[1] <= 30.574999809265137) {
                    var95 = 80.11;
                } else {
                    if (input[2] <= 122.375) {
                        var95 = 84.62;
                    } else {
                        if (input[1] <= 36.73500061035156) {
                            var95 = 83.02;
                        } else {
                            var95 = 82.48;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 48.14500045776367) {
                if (input[2] <= 177.6300048828125) {
                    if (input[2] <= 163.86000061035156) {
                        var95 = 75.92;
                    } else {
                        var95 = 76.33;
                    }
                } else {
                    if (input[0] <= 6.0) {
                        var95 = 74.09;
                    } else {
                        var95 = 74.62;
                    }
                }
            } else {
                var95 = 80.28;
            }
        }
    }
    double var96;
    if (input[3] <= 0.5) {
        if (input[1] <= 31.350000381469727) {
            if (input[1] <= 26.230000495910645) {
                if (input[1] <= 21.734999656677246) {
                    if (input[1] <= 20.69499969482422) {
                        var96 = 39.78;
                    } else {
                        if (input[0] <= 2.5) {
                            var96 = 39.67;
                        } else {
                            if (input[1] <= 21.15499973297119) {
                                var96 = 35.16;
                            } else {
                                if (input[1] <= 21.295000076293945) {
                                    var96 = 35.42;
                                } else {
                                    var96 = 35.59;
                                }
                            }
                        }
                    }
                } else {
                    if (input[0] <= 3.5) {
                        var96 = 36.76;
                    } else {
                        if (input[0] <= 8.5) {
                            if (input[2] <= 181.02499389648438) {
                                if (input[0] <= 6.0) {
                                    var96 = 39.14;
                                } else {
                                    var96 = 39.52;
                                }
                            } else {
                                var96 = 39.98;
                            }
                        } else {
                            var96 = 41.93;
                        }
                    }
                }
            } else {
                if (input[1] <= 26.795000076293945) {
                    var96 = 32.23;
                } else {
                    if (input[1] <= 27.27999973297119) {
                        var96 = 34.54;
                    } else {
                        if (input[2] <= 139.12999725341797) {
                            if (input[1] <= 27.90999984741211) {
                                var96 = 36.43;
                            } else {
                                var96 = 34.91;
                            }
                        } else {
                            var96 = 36.25;
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.989999771118164) {
                if (input[1] <= 38.834999084472656) {
                    if (input[1] <= 38.510000228881836) {
                        if (input[2] <= 165.7750015258789) {
                            if (input[2] <= 160.67499542236328) {
                                if (input[0] <= 8.5) {
                                    if (input[0] <= 7.0) {
                                        var96 = 32.91;
                                    } else {
                                        var96 = 33.27;
                                    }
                                } else {
                                    var96 = 31.17;
                                }
                            } else {
                                var96 = 35.16;
                            }
                        } else {
                            if (input[0] <= 10.0) {
                                if (input[2] <= 276.06500244140625) {
                                    if (input[1] <= 33.66000175476074) {
                                        var96 = 31.15;
                                    } else {
                                        if (input[2] <= 195.8550033569336) {
                                            var96 = 30.63;
                                        } else {
                                            if (input[1] <= 35.10500144958496) {
                                                var96 = 30.34;
                                            } else {
                                                var96 = 30.13;
                                            }
                                        }
                                    }
                                } else {
                                    var96 = 32.07;
                                }
                            } else {
                                var96 = 27.52;
                            }
                        }
                    } else {
                        var96 = 28.69;
                    }
                } else {
                    var96 = 35.22;
                }
            } else {
                if (input[1] <= 39.71000099182129) {
                    if (input[1] <= 39.170000076293945) {
                        var96 = 28.17;
                    } else {
                        if (input[1] <= 39.45000076293945) {
                            var96 = 29.5;
                        } else {
                            var96 = 29.28;
                        }
                    }
                } else {
                    var96 = 31.5;
                }
            }
        }
    } else {
        if (input[1] <= 33.92500114440918) {
            if (input[2] <= 273.96998596191406) {
                if (input[2] <= 217.37998962402344) {
                    var96 = 88.23;
                } else {
                    var96 = 87.95;
                }
            } else {
                var96 = 80.11;
            }
        } else {
            if (input[1] <= 49.385000228881836) {
                if (input[2] <= 171.34000396728516) {
                    if (input[2] <= 106.5200023651123) {
                        var96 = 82.02;
                    } else {
                        var96 = 80.28;
                    }
                } else {
                    if (input[1] <= 39.69000053405762) {
                        var96 = 79.55;
                    } else {
                        if (input[1] <= 45.07499885559082) {
                            var96 = 76.33;
                        } else {
                            var96 = 74.09;
                        }
                    }
                }
            } else {
                var96 = 70.41;
            }
        }
    }
    double var97;
    if (input[3] <= 0.5) {
        if (input[1] <= 25.22000026702881) {
            if (input[0] <= 4.0) {
                if (input[1] <= 21.670000076293945) {
                    var97 = 39.67;
                } else {
                    if (input[1] <= 22.190000534057617) {
                        var97 = 34.54;
                    } else {
                        var97 = 36.77;
                    }
                }
            } else {
                if (input[2] <= 221.1550064086914) {
                    if (input[2] <= 110.34500122070312) {
                        if (input[1] <= 22.085000038146973) {
                            var97 = 39.78;
                        } else {
                            var97 = 39.48;
                        }
                    } else {
                        if (input[0] <= 7.5) {
                            var97 = 44.31;
                        } else {
                            var97 = 41.93;
                        }
                    }
                } else {
                    var97 = 35.42;
                }
            }
        } else {
            if (input[1] <= 33.3650016784668) {
                if (input[2] <= 136.86500549316406) {
                    if (input[2] <= 85.74499893188477) {
                        if (input[0] <= 7.5) {
                            if (input[2] <= 30.609999656677246) {
                                var97 = 36.43;
                            } else {
                                if (input[2] <= 63.599998474121094) {
                                    var97 = 34.8;
                                } else {
                                    var97 = 34.91;
                                }
                            }
                        } else {
                            if (input[2] <= 35.429999113082886) {
                                var97 = 32.94;
                            } else {
                                var97 = 32.23;
                            }
                        }
                    } else {
                        if (input[2] <= 118.92000198364258) {
                            var97 = 38.4;
                        } else {
                            var97 = 37.89;
                        }
                    }
                } else {
                    if (input[1] <= 27.65499973297119) {
                        var97 = 34.54;
                    } else {
                        if (input[1] <= 30.195000648498535) {
                            var97 = 32.47;
                        } else {
                            if (input[1] <= 32.69500160217285) {
                                var97 = 33.27;
                            } else {
                                var97 = 32.91;
                            }
                        }
                    }
                }
            } else {
                if (input[1] <= 39.06999969482422) {
                    if (input[0] <= 10.5) {
                        if (input[2] <= 134.86999893188477) {
                            if (input[0] <= 4.5) {
                                var97 = 35.3;
                            } else {
                                if (input[0] <= 5.5) {
                                    var97 = 28.69;
                                } else {
                                    if (input[2] <= 45.665000915527344) {
                                        var97 = 31.17;
                                    } else {
                                        var97 = 30.22;
                                    }
                                }
                            }
                        } else {
                            if (input[0] <= 3.5) {
                                var97 = 31.15;
                            } else {
                                if (input[2] <= 188.73500061035156) {
                                    var97 = 35.16;
                                } else {
                                    var97 = 35.22;
                                }
                            }
                        }
                    } else {
                        var97 = 27.52;
                    }
                } else {
                    if (input[0] <= 4.5) {
                        if (input[0] <= 3.5) {
                            var97 = 29.28;
                        } else {
                            var97 = 29.5;
                        }
                    } else {
                        var97 = 26.88;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 45.01500129699707) {
            if (input[1] <= 30.27500057220459) {
                var97 = 88.23;
            } else {
                if (input[2] <= 253.2199935913086) {
                    if (input[2] <= 169.4000015258789) {
                        var97 = 82.48;
                    } else {
                        if (input[1] <= 36.14000129699707) {
                            var97 = 79.55;
                        } else {
                            var97 = 78.32;
                        }
                    }
                } else {
                    if (input[2] <= 273.96998596191406) {
                        var97 = 87.95;
                    } else {
                        if (input[0] <= 10.5) {
                            var97 = 80.11;
                        } else {
                            var97 = 83.02;
                        }
                    }
                }
            }
        } else {
            if (input[0] <= 6.0) {
                var97 = 70.41;
            } else {
                var97 = 75.92;
            }
        }
    }
    double var98;
    if (input[3] <= 0.5) {
        if (input[1] <= 30.90499973297119) {
            if (input[1] <= 23.81999969482422) {
                if (input[0] <= 5.5) {
                    if (input[2] <= 202.2550048828125) {
                        if (input[1] <= 22.190000534057617) {
                            if (input[0] <= 2.5) {
                                var98 = 34.54;
                            } else {
                                if (input[1] <= 21.27999973297119) {
                                    var98 = 35.16;
                                } else {
                                    var98 = 35.59;
                                }
                            }
                        } else {
                            var98 = 36.77;
                        }
                    } else {
                        var98 = 39.67;
                    }
                } else {
                    if (input[2] <= 221.1550064086914) {
                        if (input[0] <= 6.5) {
                            var98 = 44.31;
                        } else {
                            if (input[1] <= 22.6899995803833) {
                                if (input[1] <= 21.149999618530273) {
                                    var98 = 39.78;
                                } else {
                                    var98 = 39.52;
                                }
                            } else {
                                var98 = 41.93;
                            }
                        }
                    } else {
                        var98 = 35.42;
                    }
                }
            } else {
                if (input[2] <= 215.9199981689453) {
                    if (input[2] <= 76.15499877929688) {
                        if (input[2] <= 30.609999656677246) {
                            var98 = 36.43;
                        } else {
                            if (input[2] <= 63.599998474121094) {
                                var98 = 34.8;
                            } else {
                                var98 = 34.91;
                            }
                        }
                    } else {
                        if (input[2] <= 166.7449951171875) {
                            if (input[2] <= 109.21499633789062) {
                                var98 = 40.31;
                            } else {
                                var98 = 39.14;
                            }
                        } else {
                            if (input[2] <= 202.50499725341797) {
                                var98 = 36.76;
                            } else {
                                var98 = 36.25;
                            }
                        }
                    }
                } else {
                    var98 = 32.47;
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[2] <= 161.75) {
                    if (input[1] <= 37.0049991607666) {
                        if (input[1] <= 34.6200008392334) {
                            if (input[0] <= 7.0) {
                                var98 = 32.91;
                            } else {
                                if (input[2] <= 71.8800036907196) {
                                    var98 = 32.94;
                                } else {
                                    var98 = 33.27;
                                }
                            }
                        } else {
                            var98 = 31.17;
                        }
                    } else {
                        var98 = 35.3;
                    }
                } else {
                    if (input[0] <= 10.0) {
                        if (input[1] <= 33.66000175476074) {
                            var98 = 31.15;
                        } else {
                            if (input[1] <= 37.310001373291016) {
                                if (input[0] <= 5.0) {
                                    var98 = 30.34;
                                } else {
                                    var98 = 30.13;
                                }
                            } else {
                                var98 = 30.63;
                            }
                        }
                    } else {
                        var98 = 27.52;
                    }
                }
            } else {
                if (input[1] <= 39.20000076293945) {
                    if (input[0] <= 7.0) {
                        var98 = 28.69;
                    } else {
                        var98 = 28.17;
                    }
                } else {
                    var98 = 26.88;
                }
            }
        }
    } else {
        if (input[1] <= 33.01500129699707) {
            var98 = 88.23;
        } else {
            if (input[2] <= 99.03999900817871) {
                var98 = 82.02;
            } else {
                if (input[1] <= 39.84000015258789) {
                    if (input[2] <= 210.9000015258789) {
                        var98 = 78.32;
                    } else {
                        var98 = 79.55;
                    }
                } else {
                    if (input[1] <= 48.14500045776367) {
                        if (input[0] <= 5.5) {
                            var98 = 74.09;
                        } else {
                            if (input[1] <= 45.295000076293945) {
                                var98 = 76.33;
                            } else {
                                var98 = 75.92;
                            }
                        }
                    } else {
                        var98 = 80.28;
                    }
                }
            }
        }
    }
    double var99;
    if (input[3] <= 0.5) {
        if (input[1] <= 33.150001525878906) {
            if (input[1] <= 25.414999961853027) {
                if (input[2] <= 118.43000411987305) {
                    if (input[0] <= 7.5) {
                        var99 = 39.78;
                    } else {
                        if (input[2] <= 57.21500110626221) {
                            var99 = 39.52;
                        } else {
                            var99 = 39.48;
                        }
                    }
                } else {
                    if (input[2] <= 192.48500061035156) {
                        if (input[2] <= 164.36500549316406) {
                            var99 = 34.54;
                        } else {
                            var99 = 35.16;
                        }
                    } else {
                        if (input[0] <= 2.5) {
                            var99 = 39.67;
                        } else {
                            if (input[2] <= 211.7050018310547) {
                                var99 = 36.76;
                            } else {
                                var99 = 35.42;
                            }
                        }
                    }
                }
            } else {
                if (input[0] <= 4.0) {
                    var99 = 38.4;
                } else {
                    if (input[2] <= 5.509999990463257) {
                        var99 = 36.43;
                    } else {
                        if (input[1] <= 26.795000076293945) {
                            var99 = 32.23;
                        } else {
                            if (input[1] <= 27.84500026702881) {
                                if (input[2] <= 137.78499603271484) {
                                    var99 = 34.8;
                                } else {
                                    var99 = 34.54;
                                }
                            } else {
                                if (input[0] <= 7.5) {
                                    var99 = 32.47;
                                } else {
                                    if (input[2] <= 71.8800036907196) {
                                        var99 = 32.94;
                                    } else {
                                        var99 = 33.27;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (input[1] <= 38.510000228881836) {
                if (input[0] <= 10.5) {
                    if (input[1] <= 35.75) {
                        if (input[0] <= 3.5) {
                            if (input[2] <= 234.93000030517578) {
                                var99 = 31.15;
                            } else {
                                var99 = 30.34;
                            }
                        } else {
                            if (input[1] <= 34.72999954223633) {
                                var99 = 35.17;
                            } else {
                                var99 = 35.16;
                            }
                        }
                    } else {
                        if (input[2] <= 228.91000366210938) {
                            if (input[0] <= 7.5) {
                                if (input[2] <= 118.94500350952148) {
                                    var99 = 30.22;
                                } else {
                                    var99 = 30.63;
                                }
                            } else {
                                var99 = 31.17;
                            }
                        } else {
                            var99 = 32.07;
                        }
                    }
                } else {
                    var99 = 27.52;
                }
            } else {
                if (input[0] <= 4.5) {
                    if (input[1] <= 39.45000076293945) {
                        var99 = 29.5;
                    } else {
                        var99 = 29.28;
                    }
                } else {
                    if (input[2] <= 145.9650001525879) {
                        var99 = 28.69;
                    } else {
                        var99 = 28.17;
                    }
                }
            }
        }
    } else {
        if (input[1] <= 46.119998931884766) {
            if (input[1] <= 30.27500057220459) {
                var99 = 88.23;
            } else {
                if (input[2] <= 114.42500114440918) {
                    var99 = 82.02;
                } else {
                    if (input[2] <= 210.9000015258789) {
                        var99 = 78.32;
                    } else {
                        if (input[1] <= 33.250000953674316) {
                            var99 = 80.11;
                        } else {
                            var99 = 79.55;
                        }
                    }
                }
            }
        } else {
            if (input[2] <= 241.43500518798828) {
                if (input[1] <= 48.14500045776367) {
                    if (input[2] <= 168.19000244140625) {
                        var99 = 75.92;
                    } else {
                        if (input[0] <= 6.0) {
                            var99 = 74.09;
                        } else {
                            var99 = 74.62;
                        }
                    }
                } else {
                    var99 = 80.28;
                }
            } else {
                var99 = 70.41;
            }
        }
    }
    return (var0 + var1 + var2 + var3 + var4 + var5 + var6 + var7 + var8 + var9 + var10 + var11 + var12 + var13 + var14 + var15 + var16 + var17 + var18 + var19 + var20 + var21 + var22 + var23 + var24 + var25 + var26 + var27 + var28 + var29 + var30 + var31 + var32 + var33 + var34 + var35 + var36 + var37 + var38 + var39 + var40 + var41 + var42 + var43 + var44 + var45 + var46 + var47 + var48 + var49 + var50 + var51 + var52 + var53 + var54 + var55 + var56 + var57 + var58 + var59 + var60 + var61 + var62 + var63 + var64 + var65 + var66 + var67 + var68 + var69 + var70 + var71 + var72 + var73 + var74 + var75 + var76 + var77 + var78 + var79 + var80 + var81 + var82 + var83 + var84 + var85 + var86 + var87 + var88 + var89 + var90 + var91 + var92 + var93 + var94 + var95 + var96 + var97 + var98 + var99) * 0.01;
}
